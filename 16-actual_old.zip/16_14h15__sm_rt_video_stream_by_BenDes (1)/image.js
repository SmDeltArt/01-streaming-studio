
// IMAGE 


export class ImageManager {
    constructor(recorderManager) {
        this.recorderManager = recorderManager;
        this.activeImages = new Map();
        this.imageIdCounter = 0;
        this.isImageControlPanelOpen = false;
        this.currentEditingImageId = null;
        this.isImagePanelCollapsed = false;
        
        // Default image properties
        this.defaultImageProperties = {
            src: '',
            width: 200,
            height: 200,
            x: 50,
            y: 50,
            opacity: 1.0,
            rotation: 0,
            borderRadius: 0,
            zIndex: 1000,
            displayTime: 5000,
            animation: 'none',
            animationDuration: 1000,
            animationDelay: 0,
            filter: 'none',
            shadow: 'none',
            backgroundRemoval: false,
            preserveAspectRatio: true,
            blendMode: 'normal',
            borderWidth: 0,
            borderColor: '#000000',
            scale: 1.0
        };
        
        this.availableAnimations = [
            { value: 'none', name: 'None' },
            { value: 'fadeIn', name: '🌅 Fade In' },
            { value: 'fadeOut', name: '🌄 Fade Out' },
            { value: 'slideInLeft', name: '⬅️ Slide In Left' },
            { value: 'slideInRight', name: '➡️ Slide In Right' },
            { value: 'slideInTop', name: '⬆️ Slide In Top' },
            { value: 'slideInBottom', name: '⬇️ Slide In Bottom' },
            { value: 'zoomIn', name: '🔍 Zoom In' },
            { value: 'zoomOut', name: '🔎 Zoom Out' },
            { value: 'bounce', name: '🏀 Bounce' },
            { value: 'shake', name: '🔔 Shake' },
            { value: 'pulse', name: '💓 Pulse' },
            { value: 'flash', name: '⚡ Flash' },
            { value: 'flip', name: '🔄 Flip' },
            { value: 'scroll', name: '📜 Scroll' },
            { value: 'rotate', name: '🌀 Rotate' },
            { value: 'float', name: '🎈 Float' }
        ];
        
        this.availableFilters = [
            { value: 'none', name: 'None' },
            { value: 'blur', name: '🌫️ Blur' },
            { value: 'brightness', name: '☀️ Brightness' },
            { value: 'contrast', name: '⚡ Contrast' },
            { value: 'grayscale', name: '⚫ Grayscale' },
            { value: 'sepia', name: '🟤 Sepia' },
            { value: 'invert', name: '🔄 Invert' },
            { value: 'saturate', name: '🌈 Saturate' },
            { value: 'hue-rotate', name: '🎨 Hue Rotate' }
        ];
        
        this.availableShadows = [
            { value: 'none', name: 'None' },
            { value: 'soft', name: '🌫️ Soft Shadow' },
            { value: 'hard', name: '⬛ Hard Shadow' },
            { value: 'colored', name: '🌈 Colored Shadow' },
            { value: 'glow', name: '✨ Glow Effect' },
            { value: 'multiple', name: '📐 Multiple Shadows' }
        ];
    }

    init() {
        this.createImageStyles();
    }

    createImageStyles() {
        if (document.getElementById('image-system-styles')) return;
        
        const style = document.createElement('style');
        style.id = 'image-system-styles';
        style.textContent = `
            @keyframes imageFadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            
            @keyframes imageFadeOut {
                from { opacity: 1; }
                to { opacity: 0; }
            }
            
            @keyframes imageSlideInLeft {
                from { transform: translateX(-100%); }
                to { transform: translateX(0); }
            }
            
            @keyframes imageSlideInRight {
                from { transform: translateX(100%); }
                to { transform: translateX(0); }
            }
            
            @keyframes imageSlideInTop {
                from { transform: translateY(-100%); }
                to { transform: translateY(0); }
            }
            
            @keyframes imageSlideInBottom {
                from { transform: translateY(100%); }
                to { transform: translateY(0); }
            }
            
            @keyframes imageZoomIn {
                from { transform: scale(0); }
                to { transform: scale(1); }
            }
            
            @keyframes imageZoomOut {
                from { transform: scale(1); }
                to { transform: scale(0); }
            }
            
            @keyframes imageBounce {
                0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
                40% { transform: translateY(-20px); }
                60% { transform: translateY(-10px); }
            }
            
            @keyframes imageShake {
                0%, 100% { transform: translateX(0); }
                10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
                20%, 40%, 60%, 80% { transform: translateX(5px); }
            }
            
            @keyframes imagePulse {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.1); }
            }
            
            @keyframes imageFlash {
                0%, 100% { opacity: 1; }
                50% { opacity: 0; }
            }
            
            @keyframes imageFlip {
                from { transform: rotateY(0deg); }
                to { transform: rotateY(360deg); }
            }
            
            @keyframes imageScroll {
                from { transform: translateX(100vw); }
                to { transform: translateX(-100%); }
            }
            
            @keyframes imageRotate {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            
            @keyframes imageFloat {
                0%, 100% { transform: translateY(0px); }
                50% { transform: translateY(-20px); }
            }
            
            .image-display-element {
                position: fixed;
                pointer-events: none;
                user-select: none;
                object-fit: cover;
                border: solid;
                border-color: transparent;
            }
            
            .image-control-panel {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 520px;
                max-height: 90vh;
                background: rgba(255, 255, 255, 0.85);
                border: 2px solid #667eea;
                border-radius: 12px;
                z-index: 20000;
                backdrop-filter: blur(15px);
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
                overflow-y: auto;
            }
            
            .image-control-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 15px 20px;
                background: linear-gradient(135deg, rgba(102, 126, 234, 0.9) 0%, rgba(118, 75, 162, 0.9) 100%);
                color: white;
                border-radius: 10px 10px 0 0;
                margin: -2px -2px 0 -2px;
                user-select: none;
            }

            .image-header-controls {
                display: flex;
                gap: 5px;
                align-items: center;
            }
            
            .image-control-collapse,
            .image-control-close {
                background: rgba(255, 255, 255, 0.2);
                border: none;
                color: white;
                padding: 5px 10px;
                border-radius: 50%;
                cursor: pointer;
                font-size: 16px;
                width: 30px;
                height: 30px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: bold;
            }
            
            .image-control-collapse:hover,
            .image-control-close:hover {
                background: rgba(255, 255, 255, 0.3);
            }
            
            .image-control-content {
                padding: 20px;
                background: rgba(255, 255, 255, 0.05);
                backdrop-filter: blur(5px);
            }
            
            .image-section {
                margin-bottom: 20px;
                padding-bottom: 15px;
                border-bottom: 1px solid #eee;
            }
            
            .image-section:last-child {
                border-bottom: none;
                margin-bottom: 10px;
            }
            
            .image-section h4 {
                margin: 0 0 10px 0;
                color: #333;
                font-size: 14px;
                font-weight: bold;
            }
            
            .image-property-row {
                display: flex;
                align-items: center;
                gap: 10px;
                margin-bottom: 10px;
            }
            
            .image-property-row label {
                min-width: 80px;
                font-size: 12px;
                font-weight: 500;
            }
            
            .image-property-row input,
            .image-property-row select {
                flex: 1;
                padding: 4px 8px;
                border: 1px solid #ccc;
                border-radius: 4px;
                font-size: 12px;
            }
            
            .image-property-row input[type="range"] {
                height: 6px;
            }
            
            .image-property-row input[type="color"] {
                width: 40px;
                height: 30px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                padding: 0;
            }
            
            .image-property-row input[type="file"] {
                padding: 2px;
                font-size: 11px;
            }
            
            .image-property-value {
                min-width: 40px;
                font-size: 11px;
                color: #666;
                text-align: center;
            }
            
            .image-actions {
                display: flex;
                gap: 10px;
                flex-wrap: wrap;
                margin: 0;
                padding: 15px 20px;
                background: rgba(255, 255, 255, 0.05);
                border-radius: 0 0 10px 10px;
                backdrop-filter: blur(5px);
            }
            
            .image-action-btn {
                flex: 1;
                min-width: 80px;
                padding: 8px 12px;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-size: 12px;
                font-weight: bold;
                transition: all 0.2s ease;
            }
            
            .image-action-btn.primary {
                background: #28a745;
                color: white;
            }
            
            .image-action-btn.primary:hover {
                background: #218838;
            }
            
            .image-action-btn.secondary {
                background: #007bff;
                color: white;
            }
            
            .image-action-btn.secondary:hover {
                background: #0056b3;
            }
            
            .image-action-btn.danger {
                background: #dc3545;
                color: white;
            }
            
            .image-action-btn.danger:hover {
                background: #c82333;
            }
            
            .image-action-btn:not(.primary):not(.secondary):not(.danger) {
                background: #6c757d;
                color: white;
            }
            
            .image-action-btn:not(.primary):not(.secondary):not(.danger):hover {
                background: #5a6268;
            }
            
            .image-preview {
                background: #f8f9fa;
                border: 1px solid #dee2e6;
                border-radius: 6px;
                padding: 15px;
                margin: 10px 0;
                text-align: center;
                min-height: 120px;
                display: flex;
                align-items: center;
                justify-content: center;
                position: relative;
                overflow: hidden;
            }
            
            .image-preview img {
                max-width: 100%;
                max-height: 100px;
                object-fit: contain;
                border-radius: 4px;
            }
            
            .image-list {
                max-height: 200px;
                overflow-y: auto;
                border: 1px solid #ddd;
                border-radius: 6px;
                background: rgba(0, 0, 0, 0.02);
            }
            
            .image-item {
                padding: 8px;
                border-bottom: 1px solid #eee;
                transition: background-color 0.2s ease;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .image-item:last-child {
                border-bottom: none;
            }
            
            .image-item:hover {
                background: rgba(0, 123, 255, 0.05);
            }
            
            .image-item-info {
                flex: 1;
                font-size: 12px;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .image-item-thumbnail {
                width: 30px;
                height: 30px;
                object-fit: cover;
                border-radius: 3px;
                border: 1px solid #ddd;
            }
            
            .image-item-controls {
                display: flex;
                gap: 4px;
            }
            
            .image-item-btn {
                padding: 2px 6px;
                border: none;
                border-radius: 3px;
                cursor: pointer;
                font-size: 10px;
                background: rgba(0, 0, 0, 0.1);
                transition: all 0.2s ease;
                min-width: 20px;
                height: 20px;
            }
            
            .image-item-btn:hover {
                transform: scale(1.1);
            }
            
            .image-item-btn.edit:hover {
                background: #007bff;
                color: white;
            }
            
            .image-item-btn.remove:hover {
                background: #dc3545;
                color: white;
            }
            
            .image-item-btn.toggle:hover {
                background: #28a745;
                color: white;
            }
        `;
        document.head.appendChild(style);
    }

    showImageControlPanel() {
        // Remove existing panel if it exists
        const existingPanel = document.getElementById('image-control-panel');
        if (existingPanel) {
            existingPanel.remove();
        }

        this.isImageControlPanelOpen = true;
        this.isImagePanelCollapsed = false;
        const panel = document.createElement('div');
        panel.id = 'image-control-panel';
        panel.className = 'image-control-panel';
        
        panel.innerHTML = `
            <div class="image-control-header">
                <div class="image-control-title">🖼️ Image Display Manager</div>
                <div class="image-header-controls">
                    <button class="image-control-collapse" title="Collapse/Expand">−</button>
                    <button class="image-control-close">×</button>
                </div>
            </div>
            <div class="image-control-content" id="image-control-content">
                <div class="image-section">
                    <h4>🖼️ Active Images</h4>
                    <div class="image-list" id="active-images-list">
                        <!-- Active images will be populated here -->
                    </div>
                </div>

                <div class="image-section">
                    <h4>📁 Image Source</h4>
                    <div class="image-property-row">
                        <label>Upload:</label>
                        <input type="file" id="image-file-input" accept="image/*,.webp" multiple>
                    </div>
                    <div class="image-property-row">
                        <label>URL:</label>
                        <input type="url" id="image-url-input" placeholder="https://example.com/image.jpg">
                    </div>
                </div>
                
                <div class="image-section">
                    <h4>📐 Size & Position</h4>
                    <div class="image-property-row">
                        <label>Width:</label>
                        <input type="range" id="image-width" min="50" max="800" value="${this.defaultImageProperties.width}">
                        <span class="image-property-value" id="width-value">${this.defaultImageProperties.width}px</span>
                    </div>
                    <div class="image-property-row">
                        <label>Height:</label>
                        <input type="range" id="image-height" min="50" max="800" value="${this.defaultImageProperties.height}">
                        <span class="image-property-value" id="height-value">${this.defaultImageProperties.height}px</span>
                    </div>
                    <div class="image-property-row">
                        <label>Scale:</label>
                        <input type="range" id="image-scale" min="0.1" max="3" step="0.1" value="${this.defaultImageProperties.scale}">
                        <span class="image-property-value" id="scale-value">${this.defaultImageProperties.scale}x</span>
                    </div>
                    <div class="image-property-row">
                        <label>Rotation:</label>
                        <input type="range" id="image-rotation" min="0" max="360" value="${this.defaultImageProperties.rotation}">
                        <span class="image-property-value" id="rotation-value">${this.defaultImageProperties.rotation}°</span>
                    </div>
                    <div class="image-property-row">
                        <label>X Position:</label>
                        <input type="range" id="image-x" min="0" max="100" value="${this.defaultImageProperties.x}">
                        <span class="image-property-value" id="x-value">${this.defaultImageProperties.x}%</span>
                    </div>
                    <div class="image-property-row">
                        <label>Y Position:</label>
                        <input type="range" id="image-y" min="0" max="100" value="${this.defaultImageProperties.y}">
                        <span class="image-property-value" id="y-value">${this.defaultImageProperties.y}%</span>
                    </div>
                    <div class="image-property-row">
                        <label>
                            <input type="checkbox" id="preserve-aspect-ratio" ${this.defaultImageProperties.preserveAspectRatio ? 'checked' : ''}>
                            Preserve Aspect Ratio
                        </label>
                    </div>
                </div>
                
                <div class="image-section">
                    <h4>🎨 Appearance</h4>
                    <div class="image-property-row">
                        <label>Opacity:</label>
                        <input type="range" id="image-opacity" min="0" max="1" step="0.05" value="${this.defaultImageProperties.opacity}">
                        <span class="image-property-value" id="opacity-value">${Math.round(this.defaultImageProperties.opacity * 100)}%</span>
                    </div>
                    <div class="image-property-row">
                        <label>Border Radius:</label>
                        <input type="range" id="image-border-radius" min="0" max="50" value="${this.defaultImageProperties.borderRadius}">
                        <span class="image-property-value" id="border-radius-value">${this.defaultImageProperties.borderRadius}px</span>
                    </div>
                    <div class="image-property-row">
                        <label>Border Width:</label>
                        <input type="range" id="image-border-width" min="0" max="20" value="${this.defaultImageProperties.borderWidth}">
                        <span class="image-property-value" id="border-width-value">${this.defaultImageProperties.borderWidth}px</span>
                    </div>
                    <div class="image-property-row">
                        <label>Border Color:</label>
                        <input type="color" id="image-border-color" value="${this.defaultImageProperties.borderColor}">
                    </div>
                    <div class="image-property-row">
                        <label>Blend Mode:</label>
                        <select id="image-blend-mode">
                            <option value="normal">Normal</option>
                            <option value="multiply">Multiply</option>
                            <option value="screen">Screen</option>
                            <option value="overlay">Overlay</option>
                            <option value="soft-light">Soft Light</option>
                            <option value="hard-light">Hard Light</option>
                            <option value="color-dodge">Color Dodge</option>
                            <option value="color-burn">Color Burn</option>
                            <option value="difference">Difference</option>
                            <option value="exclusion">Exclusion</option>
                        </select>
                    </div>
                </div>
                
                <div class="image-section">
                    <h4>✨ Effects</h4>
                    <div class="image-property-row">
                        <label>Filter:</label>
                        <select id="image-filter">
                            ${this.availableFilters.map(filter => 
                                `<option value="${filter.value}" ${filter.value === this.defaultImageProperties.filter ? 'selected' : ''}>${filter.name}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <div class="image-property-row">
                        <label>Shadow:</label>
                        <select id="image-shadow">
                            ${this.availableShadows.map(shadow => 
                                `<option value="${shadow.value}" ${shadow.value === this.defaultImageProperties.shadow ? 'selected' : ''}>${shadow.name}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <div class="image-property-row">
                        <label>
                            <input type="checkbox" id="background-removal" ${this.defaultImageProperties.backgroundRemoval ? 'checked' : ''}>
                            Remove Background (Alpha)
                        </label>
                    </div>
                </div>
                
                <div class="image-section">
                    <h4>⏰ Timing & Animation</h4>
                    <div class="image-property-row">
                        <label>Display Time:</label>
                        <input type="range" id="image-display-time" min="1000" max="30000" step="100" value="${this.defaultImageProperties.displayTime}">
                        <span class="image-property-value" id="display-time-value">${this.defaultImageProperties.displayTime / 1000}s</span>
                    </div>
                    <div class="image-property-row">
                        <label>Animation:</label>
                        <select id="image-animation">
                            ${this.availableAnimations.map(animation => 
                                `<option value="${animation.value}" ${animation.value === this.defaultImageProperties.animation ? 'selected' : ''}>${animation.name}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <div class="image-property-row">
                        <label>Duration:</label>
                        <input type="range" id="image-animation-duration" min="100" max="5000" step="50" value="${this.defaultImageProperties.animationDuration}">
                        <span class="image-property-value" id="animation-duration-value">${this.defaultImageProperties.animationDuration}ms</span>
                    </div>
                    <div class="image-property-row">
                        <label>Delay:</label>
                        <input type="range" id="image-animation-delay" min="0" max="3000" step="50" value="${this.defaultImageProperties.animationDelay}">
                        <span class="image-property-value" id="animation-delay-value">${this.defaultImageProperties.animationDelay}ms</span>
                    </div>
                </div>
                
                <div class="image-section">
                    <h4>👁️ Preview</h4>
                    <div class="image-preview" id="image-preview">
                        <div style="color: #999; font-style: italic;">Select an image to preview</div>
                    </div>
                </div>
            </div>
                
            <div class="image-actions" id="image-actions">
                <button id="preview-image-btn" class="image-action-btn secondary">👁️ Preview</button>
                <button id="add-image-display-btn" class="image-action-btn primary">➕ Add Image</button>
                <button id="save-image-preset-btn" class="image-action-btn">💾 Save Preset</button>
                <button id="load-image-preset-btn" class="image-action-btn">📂 Load Preset</button>
                <button id="clear-all-images-btn" class="image-action-btn danger">🗑️ Clear All</button>
            </div>
        `;

        document.body.appendChild(panel);
        this.setupImageControlEvents(panel);
        this.setupImagePanelDragging(panel);
        this.updateActiveImagesList();
    }

    setupImagePanelDragging(panel) {
        const header = panel.querySelector('.image-control-header');
        let isDragging = false;
        let dragOffset = { x: 0, y: 0 };

        header.addEventListener('mousedown', (e) => {
            // Don't start dragging if clicking on buttons
            if (e.target.classList.contains('image-control-close') || 
                e.target.classList.contains('image-control-collapse')) {
                return;
            }
            
            isDragging = true;
            const rect = panel.getBoundingClientRect();
            dragOffset.x = e.clientX - rect.left;
            dragOffset.y = e.clientY - rect.top;
            panel.style.cursor = 'grabbing';
            header.style.cursor = 'grabbing';
        });

        document.addEventListener('mousemove', (e) => {
            if (isDragging) {
                const x = e.clientX - dragOffset.x;
                const y = e.clientY - dragOffset.y;
                
                // Allow 95% off-screen positioning
                const maxX = window.innerWidth - (panel.offsetWidth * 0.05);
                const maxY = window.innerHeight - (panel.offsetHeight * 0.05);
                const minX = -(panel.offsetWidth * 0.95);
                const minY = -(panel.offsetHeight * 0.95);
                
                panel.style.left = `${Math.max(minX, Math.min(x, maxX))}px`;
                panel.style.top = `${Math.max(minY, Math.min(y, maxY))}px`;
                panel.style.transform = 'none';
            }
        });

        document.addEventListener('mouseup', () => {
            isDragging = false;
            panel.style.cursor = 'default';
            header.style.cursor = 'grab';
        });

        // Set initial cursor
        header.style.cursor = 'grab';
    }

    setupImageControlEvents(panel) {
        const closeBtn = panel.querySelector('.image-control-close');
        const collapseBtn = panel.querySelector('.image-control-collapse');
        const content = panel.querySelector('#image-control-content');
        
        closeBtn.addEventListener('click', () => this.closeImageControlPanel());
        
        collapseBtn.addEventListener('click', () => {
            this.isImagePanelCollapsed = !this.isImagePanelCollapsed;
            
            if (this.isImagePanelCollapsed) {
                content.style.display = 'none';
                collapseBtn.textContent = '+';
                collapseBtn.title = 'Expand';
                panel.style.height = 'auto';
            } else {
                content.style.display = 'block';
                collapseBtn.textContent = '−';
                collapseBtn.title = 'Collapse';
            }
        });

        // File upload handling
        const fileInput = panel.querySelector('#image-file-input');
        fileInput.addEventListener('change', (e) => this.handleFileUpload(e));

        // URL input handling
        const urlInput = panel.querySelector('#image-url-input');
        urlInput.addEventListener('input', () => this.updatePreview());

        // Real-time preview updates
        const inputs = panel.querySelectorAll('input, select');
        inputs.forEach(input => {
            input.addEventListener('input', () => this.updatePreview());
        });

        // Value displays
        this.setupValueDisplays(panel);

        // Action buttons
        panel.querySelector('#preview-image-btn').addEventListener('click', () => this.previewImage());
        panel.querySelector('#add-image-display-btn').addEventListener('click', () => this.addImageDisplay());
        panel.querySelector('#save-image-preset-btn').addEventListener('click', () => this.saveImagePreset());
        panel.querySelector('#load-image-preset-btn').addEventListener('click', () => this.loadImagePreset());
        panel.querySelector('#clear-all-images-btn').addEventListener('click', () => this.clearAllImages());
    }

    setupValueDisplays(panel) {
        const valueUpdaters = [
            { slider: '#image-width', display: '#width-value', suffix: 'px' },
            { slider: '#image-height', display: '#height-value', suffix: 'px' },
            { slider: '#image-scale', display: '#scale-value', suffix: 'x' },
            { slider: '#image-x', display: '#x-value', suffix: '%' },
            { slider: '#image-y', display: '#y-value', suffix: '%' },
            { slider: '#image-rotation', display: '#rotation-value', suffix: '°' },
            { slider: '#image-opacity', display: '#opacity-value', transform: (val) => Math.round(val * 100) + '%' },
            { slider: '#image-border-radius', display: '#border-radius-value', suffix: 'px' },
            { slider: '#image-border-width', display: '#border-width-value', suffix: 'px' },
            { slider: '#image-display-time', display: '#display-time-value', transform: (val) => (val / 1000) + 's' },
            { slider: '#image-animation-duration', display: '#animation-duration-value', suffix: 'ms' },
            { slider: '#image-animation-delay', display: '#animation-delay-value', suffix: 'ms' }
        ];

        valueUpdaters.forEach(({ slider, display, suffix, transform }) => {
            const sliderEl = panel.querySelector(slider);
            const displayEl = panel.querySelector(display);
            
            if (sliderEl && displayEl) {
                sliderEl.addEventListener('input', (e) => {
                    const value = parseFloat(e.target.value);
                    displayEl.textContent = transform ? transform(value) : value + (suffix || '');
                });
            }
        });
    }

    handleFileUpload(event) {
        const files = Array.from(event.target.files);
        if (files.length === 0) return;

        // Handle multiple files
        files.forEach(file => {
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    const panel = document.getElementById('image-control-panel');
                    const urlInput = panel.querySelector('#image-url-input');
                    urlInput.value = e.target.result;
                    this.updatePreview();
                };
                reader.readAsDataURL(file);
            }
        });
    }

    updatePreview() {
        const panel = document.getElementById('image-control-panel');
        if (!panel) return;

        const preview = panel.querySelector('#image-preview');
        const properties = this.getImagePropertiesFromPanel(panel);
        
        if (properties.src) {
            // Combine filter and shadow effects for preview
            const filterEffects = [];
            
            const filterStyle = this.getFilterStyle(properties.filter);
            if (filterStyle !== 'none') {
                filterEffects.push(filterStyle);
            }
            
            const shadowStyle = this.getShadowStyle(properties.shadow);
            if (shadowStyle !== 'none') {
                filterEffects.push(shadowStyle);
            }
            
            const combinedFilter = filterEffects.length > 0 ? filterEffects.join(' ') : 'none';
            
            preview.innerHTML = `<img src="${properties.src}" style="
                width: ${Math.min(properties.width, 150)}px;
                height: ${Math.min(properties.height, 100)}px;
                opacity: ${properties.opacity};
                transform: rotate(${properties.rotation}deg) scale(${properties.scale});
                border-radius: ${properties.borderRadius}px;
                border: ${properties.borderWidth}px solid ${properties.borderColor};
                mix-blend-mode: ${properties.blendMode};
                filter: ${combinedFilter};
                object-fit: ${properties.preserveAspectRatio ? 'contain' : 'cover'};
            ">`;
        } else {
            preview.innerHTML = '<div style="color: #999; font-style: italic;">Select an image to preview</div>';
        }
    }

    getImagePropertiesFromPanel(panel) {
        const fileInput = panel.querySelector('#image-file-input');
        const urlInput = panel.querySelector('#image-url-input');
        
        let src = urlInput ? urlInput.value : '';
        if (!src && fileInput && fileInput.files.length > 0) {
            // This will be handled by the file reader
            src = '';
        }

        return {
            src: src,
            width: parseInt(panel.querySelector('#image-width')?.value || this.defaultImageProperties.width),
            height: parseInt(panel.querySelector('#image-height')?.value || this.defaultImageProperties.height),
            scale: parseFloat(panel.querySelector('#image-scale')?.value || this.defaultImageProperties.scale),
            x: parseInt(panel.querySelector('#image-x')?.value || this.defaultImageProperties.x),
            y: parseInt(panel.querySelector('#image-y')?.value || this.defaultImageProperties.y),
            opacity: parseFloat(panel.querySelector('#image-opacity')?.value || this.defaultImageProperties.opacity),
            rotation: parseInt(panel.querySelector('#image-rotation')?.value || this.defaultImageProperties.rotation),
            borderRadius: parseInt(panel.querySelector('#image-border-radius')?.value || this.defaultImageProperties.borderRadius),
            borderWidth: parseInt(panel.querySelector('#image-border-width')?.value || this.defaultImageProperties.borderWidth),
            borderColor: panel.querySelector('#image-border-color')?.value || this.defaultImageProperties.borderColor,
            zIndex: 1000,
            displayTime: parseInt(panel.querySelector('#image-display-time')?.value || this.defaultImageProperties.displayTime),
            animation: panel.querySelector('#image-animation')?.value || this.defaultImageProperties.animation,
            animationDuration: parseInt(panel.querySelector('#image-animation-duration')?.value || this.defaultImageProperties.animationDuration),
            animationDelay: parseInt(panel.querySelector('#image-animation-delay')?.value || this.defaultImageProperties.animationDelay),
            filter: panel.querySelector('#image-filter')?.value || this.defaultImageProperties.filter,
            shadow: panel.querySelector('#image-shadow')?.value || this.defaultImageProperties.shadow,
            backgroundRemoval: panel.querySelector('#background-removal')?.checked || this.defaultImageProperties.backgroundRemoval,
            preserveAspectRatio: panel.querySelector('#preserve-aspect-ratio')?.checked || this.defaultImageProperties.preserveAspectRatio,
            blendMode: panel.querySelector('#image-blend-mode')?.value || this.defaultImageProperties.blendMode
        };
    }

    getFilterStyle(filterType) {
        switch (filterType) {
            case 'blur': return 'blur(5px)';
            case 'brightness': return 'brightness(1.2)';
            case 'contrast': return 'contrast(1.2)';
            case 'grayscale': return 'grayscale(100%)';
            case 'sepia': return 'sepia(100%)';
            case 'invert': return 'invert(100%)';
            case 'saturate': return 'saturate(1.5)';
            case 'hue-rotate': return 'hue-rotate(90deg)';
            default: return 'none';
        }
    }

    getShadowStyle(shadowType) {
        switch (shadowType) {
            case 'soft': return 'drop-shadow(0 4px 8px rgba(0,0,0,0.3))';
            case 'hard': return 'drop-shadow(5px 5px 0px rgba(0,0,0,1))';
            case 'colored': return 'drop-shadow(0 0 20px rgba(255,0,255,0.8))';
            case 'glow': return 'drop-shadow(0 0 20px rgba(255,255,255,0.8))';
            case 'multiple': return 'drop-shadow(0 0 5px rgba(0,0,0,0.3)) drop-shadow(0 0 15px rgba(0,0,0,0.2)) drop-shadow(0 0 25px rgba(0,0,0,0.1))';
            default: return 'none';
        }
    }

    previewImage() {
        const panel = document.getElementById('image-control-panel');
        if (!panel) return;

        const properties = this.getImagePropertiesFromPanel(panel);
        if (!properties.src) {
            alert('Please select an image first');
            return;
        }
        this.displayImage(properties, true);
    }

    addImageDisplay() {
        const panel = document.getElementById('image-control-panel');
        if (!panel) return;

        const properties = this.getImagePropertiesFromPanel(panel);
        if (!properties.src) {
            alert('Please select an image first');
            return;
        }
        
        const imageId = this.displayImage(properties, false);
        
        // Record the image addition
        if (this.recorderManager) {
            this.recorderManager.logEvent('add-image', [imageId, properties]);
        }
        
        this.updateActiveImagesList();
    }

    displayImage(properties, isPreview = false) {
        const imageId = isPreview ? 'preview-image' : `image-${this.imageIdCounter++}`;
        
        // Remove existing preview if it exists
        if (isPreview) {
            const existing = document.getElementById(imageId);
            if (existing) existing.remove();
        }
        
        const imageElement = document.createElement('img');
        imageElement.id = imageId;
        imageElement.className = 'image-display-element';
        imageElement.src = properties.src;
        
        // Apply styles
        this.applyImageStyle(imageElement, properties);
        
        // Apply animation
        if (properties.animation && properties.animation !== 'none') {
            this.applyAnimation(imageElement, properties);
        }
        
        document.body.appendChild(imageElement);
        
        // Store active image if not preview
        if (!isPreview) {
            this.activeImages.set(imageId, {
                element: imageElement,
                properties: { ...properties },
                isVisible: true
            });
        }
        
        // Auto-remove after display time
        if (properties.displayTime > 0) {
            setTimeout(() => {
                if (imageElement.parentNode) {
                    if (isPreview || this.activeImages.has(imageId)) {
                        imageElement.remove();
                        if (!isPreview) {
                            this.activeImages.delete(imageId);
                            this.updateActiveImagesList();
                        }
                    }
                }
            }, properties.displayTime);
        }
        
        return imageId;
    }

    applyImageStyle(element, properties) {
        element.style.left = properties.x + '%';
        element.style.top = properties.y + '%';
        element.style.width = properties.width + 'px';
        element.style.height = properties.height + 'px';
        element.style.opacity = properties.opacity;
        element.style.transform = `rotate(${properties.rotation}deg) scale(${properties.scale})`;
        element.style.borderRadius = properties.borderRadius + 'px';
        element.style.borderWidth = properties.borderWidth + 'px';
        element.style.borderColor = properties.borderColor;
        element.style.zIndex = properties.zIndex;
        element.style.mixBlendMode = properties.blendMode;
        element.style.objectFit = properties.preserveAspectRatio ? 'contain' : 'cover';
        
        // Combine filter and shadow effects
        const filterEffects = [];
        
        const filterStyle = this.getFilterStyle(properties.filter);
        if (filterStyle !== 'none') {
            filterEffects.push(filterStyle);
        }
        
        const shadowStyle = this.getShadowStyle(properties.shadow);
        if (shadowStyle !== 'none') {
            filterEffects.push(shadowStyle);
        }
        
        element.style.filter = filterEffects.length > 0 ? filterEffects.join(' ') : 'none';
        
        // Remove box-shadow since we're using drop-shadow filter
        element.style.boxShadow = 'none';
        
        if (properties.backgroundRemoval) {
            element.style.backgroundColor = 'transparent';
        }
    }

    applyAnimation(element, properties) {
        const animationName = `image${properties.animation.charAt(0).toUpperCase() + properties.animation.slice(1)}`;
        element.style.animation = `${animationName} ${properties.animationDuration}ms ease ${properties.animationDelay}ms`;
        
        // Special handling for continuous animations
        if (properties.animation === 'scroll') {
            element.style.animation = `imageScroll ${properties.animationDuration}ms linear infinite`;
        } else if (properties.animation === 'rotate') {
            element.style.animation = `imageRotate ${properties.animationDuration}ms linear infinite`;
        } else if (properties.animation === 'float') {
            element.style.animation = `imageFloat ${properties.animationDuration}ms ease-in-out infinite`;
        }
    }

    updateActiveImagesList() {
        const panel = document.getElementById('image-control-panel');
        if (!panel) return;

        const list = panel.querySelector('#active-images-list');
        if (!list) return;

        list.innerHTML = '';

        if (this.activeImages.size === 0) {
            list.innerHTML = '<div style="padding: 20px; text-align: center; color: #666; font-style: italic;">No active images</div>';
            return;
        }

        this.activeImages.forEach((imageData, imageId) => {
            const item = document.createElement('div');
            item.className = 'image-item';
            
            const imageName = imageData.properties.src.split('/').pop() || 'Unnamed Image';
            const truncatedName = imageName.length > 20 ? imageName.substring(0, 17) + '...' : imageName;
            
            item.innerHTML = `
                <div class="image-item-info">
                    <img src="${imageData.properties.src}" class="image-item-thumbnail" alt="Thumbnail">
                    <div>
                        <div style="font-weight: bold;">${truncatedName}</div>
                        <div style="color: #666; font-size: 11px;">
                            ${imageData.properties.width}×${imageData.properties.height}px
                            ${imageData.properties.animation !== 'none' ? `🎬 ${imageData.properties.animation}` : ''}
                        </div>
                    </div>
                </div>
                <div class="image-item-controls">
                    <button class="image-item-btn edit" data-image-id="${imageId}" title="Edit">✏️</button>
                    <button class="image-item-btn toggle" data-image-id="${imageId}" title="Toggle Visibility">${imageData.isVisible ? '👁️' : '🙈'}</button>
                    <button class="image-item-btn remove" data-image-id="${imageId}" title="Remove">🗑️</button>
                </div>
            `;

            list.appendChild(item);
        });

        // Setup event listeners for image item controls
        list.querySelectorAll('.image-item-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const imageId = e.target.dataset.imageId;
                const action = e.target.classList.contains('edit') ? 'edit' :
                              e.target.classList.contains('toggle') ? 'toggle' :
                              e.target.classList.contains('remove') ? 'remove' : '';
                
                this.handleImageItemAction(imageId, action);
            });
        });
    }

    handleImageItemAction(imageId, action) {
        const imageData = this.activeImages.get(imageId);
        if (!imageData) return;

        switch (action) {
            case 'edit':
                this.editImage(imageId);
                break;
            case 'toggle':
                this.toggleImageVisibility(imageId);
                break;
            case 'remove':
                this.removeImage(imageId);
                break;
        }
    }

    editImage(imageId) {
        const imageData = this.activeImages.get(imageId);
        if (!imageData) return;

        // Load properties into the panel
        const panel = document.getElementById('image-control-panel');
        if (!panel) return;

        const props = imageData.properties;
        panel.querySelector('#image-url-input').value = props.src;
        panel.querySelector('#image-width').value = props.width;
        panel.querySelector('#image-height').value = props.height;
        panel.querySelector('#image-scale').value = props.scale;
        panel.querySelector('#image-x').value = props.x;
        panel.querySelector('#image-y').value = props.y;
        panel.querySelector('#image-opacity').value = props.opacity;
        panel.querySelector('#image-rotation').value = props.rotation;
        panel.querySelector('#image-border-radius').value = props.borderRadius;
        panel.querySelector('#image-border-width').value = props.borderWidth;
        panel.querySelector('#image-border-color').value = props.borderColor;
        panel.querySelector('#image-display-time').value = props.displayTime;
        panel.querySelector('#image-animation').value = props.animation;
        panel.querySelector('#image-animation-duration').value = props.animationDuration;
        panel.querySelector('#image-animation-delay').value = props.animationDelay;
        panel.querySelector('#image-filter').value = props.filter;
        panel.querySelector('#image-shadow').value = props.shadow;
        panel.querySelector('#background-removal').checked = props.backgroundRemoval;
        panel.querySelector('#preserve-aspect-ratio').checked = props.preserveAspectRatio;
        panel.querySelector('#image-blend-mode').value = props.blendMode;

        // Update value displays
        this.updateAllValueDisplays(panel);

        // Change button to update mode
        const addBtn = panel.querySelector('#add-image-display-btn');
        addBtn.textContent = '💾 Update Image';
        addBtn.onclick = () => this.updateImage(imageId);

        this.currentEditingImageId = imageId;
        this.updatePreview();
    }

    updateAllValueDisplays(panel) {
        // Trigger input events to update all displays
        const inputs = panel.querySelectorAll('input[type="range"]');
        inputs.forEach(input => {
            input.dispatchEvent(new Event('input'));
        });
    }

    updateImage(imageId) {
        const panel = document.getElementById('image-control-panel');
        if (!panel) return;

        const properties = this.getImagePropertiesFromPanel(panel);
        const imageData = this.activeImages.get(imageId);
        
        if (imageData) {
            // Update element
            imageData.element.src = properties.src;
            this.applyImageStyle(imageData.element, properties);
            
            // Update stored properties
            imageData.properties = { ...properties };
            
            // Record the update
            if (this.recorderManager) {
                this.recorderManager.logEvent('update-image', [imageId, properties]);
            }
            
            this.updateActiveImagesList();
        }

        // Reset button
        const addBtn = panel.querySelector('#add-image-display-btn');
        addBtn.textContent = '➕ Add Image';
        addBtn.onclick = () => this.addImageDisplay();
        this.currentEditingImageId = null;
    }

    toggleImageVisibility(imageId) {
        const imageData = this.activeImages.get(imageId);
        if (!imageData) return;

        imageData.isVisible = !imageData.isVisible;
        imageData.element.style.display = imageData.isVisible ? 'block' : 'none';
        
        // Record the toggle
        if (this.recorderManager) {
            this.recorderManager.logEvent('toggle-image', [imageId, imageData.isVisible]);
        }
        
        this.updateActiveImagesList();
    }

    removeImage(imageId) {
        const imageData = this.activeImages.get(imageId);
        if (!imageData) return;

        imageData.element.remove();
        this.activeImages.delete(imageId);
        
        // Record the removal
        if (this.recorderManager) {
            this.recorderManager.logEvent('remove-image', [imageId]);
        }
        
        this.updateActiveImagesList();
    }

    clearAllImages() {
        this.activeImages.forEach((imageData, imageId) => {
            imageData.element.remove();
        });
        this.activeImages.clear();
        
        // Record the clear
        if (this.recorderManager) {
            this.recorderManager.logEvent('clear-all-images', []);
        }
        
        this.updateActiveImagesList();
    }

    saveImagePreset() {
        const panel = document.getElementById('image-control-panel');
        if (!panel) return;

        const properties = this.getImagePropertiesFromPanel(panel);
        const preset = {
            version: '1.0',
            created: new Date().toISOString(),
            properties: properties
        };

        const blob = new Blob([JSON.stringify(preset, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `image-preset-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        URL.revokeObjectURL(url);
    }

    loadImagePreset() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const preset = JSON.parse(e.target.result);
                    if (preset.properties) {
                        this.applyImagePreset(preset.properties);
                    }
                } catch (error) {
                    console.error('Failed to load image preset:', error);
                }
            };
            reader.readAsText(file);
        });
        input.click();
    }

    applyImagePreset(properties) {
        const panel = document.getElementById('image-control-panel');
        if (!panel) return;

        // Apply properties to panel
        Object.keys(properties).forEach(key => {
            const element = panel.querySelector(`#image-${key.replace(/([A-Z])/g, '-$1').toLowerCase()}`);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = properties[key];
                } else {
                    element.value = properties[key];
                }
                element.dispatchEvent(new Event('input'));
            }
        });

        this.updatePreview();
    }

    closeImageControlPanel() {
        const panel = document.getElementById('image-control-panel');
        if (panel) {
            panel.remove();
        }
        this.isImageControlPanelOpen = false;
        this.currentEditingImageId = null;
    }

    // Public methods for recorder integration
    addImageFromRecording(imageId, properties) {
        const customId = imageId || `image-${this.imageIdCounter++}`;
        
        const imageElement = document.createElement('img');
        imageElement.id = customId;
        imageElement.className = 'image-display-element';
        imageElement.src = properties.src;
        
        this.applyImageStyle(imageElement, properties);
        
        if (properties.animation && properties.animation !== 'none') {
            this.applyAnimation(imageElement, properties);
        }
        
        document.body.appendChild(imageElement);
        
        this.activeImages.set(customId, {
            element: imageElement,
            properties: { ...properties },
            isVisible: true
        });
        
        if (properties.displayTime > 0) {
            setTimeout(() => {
                if (imageElement.parentNode && this.activeImages.has(customId)) {
                    imageElement.remove();
                    this.activeImages.delete(customId);
                    this.updateActiveImagesList();
                }
            }, properties.displayTime);
        }
        
        this.updateActiveImagesList();
    }

    updateImageFromRecording(imageId, properties) {
        const imageData = this.activeImages.get(imageId);
        if (!imageData) return;

        imageData.element.src = properties.src;
        this.applyImageStyle(imageData.element, properties);
        imageData.properties = { ...properties };
        this.updateActiveImagesList();
    }

    toggleImageFromRecording(imageId, isVisible) {
        const imageData = this.activeImages.get(imageId);
        if (!imageData) return;

        imageData.isVisible = isVisible;
        imageData.element.style.display = isVisible ? 'block' : 'none';
        this.updateActiveImagesList();
    }

    removeImageFromRecording(imageId) {
        const imageData = this.activeImages.get(imageId);
        if (!imageData) return;

        imageData.element.remove();
        this.activeImages.delete(imageId);
        this.updateActiveImagesList();
    }

    clearAllImagesFromRecording() {
        this.activeImages.forEach((imageData, imageId) => {
            imageData.element.remove();
        });
        this.activeImages.clear();
        this.updateActiveImagesList();
    }
}