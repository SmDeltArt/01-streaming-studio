export default class ImageDisplayManager {
    constructor(app) {
        this.app = app;
        this.imagePanel = null;
        this.currentImageElement = null;
        /* @tweakable default image display duration in milliseconds */
        this.defaultDisplayDuration = 5000;
        /* @tweakable image fade transition duration */
        this.imageFadeTransition = 500;
        /* @tweakable maximum simultaneous image displays */
        this.maxSimultaneousImages = 3;
        
        this.activeImages = [];
        this.isDragging = false;
        this.dragOffset = { x: 0, y: 0 };
        this.currentSettings = this.getDefaultSettings();
        this.currentImageData = null;
        this.currentSoundData = null;
        
        /* @tweakable audio playback tracking variables */
        this.currentAudio = null;
        this.audioProgressInterval = null;
        this.audioMetadata = null;
        
        this.initializeElements();
        this.bindEvents();
        this.setupDragging();
    }
    
    initializeElements() {
        this.imageBtn = document.getElementById('imageBtn');
        this.imagePanel = document.getElementById('imageDisplayPanel');
        this.imagePanelCollapse = document.getElementById('imagePanelCollapse');
        this.imagePanelClose = document.getElementById('imagePanelClose');
        
        // Source controls
        this.imageFileInput = document.getElementById('imageFileInput');
        this.imageFileBrowse = document.getElementById('imageFileBrowse');
        this.imageUrlInput = document.getElementById('imageUrlInput');
        this.imagePreview = document.getElementById('imagePreview');
        
        // Size & Position controls
        this.imageWidth = document.getElementById('imageWidth');
        this.widthValue = document.getElementById('widthValue');
        this.imageHeight = document.getElementById('imageHeight');
        this.heightValue = document.getElementById('heightValue');
        this.imagePosition = document.getElementById('imagePosition');
        this.imageScale = document.getElementById('imageScale');
        this.scaleValue = document.getElementById('scaleValue');
        this.imageRotation = document.getElementById('imageRotation');
        this.rotationValue = document.getElementById('rotationValue');
        this.imageDisplayTime = document.getElementById('imageDisplayTime');
        this.imageDisplayTimeValue = document.getElementById('imageDisplayTimeValue');
        
        // Appearance controls
        this.imageOpacity = document.getElementById('imageOpacity');
        this.opacityValue = document.getElementById('opacityValue');
        this.imageBorderRadius = document.getElementById('imageBorderRadius');
        this.imageBorderRadiusValue = document.getElementById('imageBorderRadiusValue');
        this.imageShadowBlur = document.getElementById('imageShadowBlur');
        this.imageShadowBlurValue = document.getElementById('imageShadowBlurValue');
        this.imageBorderWidth = document.getElementById('imageBorderWidth');
        this.imageBorderWidthValue = document.getElementById('imageBorderWidthValue');
        this.imageBorderColor = document.getElementById('imageBorderColor');
        
        // Effects controls
        this.imageBlur = document.getElementById('imageBlur');
        this.imageBlurValue = document.getElementById('imageBlurValue');
        this.imageBrightness = document.getElementById('imageBrightness');
        this.imageBrightnessValue = document.getElementById('imageBrightnessValue');
        this.imageContrast = document.getElementById('imageContrast');
        this.imageContrastValue = document.getElementById('imageContrastValue');
        this.imageSaturation = document.getElementById('imageSaturation');
        this.imageSaturationValue = document.getElementById('imageSaturationValue');
        this.imageHueRotate = document.getElementById('imageHueRotate');
        this.imageHueRotateValue = document.getElementById('imageHueRotateValue');
        this.imageGrayscale = document.getElementById('imageGrayscale');
        this.imageGrayscaleValue = document.getElementById('imageGrayscaleValue');
        
        // Animation controls
        this.imageAnimation = document.getElementById('imageAnimation');
        
        // Sound controls
        this.imageSoundInput = document.getElementById('imageSoundInput');
        this.imageSoundBrowse = document.getElementById('imageSoundBrowse');
        this.imageSoundInfo = document.getElementById('imageSoundInfo');
        this.imageSoundVolume = document.getElementById('imageSoundVolume');
        this.imageSoundVolumeValue = document.getElementById('imageSoundVolumeValue');
        this.imageSoundLoop = document.getElementById('imageSoundLoop');
        /* @tweakable enhanced null safety checks for sound control elements to prevent undefined property errors */
        this.imageSoundProgress = document.getElementById('imageSoundProgress') || null;
        this.imageSoundDuration = document.getElementById('imageSoundDuration') || null;
        this.imageSoundMaxDuration = document.getElementById('imageSoundMaxDuration') || null;
        this.imageSoundMaxDurationValue = document.getElementById('imageSoundMaxDurationValue') || null;
        this.imageSoundStop = document.getElementById('imageSoundStop') || null;
        
        // Action buttons
        this.showImageBtn = document.getElementById('showImageBtn');
        this.previewImageBtn = document.getElementById('previewImageBtn');
        this.saveImageBtn = document.getElementById('saveImageBtn');
        this.loadImageBtn = document.getElementById('loadImageBtn');
        this.removeImageBtn = document.getElementById('removeImageBtn');
    }
    
    bindEvents() {
        this.imageBtn.addEventListener('click', () => this.togglePanel());
        this.imagePanelCollapse.addEventListener('click', () => this.toggleCollapse());
        this.imagePanelClose.addEventListener('click', () => this.hidePanel());
        
        // Source events
        this.imageFileBrowse.addEventListener('click', () => this.imageFileInput.click());
        this.imageFileInput.addEventListener('change', (e) => this.handleFileSelection(e));
        this.imageUrlInput.addEventListener('input', () => this.handleUrlInput());
        
        // Size & Position events
        this.imageWidth.addEventListener('input', () => {
            this.widthValue.textContent = this.imageWidth.value + 'px';
            /* @tweakable automatic height adjustment to maintain aspect ratio when width changes */
            if (this.currentImageData && this.currentImageData.aspectRatio) {
                const newHeight = Math.round(parseInt(this.imageWidth.value) / this.currentImageData.aspectRatio);
                this.imageHeight.value = newHeight;
                this.heightValue.textContent = newHeight + 'px';
            }
            this.updatePreview();
        });
        this.imageHeight.addEventListener('input', () => {
            this.heightValue.textContent = this.imageHeight.value + 'px';
            /* @tweakable automatic width adjustment to maintain aspect ratio when height changes */
            if (this.currentImageData && this.currentImageData.aspectRatio) {
                const newWidth = Math.round(parseInt(this.imageHeight.value) * this.currentImageData.aspectRatio);
                this.imageWidth.value = newWidth;
                this.widthValue.textContent = newWidth + 'px';
            }
            this.updatePreview();
        });
        this.imageScale.addEventListener('input', () => {
            this.scaleValue.textContent = this.imageScale.value + '%';
            this.updatePreview();
        });
        this.imageRotation.addEventListener('input', () => {
            this.rotationValue.textContent = this.imageRotation.value + '°';
            this.updatePreview();
        });
        this.imageDisplayTime.addEventListener('input', () => {
            this.imageDisplayTimeValue.textContent = this.imageDisplayTime.value + 's';
        });
        
        // Appearance events
        this.imageOpacity.addEventListener('input', () => {
            this.opacityValue.textContent = this.imageOpacity.value + '%';
            this.updatePreview();
        });
        this.imageBorderRadius.addEventListener('input', () => {
            this.imageBorderRadiusValue.textContent = this.imageBorderRadius.value + 'px';
            this.updatePreview();
        });
        this.imageShadowBlur.addEventListener('input', () => {
            this.imageShadowBlurValue.textContent = this.imageShadowBlur.value + 'px';
            this.updatePreview();
        });
        this.imageBorderWidth.addEventListener('input', () => {
            this.imageBorderWidthValue.textContent = this.imageBorderWidth.value + 'px';
            this.updatePreview();
        });
        
        // Effects events
        this.imageBlur.addEventListener('input', () => {
            this.imageBlurValue.textContent = this.imageBlur.value + 'px';
            this.updatePreview();
        });
        this.imageBrightness.addEventListener('input', () => {
            this.imageBrightnessValue.textContent = this.imageBrightness.value + '%';
            this.updatePreview();
        });
        this.imageContrast.addEventListener('input', () => {
            this.imageContrastValue.textContent = this.imageContrast.value + '%';
            this.updatePreview();
        });
        this.imageSaturation.addEventListener('input', () => {
            this.imageSaturationValue.textContent = this.imageSaturation.value + '%';
            this.updatePreview();
        });
        this.imageHueRotate.addEventListener('input', () => {
            this.imageHueRotateValue.textContent = this.imageHueRotate.value + '°';
            this.updatePreview();
        });
        this.imageGrayscale.addEventListener('input', () => {
            this.imageGrayscaleValue.textContent = this.imageGrayscale.value + '%';
            this.updatePreview();
        });
        
        // Sound events
        this.imageSoundBrowse.addEventListener('click', () => this.imageSoundInput.click());
        this.imageSoundInput.addEventListener('change', (e) => this.handleSoundSelection(e));
        
        /* @tweakable volume control with real-time audio adjustment */
        this.imageSoundVolume.addEventListener('input', () => {
            this.imageSoundVolumeValue.textContent = this.imageSoundVolume.value + '%';
            
            // Apply volume change to currently playing audio in real-time
            if (this.currentAudio && !this.currentAudio.paused) {
                this.currentAudio.volume = Math.max(0, Math.min(1, parseInt(this.imageSoundVolume.value) / 100));
            }
        });
        
        /* @tweakable functional progress bar for audio seeking */
        if (this.imageSoundProgress) {
            this.imageSoundProgress.addEventListener('input', () => this.seekAudio());
            this.imageSoundProgress.addEventListener('change', () => this.seekAudio());
        }
        
        /* @tweakable enhanced sound control events with null safety checks to prevent undefined errors */
        if (this.imageSoundMaxDuration && this.imageSoundMaxDurationValue) {
            this.imageSoundMaxDuration.addEventListener('input', () => {
                this.imageSoundMaxDurationValue.textContent = this.imageSoundMaxDuration.value + 's';
            });
        }
        
        if (this.imageSoundStop) {
            this.imageSoundStop.addEventListener('click', () => this.stopCurrentAudio());
        }
        
        // Change events for preview update
        [this.imagePosition, this.imageAnimation, this.imageBorderColor].forEach(element => {
            element.addEventListener('change', () => this.updatePreview());
        });
        
        // Action buttons
        this.showImageBtn.addEventListener('click', () => this.showImage());
        this.previewImageBtn.addEventListener('click', () => this.previewImage());
        this.saveImageBtn.addEventListener('click', () => this.saveSettings());
        this.loadImageBtn.addEventListener('click', () => this.loadSettings());
        this.removeImageBtn.addEventListener('click', () => this.removeAllImages());
        
        // Keyboard shortcut
        document.addEventListener('keydown', (e) => {
            if (e.key.toLowerCase() === 'i' && !e.target.matches('input, textarea, select')) {
                this.togglePanel();
                e.preventDefault();
            }
        });
    }
    
    setupDragging() {
        const header = this.imagePanel.querySelector('.image-panel-header');
        let isDragging = false;
        let startX, startY, initialX, initialY;
        
        header.addEventListener('mousedown', (e) => {
            isDragging = true;
            this.imagePanel.classList.add('dragging');
            
            startX = e.clientX;
            startY = e.clientY;
            
            const rect = this.imagePanel.getBoundingClientRect();
            initialX = rect.left;
            initialY = rect.top;
            
            e.preventDefault();
        });
        
        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            
            const deltaX = e.clientX - startX;
            const deltaY = e.clientY - startY;
            
            let newX = initialX + deltaX;
            let newY = initialY + deltaY;
            
            /* @tweakable boundaries for image panel dragging - allow 95% off-screen */
            const panelRect = this.imagePanel.getBoundingClientRect();
            const minVisibleArea = Math.min(panelRect.width, panelRect.height) * 0.05; // 5% must stay visible
            
            newX = Math.max(-panelRect.width + minVisibleArea, 
                           Math.min(newX, window.innerWidth - minVisibleArea));
            newY = Math.max(-panelRect.height + minVisibleArea, 
                           Math.min(newY, window.innerHeight - minVisibleArea));
            
            this.imagePanel.style.left = `${newX}px`;
            this.imagePanel.style.top = `${newY}px`;
            this.imagePanel.style.transform = 'none';
        });
        
        document.addEventListener('mouseup', () => {
            if (isDragging) {
                isDragging = false;
                this.imagePanel.classList.remove('dragging');
            }
        });
    }
    
    /* @tweakable method to handle file selection for images and media */
    async handleFileSelection(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        try {
            /* @tweakable supported file types and size limits */
            const maxFileSize = 50 * 1024 * 1024; // 50MB limit
            const supportedImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
            const supportedVideoTypes = ['video/mp4', 'video/webm', 'video/ogg'];
            const supportedAudioTypes = ['audio/mp3', 'audio/wav', 'audio/ogg', 'audio/aac'];
            
            if (file.size > maxFileSize) {
                alert('File size too large. Maximum allowed size is 50MB.');
                return;
            }
            
            const fileType = file.type;
            const isImage = supportedImageTypes.includes(fileType);
            const isVideo = supportedVideoTypes.includes(fileType);
            const isAudio = supportedAudioTypes.includes(fileType);
            
            if (!isImage && !isVideo && !isAudio) {
                alert('Unsupported file type. Please select an image, video, or audio file.');
                return;
            }
            
            const reader = new FileReader();
            reader.onload = async (e) => {
                this.currentImageData = {
                    type: fileType,
                    data: e.target.result,
                    name: file.name,
                    size: file.size
                };
                
                /* @tweakable automatic dimension detection and aspect ratio preservation */
                if (isImage) {
                    try {
                        const dimensions = await this.extractImageDimensions(e.target.result);
                        if (dimensions.width && dimensions.height) {
                            this.currentImageData.originalWidth = dimensions.width;
                            this.currentImageData.originalHeight = dimensions.height;
                            this.currentImageData.aspectRatio = dimensions.width / dimensions.height;
                            
                            // Auto-adjust dimensions maintaining aspect ratio
                            this.adjustImageDimensionsToAspectRatio(dimensions.width, dimensions.height);
                            
                            console.log(`Image loaded: ${dimensions.width}x${dimensions.height} (ratio: ${dimensions.width / dimensions.height})`);
                        }
                    } catch (error) {
                        console.warn('Could not extract image dimensions:', error);
                    }
                } else if (isVideo) {
                    try {
                        const dimensions = await this.extractVideoDimensions(e.target.result);
                        if (dimensions.width && dimensions.height) {
                            this.currentImageData.originalWidth = dimensions.width;
                            this.currentImageData.originalHeight = dimensions.height;
                            this.currentImageData.aspectRatio = dimensions.width / dimensions.height;
                            
                            this.adjustImageDimensionsToAspectRatio(dimensions.width, dimensions.height);
                            
                            console.log(`Video loaded: ${dimensions.width}x${dimensions.height} (ratio: ${dimensions.width / dimensions.height})`);
                        }
                    } catch (error) {
                        console.warn('Could not extract video dimensions:', error);
                    }
                }
                
                this.updateImagePreview();
                console.log(`Loaded ${isImage ? 'image' : isVideo ? 'video' : 'audio'}: ${file.name}`);
            };
            
            reader.readAsDataURL(file);
            
        } catch (error) {
            console.error('Error handling file selection:', error);
            alert('Error loading file: ' + error.message);
        }
    }
    
    /* @tweakable method to handle URL input for images */
    async handleUrlInput() {
        const url = this.imageUrlInput.value.trim();
        if (!url) {
            this.currentImageData = null;
            this.updateImagePreview();
            return;
        }
        
        try {
            // Validate URL format
            new URL(url);
            
            this.currentImageData = {
                type: 'url',
                data: url,
                name: url.split('/').pop() || 'Web Image',
                size: 0
            };
            
            this.updateImagePreview();
            
        } catch (error) {
            console.warn('Invalid URL format:', error);
        }
    }
    
    /* @tweakable method to update media preview with aspect ratio preservation */
    updateMediaPreview() {
        if (!this.currentMediaData) {
            this.mediaPreview.innerHTML = 'No media selected';
            return;
        }
        
        const { type, data, name, isVideo, isAudio } = this.currentMediaData;
        this.mediaPreview.innerHTML = '';
        
        if (isVideo) {
            const video = document.createElement('video');
            video.src = data;
            video.controls = true;
            video.muted = true;
            video.style.maxWidth = '100%';
            video.style.maxHeight = '100%';
            
            /* @tweakable aspect ratio preservation for video preview */
            if (this.preserveAspectRatio.checked && this.currentMediaData.aspectRatio) {
                video.style.aspectRatio = this.currentMediaData.aspectRatio;
                video.style.objectFit = 'contain';
            }
            
            this.mediaPreview.appendChild(video);
            
            // Add media info overlay
            const mediaInfo = document.createElement('div');
            mediaInfo.className = 'media-info';
            mediaInfo.textContent = `📹 ${name} (${this.formatFileSize(this.currentMediaData.size)})`;
            this.mediaPreview.appendChild(mediaInfo);
            
        } else if (isAudio) {
            const audioContainer = document.createElement('div');
            audioContainer.style.display = 'flex';
            audioContainer.style.flexDirection = 'column';
            audioContainer.style.alignItems = 'center';
            audioContainer.style.justifyContent = 'center';
            audioContainer.style.height = '100%';
            audioContainer.innerHTML = `
                <div style="font-size: 24px; margin-bottom: 10px;">🎵</div>
                <audio controls style="width: 90%;">
                    <source src="${data}" type="${type}">
                </audio>
            `;
            this.mediaPreview.appendChild(audioContainer);
            
            // Add media info
            const mediaInfo = document.createElement('div');
            mediaInfo.className = 'media-info';
            mediaInfo.textContent = `🎵 ${name} (${this.formatFileSize(this.currentMediaData.size)})`;
            this.mediaPreview.appendChild(mediaInfo);
        }
    }
    
    /* @tweakable method to extract audio metadata including duration */
    async extractAudioMetadata(audioDataUrl) {
        return new Promise((resolve, reject) => {
            const audio = new Audio();
            
            audio.onloadedmetadata = () => {
                const metadata = {
                    duration: audio.duration || 0,
                    sampleRate: audio.sampleRate || null,
                    channels: audio.channels || null
                };
                resolve(metadata);
            };
            
            audio.onerror = () => {
                reject(new Error('Failed to load audio metadata'));
            };
            
            /* @tweakable metadata extraction timeout */
            setTimeout(() => {
                reject(new Error('Audio metadata extraction timeout'));
            }, 5000);
            
            audio.src = audioDataUrl;
        });
    }
    
    /* @tweakable simplified method to update sound information without progress tracking */
    updateSoundInfo() {
        if (!this.imageSoundInfo) return;
        
        if (!this.currentSoundData) {
            this.imageSoundInfo.textContent = 'No sound selected';
            return;
        }
        
        let infoText = `🔊 ${this.currentSoundData.name} (${this.formatFileSize(this.currentSoundData.size)})`;
        
        if (this.audioMetadata && this.audioMetadata.duration > 0) {
            const duration = Math.ceil(this.audioMetadata.duration);
            infoText += ` - ${this.formatDuration(duration)}`;
        }
        
        this.imageSoundInfo.textContent = infoText;
    }
    
    /* @tweakable improved audio seeking with proper progress bar functionality */
    seekAudio() {
        if (this.currentAudio && this.imageSoundProgress && this.currentAudio.duration && !isNaN(this.currentAudio.duration)) {
            const seekPosition = parseFloat(this.imageSoundProgress.value) / 100;
            const newTime = seekPosition * this.currentAudio.duration;
            
            try {
                this.currentAudio.currentTime = Math.max(0, Math.min(newTime, this.currentAudio.duration));
                console.log(`Audio seeked to ${Math.floor(newTime)}s (${Math.floor(seekPosition * 100)}%)`);
            } catch (error) {
                console.warn('Error seeking audio:', error);
            }
        }
    }
    
    /* @tweakable enhanced progress tracking with real-time updates and proper duration display */
    setupProgressTracking(audio) {
        if (!this.imageSoundProgress || !this.imageSoundDuration || !audio) return;
        
        this.clearProgressTracking();
        
        /* @tweakable progress update interval for smooth progress bar movement */
        const progressUpdateInterval = 200;
        
        // Wait for audio metadata to load
        const startTracking = () => {
            if (audio.duration && !isNaN(audio.duration) && audio.duration > 0) {
                this.audioProgressInterval = setInterval(() => {
                    if (audio.duration > 0 && this.imageSoundProgress && this.imageSoundDuration && !audio.paused) {
                        const progress = (audio.currentTime / audio.duration) * 100;
                        
                        /* @tweakable prevent progress bar conflicts during user interaction */
                        if (!this.imageSoundProgress.matches(':active')) {
                            this.imageSoundProgress.value = Math.min(100, Math.max(0, progress));
                        }
                        
                        const currentTime = Math.floor(audio.currentTime);
                        const totalTime = Math.floor(audio.duration);
                        this.imageSoundDuration.textContent = `${this.formatDuration(currentTime)} / ${this.formatDuration(totalTime)}`;
                    }
                }, progressUpdateInterval);
            }
        };
        
        if (audio.readyState >= 1) {
            startTracking();
        } else {
            audio.addEventListener('loadedmetadata', startTracking, { once: true });
        }
        
        /* @tweakable audio end event handling with progress reset */
        audio.addEventListener('ended', () => {
            this.clearProgressTracking();
            if (this.imageSoundProgress) {
                this.imageSoundProgress.value = 0;
            }
            if (this.imageSoundDuration && audio.duration) {
                const totalTime = Math.floor(audio.duration);
                this.imageSoundDuration.textContent = `0:00 / ${this.formatDuration(totalTime)}`;
            }
        });
        
        /* @tweakable audio pause/play event handling for progress tracking */
        audio.addEventListener('pause', () => {
            // Keep tracking even when paused to maintain current position display
        });
        
        audio.addEventListener('play', () => {
            if (!this.audioProgressInterval) {
                startTracking();
            }
        });
    }
    
    /* @tweakable method to clear progress tracking interval */
    clearProgressTracking() {
        if (this.audioProgressInterval) {
            clearInterval(this.audioProgressInterval);
            this.audioProgressInterval = null;
        }
    }
    
    updateImagePreview() {
        if (!this.currentImageData) {
            this.imagePreview.innerHTML = 'No image selected';
            return;
        }
        
        const { type, data, name } = this.currentImageData;
        
        if (type.startsWith('image/')) {
            const img = document.createElement('img');
            img.src = data;
            img.alt = name;
            this.imagePreview.innerHTML = '';
            this.imagePreview.appendChild(img);
        } else if (type.startsWith('video/')) {
            const video = document.createElement('video');
            video.src = data;
            video.controls = true;
            video.muted = true;
            this.imagePreview.innerHTML = '';
            this.imagePreview.appendChild(video);
        } else if (type.startsWith('audio/')) {
            this.imagePreview.innerHTML = `🎵 ${name}<br><small>Audio file loaded</small>`;
        } else if (type === 'url') {
            const img = document.createElement('img');
            img.src = data;
            img.alt = name;
            img.onerror = () => {
                this.imagePreview.innerHTML = `❌ Failed to load image from URL<br><small>${data}</small>`;
            };
            this.imagePreview.innerHTML = '';
            this.imagePreview.appendChild(img);
        }
        
        this.updatePreview();
    }
    
    updatePreview() {
        if (!this.currentImageData) return;
        
        const settings = this.getCurrentSettings();
        const preview = this.imagePreview.querySelector('img, video');
        
        if (preview) {
            /* @tweakable preview styling to match actual display settings */
            preview.style.width = Math.min(parseInt(settings.width), 300) + 'px';
            preview.style.height = Math.min(parseInt(settings.height), 200) + 'px';
            preview.style.opacity = settings.opacity / 100;
            preview.style.borderRadius = settings.borderRadius + 'px';
            preview.style.transform = `scale(${Math.min(settings.scale / 100, 1.5)}) rotate(${settings.rotation}deg)`;
            
            if (settings.borderWidth > 0) {
                preview.style.border = `${settings.borderWidth}px solid ${settings.borderColor}`;
            }
            
            // Apply filters
            const filters = [];
            if (settings.blur > 0) filters.push(`blur(${settings.blur}px)`);
            if (settings.brightness !== 100) filters.push(`brightness(${settings.brightness}%)`);
            if (settings.contrast !== 100) filters.push(`contrast(${settings.contrast}%)`);
            if (settings.saturation !== 100) filters.push(`saturate(${settings.saturation}%)`);
            if (settings.hueRotate > 0) filters.push(`hue-rotate(${settings.hueRotate}deg)`);
            if (settings.grayscale > 0) filters.push(`grayscale(${settings.grayscale}%)`);
            
            preview.style.filter = filters.join(' ');
            
            if (settings.shadowBlur > 0) {
                preview.style.boxShadow = `0 ${settings.shadowBlur}px ${settings.shadowBlur * 2}px rgba(0, 0, 0, 0.3)`;
            }
        }
    }
    
    getDefaultSettings() {
        return {
            source: '',
            position: 'center',
            width: 300,
            height: 200,
            scale: 100,
            rotation: 0,
            displayTime: 5,
            opacity: 100,
            borderRadius: 8,
            shadowBlur: 10,
            borderWidth: 0,
            borderColor: '#ffffff',
            blur: 0,
            brightness: 100,
            contrast: 100,
            saturation: 100,
            hueRotate: 0,
            grayscale: 0,
            animation: 'fade',
            soundVolume: 70,
            soundLoop: false
        };
    }
    
    getCurrentSettings() {
        return {
            source: this.currentImageData,
            position: this.imagePosition.value,
            width: parseInt(this.imageWidth.value),
            height: parseInt(this.imageHeight.value),
            scale: parseInt(this.imageScale.value),
            rotation: parseInt(this.imageRotation.value),
            displayTime: parseInt(this.imageDisplayTime.value),
            opacity: parseInt(this.imageOpacity.value),
            borderRadius: parseInt(this.imageBorderRadius.value),
            shadowBlur: parseInt(this.imageShadowBlur.value),
            borderWidth: parseInt(this.imageBorderWidth.value),
            borderColor: this.imageBorderColor.value,
            blur: parseInt(this.imageBlur.value),
            brightness: parseInt(this.imageBrightness.value),
            contrast: parseInt(this.imageContrast.value),
            saturation: parseInt(this.imageSaturation.value),
            hueRotate: parseInt(this.imageHueRotate.value),
            grayscale: parseInt(this.imageGrayscale.value),
            animation: this.imageAnimation.value,
            soundVolume: parseInt(this.imageSoundVolume.value),
            soundLoop: this.imageSoundLoop.checked,
            sound: this.currentSoundData
        };
    }
    
    togglePanel() {
        if (this.imagePanel.style.display === 'block') {
            this.hidePanel();
        } else {
            this.showPanel();
        }
    }
    
    showPanel() {
        this.imagePanel.style.display = 'block';
        this.updatePreview();
    }
    
    hidePanel() {
        this.imagePanel.style.display = 'none';
    }
    
    toggleCollapse() {
        const isCollapsed = this.imagePanel.classList.contains('collapsed');
        if (isCollapsed) {
            this.imagePanel.classList.remove('collapsed');
            this.imagePanelCollapse.textContent = '−';
        } else {
            this.imagePanel.classList.add('collapsed');
            this.imagePanelCollapse.textContent = '+';
        }
    }
    
    showImage() {
        const settings = this.getCurrentSettings();
        if (!settings.source) {
            alert('Please select an image or enter an image URL');
            return;
        }
        
        this.displayImage(settings);
    }
    
    /* @tweakable enhanced video sound synchronization during display */
    displayImage(settings) {
        // Remove oldest image if at maximum
        if (this.activeImages.length >= this.maxSimultaneousImages) {
            const oldestImage = this.activeImages.shift();
            if (oldestImage && oldestImage.parentNode) {
                // Stop any associated audio
                if (oldestImage.associatedAudio) {
                    this.stopAssociatedAudio(oldestImage.associatedAudio);
                }
                oldestImage.remove();
            }
        }
        
        const imageElement = document.createElement('div');
        imageElement.className = 'image-display-element';
        
        // Create media element based on type
        let mediaElement;
        const sourceData = settings.source;
        let actualDisplayTime = settings.displayTime;
        let audioElement = null;
        
        if (!sourceData) {
            console.warn('No source data available for display');
            return;
        }
        
        const { type, data, isVideo, isAudio } = sourceData;
        
        if (type.startsWith('image/') || type === 'url') {
            mediaElement = document.createElement('img');
            mediaElement.src = data;
        } else if (type.startsWith('video/') || isVideo) {
            mediaElement = document.createElement('video');
            mediaElement.src = data;
            mediaElement.autoplay = true;
            /* @tweakable video sound enabled for display synchronization */
            mediaElement.muted = false; // Enable sound for videos
            mediaElement.loop = false; // No looping
            
            /* @tweakable video volume control synchronized with settings */
            mediaElement.volume = Math.max(0, Math.min(1, (settings.soundVolume || 70) / 100));
            
            /* @tweakable video aspect ratio preservation */
            if (sourceData.aspectRatio) {
                mediaElement.style.aspectRatio = sourceData.aspectRatio;
                mediaElement.style.objectFit = 'contain';
            }
            
        } else if (type.startsWith('audio/') || isAudio) {
            mediaElement = document.createElement('div');
            mediaElement.innerHTML = `🎵 ${sourceData.name}`;
            mediaElement.style.display = 'flex';
            mediaElement.style.alignItems = 'center';
            mediaElement.style.justifyContent = 'center';
            mediaElement.style.fontSize = '24px';
            mediaElement.style.background = 'rgba(0, 0, 0, 0.8)';
            mediaElement.style.color = 'white';
            
            // Create audio element for playback
            audioElement = new Audio(data);
            audioElement.volume = settings.soundVolume / 100;
            audioElement.loop = false;
            
            imageElement.associatedAudio = audioElement;
            
            audioElement.play().catch(error => {
                console.warn('Audio autoplay prevented:', error);
                document.addEventListener('click', () => {
                    audioElement.play().catch(e => console.warn('Manual audio play failed:', e));
                }, { once: true });
            });
        }
        
        // Apply styling
        mediaElement.style.width = settings.width + 'px';
        mediaElement.style.height = settings.height + 'px';
        mediaElement.style.opacity = settings.opacity / 100;
        mediaElement.style.borderRadius = settings.borderRadius + 'px';
        mediaElement.style.transform = `scale(${settings.scale / 100}) rotate(${settings.rotation}deg)`;
        
        if (settings.borderWidth > 0) {
            mediaElement.style.border = `${settings.borderWidth}px solid ${settings.borderColor}`;
        }
        
        // Apply filters
        const filters = [];
        if (settings.blur > 0) filters.push(`blur(${settings.blur}px)`);
        if (settings.brightness !== 100) filters.push(`brightness(${settings.brightness}%)`);
        if (settings.contrast !== 100) filters.push(`contrast(${settings.contrast}%)`);
        if (settings.saturation !== 100) filters.push(`saturate(${settings.saturation}%)`);
        if (settings.hueRotate > 0) filters.push(`hue-rotate(${settings.hueRotate}deg)`);
        if (settings.grayscale > 0) filters.push(`grayscale(${settings.grayscale}%)`);
        
        if (filters.length > 0) {
            mediaElement.style.filter = filters.join(' ');
        }
        
        if (settings.shadowBlur > 0) {
            mediaElement.style.boxShadow = `0 ${settings.shadowBlur}px ${settings.shadowBlur * 2}px rgba(0, 0, 0, 0.3)`;
        }
        
        imageElement.appendChild(mediaElement);
        
        // Position the media element
        this.positionImage(imageElement, settings.position);
        
        // Add animation class and custom properties
        if (settings.animation !== 'none') {
            imageElement.classList.add(settings.animation);
            imageElement.style.setProperty('--display-time', `${actualDisplayTime}s`);
        }
        
        // Add to DOM and track
        document.body.appendChild(imageElement);
        this.activeImages.push(imageElement);

        /* @tweakable enhanced active item creation for persistent replay functionality */
        let activeItemId = null;
        if (this.app.uiManager && this.app.uiManager.addActiveItem) {
            const contentDescription = sourceData.name || 'Image';
            
            // Check if this is a replay of an existing item
            const existingItem = this.app.uiManager.activeItems.find(item => 
                item.type === 'image' && 
                item.content === contentDescription && 
                !item.element
            );
            
            if (existingItem) {
                // Update existing item with new element
                existingItem.element = imageElement;
                activeItemId = existingItem.id;
                imageElement.dataset.activeItemId = activeItemId;
                this.app.uiManager.updateActiveItemsDisplay();
            } else {
                // Create new active item
                activeItemId = this.app.uiManager.addActiveItem('image', contentDescription, imageElement, settings);
            }
        }
        
        /* @tweakable sound playback for non-video media synchronized with display time */
        if (settings.sound && !type.startsWith('audio/') && !isAudio && !type.startsWith('video/')) {
            const imageAudio = this.playImageSoundForDuration(settings.sound, settings.soundVolume, actualDisplayTime);
            if (imageAudio) {
                imageElement.associatedAudio = imageAudio;
            }
        }
        
        // Auto-remove after display time
        const displayDuration = actualDisplayTime * 1000;
        const removalTimeout = setTimeout(() => {
            /* @tweakable video sound cleanup when display time ends */
            if (imageElement.associatedAudio) {
                this.stopAssociatedAudio(imageElement.associatedAudio);
            }
            if (audioElement && !audioElement.ended) {
                audioElement.pause();
                audioElement.currentTime = 0;
            }
            // Stop video sound when display time ends
            if (mediaElement.tagName === 'VIDEO') {
                mediaElement.pause();
                mediaElement.currentTime = 0;
            }
            this.removeImageElement(imageElement);
        }, displayDuration);
        
        imageElement.dataset.removalTimeout = removalTimeout;
        
        console.log(`Media displayed for ${actualDisplayTime} seconds`);
    }
    
    /* @tweakable method to play sound synchronized with image display duration only */
    playImageSoundForDuration(soundData, volume, displayDuration) {
        try {
            const audio = new Audio(soundData.data);
            
            /* @tweakable audio playback settings - no looping, duration-limited */
            audio.volume = Math.max(0, Math.min(1, volume / 100));
            audio.loop = false; // Never loop for image display
            
            // Force stop after display duration
            const stopTimeout = setTimeout(() => {
                if (audio && !audio.paused) {
                    audio.pause();
                    audio.currentTime = 0;
                    console.log('Audio stopped after image display duration');
                }
            }, displayDuration * 1000);
            
            // Store timeout reference for cleanup
            audio.stopTimeout = stopTimeout;
            
            // Enhanced error handling for audio playback
            audio.onerror = (error) => {
                console.warn('Image audio playback error:', error);
                if (audio.stopTimeout) {
                    clearTimeout(audio.stopTimeout);
                }
            };
            
            /* @tweakable audio end event handling to prevent unwanted loops */
            audio.addEventListener('ended', () => {
                if (audio.stopTimeout) {
                    clearTimeout(audio.stopTimeout);
                }
                console.log('Image audio playback completed naturally');
            });
            
            /* @tweakable audio loading and play event with progress tracking */
            audio.addEventListener('canplaythrough', () => {
                this.setupProgressTracking(audio);
                audio.play().catch(error => {
                    console.warn('Audio autoplay prevented:', error);
                    // Attempt to play with user interaction context
                    document.addEventListener('click', () => {
                        if (audio) {
                            audio.play().then(() => {
                                this.setupProgressTracking(audio);
                            }).catch(e => console.warn('Manual image audio play failed:', e));
                        }
                    }, { once: true });
                });
            });
            
            audio.load(); // Preload audio
            return audio;
            
        } catch (error) {
            console.error('Error playing image sound for duration:', error);
            return null;
        }
    }
    
    /* @tweakable method to stop associated audio with proper cleanup */
    stopAssociatedAudio(audio) {
        if (audio) {
            try {
                audio.pause();
                audio.currentTime = 0;
                audio.loop = false;
                
                // Clear any timeouts
                if (audio.stopTimeout) {
                    clearTimeout(audio.stopTimeout);
                    audio.stopTimeout = null;
                }
                if (audio.maxDurationTimeout) {
                    clearTimeout(audio.maxDurationTimeout);
                    audio.maxDurationTimeout = null;
                }
                
                // Remove event listeners
                audio.onended = null;
                audio.onerror = null;
                audio.onloadedmetadata = null;
                audio.oncanplaythrough = null;
                
                // Clear source
                audio.src = '';
                audio.load();
                
                console.log('Associated audio stopped and cleaned up');
            } catch (error) {
                console.warn('Error stopping associated audio:', error);
            }
        }
    }
    
    /* @tweakable improved audio playback with progress tracking integration */
    playImageSound(soundData, volume, loop) {
        try {
            // Stop any currently playing audio first
            this.stopCurrentAudio();
            
            const audio = new Audio(soundData.data);
            this.currentAudio = audio;
            
            /* @tweakable proper volume control that works in real-time */
            audio.volume = Math.max(0, Math.min(1, volume / 100));
            audio.loop = false; // Always false to prevent loop issues
            
            // Enhanced error handling for audio playback
            audio.onerror = (error) => {
                console.warn('Audio playback error:', error);
                this.currentAudio = null;
                this.clearProgressTracking();
            };
            
            /* @tweakable audio end event handling - no restart or loop behavior */
            audio.addEventListener('ended', () => {
                this.currentAudio = null;
                this.clearProgressTracking();
                console.log('Audio playback completed - no restart');
            });
            
            /* @tweakable audio loading and play event with progress tracking */
            audio.addEventListener('canplaythrough', () => {
                this.setupProgressTracking(audio);
                audio.play().catch(error => {
                    console.warn('Audio autoplay prevented:', error);
                    // Attempt to play with user interaction context
                    document.addEventListener('click', () => {
                        if (this.currentAudio === audio) {
                            audio.play().then(() => {
                                this.setupProgressTracking(audio);
                            }).catch(e => console.warn('Manual audio play failed:', e));
                        }
                    }, { once: true });
                });
            });
            
            audio.load(); // Preload audio
            
        } catch (error) {
            console.error('Error playing image sound:', error);
        }
    }
    
    positionImage(element, position) {
        element.style.position = 'fixed';
        element.style.zIndex = '15000';
        
        switch (position) {
            case 'top-left':
                element.style.top = '20px';
                element.style.left = '20px';
                break;
            case 'top-center':
                element.style.top = '20px';
                element.style.left = '50%';
                element.style.transform += ' translateX(-50%)';
                break;
            case 'top-right':
                element.style.top = '20px';
                element.style.right = '20px';
                break;
            case 'center':
                element.style.top = '50%';
                element.style.left = '50%';
                element.style.transform += ' translate(-50%, -50%)';
                break;
            case 'bottom-left':
                element.style.bottom = '20px';
                element.style.left = '20px';
                break;
            case 'bottom-center':
                element.style.bottom = '20px';
                element.style.left = '50%';
                element.style.transform += ' translateX(-50%)';
                break;
            case 'bottom-right':
                element.style.bottom = '20px';
                element.style.right = '20px';
                break;
        }
    }
    
    removeImageElement(element) {
        if (element && element.parentNode) {
            // Clear any pending timeout
            if (element.dataset.removalTimeout) {
                clearTimeout(parseInt(element.dataset.removalTimeout));
            }
            
            /* @tweakable cleanup active item when image element is removed */
            if (this.app.uiManager && this.app.uiManager.cleanupActiveItem) {
                this.app.uiManager.cleanupActiveItem(element);
            }
            
            /* @tweakable stop any associated audio when removing image */
            if (element.associatedAudio) {
                this.stopAssociatedAudio(element.associatedAudio);
            }
            
            element.style.transition = `opacity ${this.imageFadeTransition}ms ease-out`;
            element.style.opacity = '0';
            
            setTimeout(() => {
                if (element.parentNode) {
                    element.remove();
                }
                const index = this.activeImages.indexOf(element);
                if (index > -1) {
                    this.activeImages.splice(index, 1);
                }
            }, this.imageFadeTransition);
        }
    }
    
    previewImage() {
        const settings = this.getCurrentSettings();
        if (!settings.source) {
            alert('Please select an image or enter an image URL');
            return;
        }
        
        // Show a temporary preview for 2 seconds
        const tempSettings = { ...settings, displayTime: 2 };
        this.displayImage(tempSettings);
    }
    
    removeAllImages() {
        this.activeImages.forEach(element => {
            if (element.parentNode) {
                // Clear any pending removal timeouts
                if (element.dataset.removalTimeout) {
                    clearTimeout(parseInt(element.dataset.removalTimeout));
                }
                /* @tweakable cleanup associated audio for each image element */
                if (element.associatedAudio) {
                    this.stopAssociatedAudio(element.associatedAudio);
                }
                element.remove();
            }
        });
        this.activeImages = [];
    }
    
    /* @tweakable JSON save/load functionality for image settings */
    saveSettings() {
        const settings = this.getCurrentSettings();
        
        // Prepare settings for JSON (exclude file data for size)
        const exportSettings = { ...settings };
        if (exportSettings.source && exportSettings.source.data) {
            exportSettings.source = {
                ...exportSettings.source,
                data: exportSettings.source.type === 'url' ? exportSettings.source.data : '[FILE_DATA]'
            };
        }
        if (exportSettings.sound && exportSettings.sound.data) {
            exportSettings.sound = {
                ...exportSettings.sound,
                data: '[AUDIO_DATA]'
            };
        }
        
        const dataStr = JSON.stringify(exportSettings, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        
        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        link.download = `image-display-settings-${new Date().toISOString().slice(0, 10)}.json`;
        link.click();
        
        // Clean up
        setTimeout(() => URL.revokeObjectURL(link.href), 100);
    }
    
    loadSettings() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        
        input.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const settings = JSON.parse(e.target.result);
                    this.applySettings(settings);
                    this.updatePreview();
                    alert('Settings loaded successfully!');
                } catch (error) {
                    console.error('Error loading settings:', error);
                    alert('Failed to load settings: Invalid JSON file');
                }
            };
            reader.readAsText(file);
        });
        
        input.click();
    }
    
    applySettings(settings) {
        // Apply source settings (note: file data won't be restored from JSON)
        if (settings.source && settings.source.type === 'url') {
            this.imageUrlInput.value = settings.source.data;
            this.handleUrlInput();
        }
        
        // Apply size & position settings
        this.imagePosition.value = settings.position || 'center';
        this.imageWidth.value = settings.width || 300;
        this.widthValue.textContent = this.imageWidth.value + 'px';
        this.imageHeight.value = settings.height || 200;
        this.heightValue.textContent = this.imageHeight.value + 'px';
        this.imageScale.value = settings.scale || 100;
        this.scaleValue.textContent = this.imageScale.value + '%';
        this.imageRotation.value = settings.rotation || 0;
        this.rotationValue.textContent = this.imageRotation.value + '°';
        this.imageDisplayTime.value = settings.displayTime || 5;
        this.imageDisplayTimeValue.textContent = this.imageDisplayTime.value + 's';
        
        // Apply appearance settings
        this.imageOpacity.value = settings.opacity || 100;
        this.opacityValue.textContent = this.imageOpacity.value + '%';
        this.imageBorderRadius.value = settings.borderRadius || 8;
        this.imageBorderRadiusValue.textContent = this.imageBorderRadius.value + 'px';
        this.imageShadowBlur.value = settings.shadowBlur || 10;
        this.imageShadowBlurValue.textContent = this.imageShadowBlur.value + 'px';
        this.imageBorderWidth.value = settings.borderWidth || 0;
        this.imageBorderWidthValue.textContent = this.imageBorderWidth.value + 'px';
        this.imageBorderColor.value = settings.borderColor || '#ffffff';
        
        // Apply effects settings
        this.imageBlur.value = settings.blur || 0;
        this.imageBlurValue.textContent = this.imageBlur.value + 'px';
        this.imageBrightness.value = settings.brightness || 100;
        this.imageBrightnessValue.textContent = this.imageBrightness.value + '%';
        this.imageContrast.value = settings.contrast || 100;
        this.imageContrastValue.textContent = this.imageContrast.value + '%';
        this.imageSaturation.value = settings.saturation || 100;
        this.imageSaturationValue.textContent = this.imageSaturation.value + '%';
        this.imageHueRotate.value = settings.hueRotate || 0;
        this.imageHueRotateValue.textContent = this.imageHueRotate.value + '°';
        this.imageGrayscale.value = settings.grayscale || 0;
        this.imageGrayscaleValue.textContent = this.imageGrayscale.value + '%';
        
        // Apply animation settings
        this.imageAnimation.value = settings.animation || 'fade';
        
        // Apply sound settings
        this.imageSoundVolume.value = settings.soundVolume || 70;
        this.imageSoundVolumeValue.textContent = this.imageSoundVolume.value + '%';
        this.imageSoundLoop.checked = settings.soundLoop || false;
    }
    
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    /* @tweakable improved method to format duration with better time display */
    formatDuration(seconds) {
        if (!seconds || isNaN(seconds) || seconds < 0) return '0:00';
        
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = Math.floor(seconds % 60);
        
        if (minutes > 0) {
            return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
        }
        return `0:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    
    /* @tweakable simplified cleanup method without progress tracking */
    cleanup() {
        // Stop and clear current audio
        this.stopCurrentAudio();
        
        this.activeImages.forEach(element => {
            if (element.parentNode) {
                // Clear any pending removal timeouts
                if (element.dataset.removalTimeout) {
                    clearTimeout(parseInt(element.dataset.removalTimeout));
                }
                /* @tweakable cleanup associated audio for each image element */
                if (element.associatedAudio) {
                    this.stopAssociatedAudio(element.associatedAudio);
                }
                element.remove();
            }
        });
        this.activeImages = [];
        this.currentImageData = null;
        this.currentSoundData = null;
        this.audioMetadata = null;
    }
    
    /* @tweakable method to extract image dimensions for proper aspect ratio handling */
    extractImageDimensions(dataUrl) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                resolve({
                    width: img.naturalWidth,
                    height: img.naturalHeight
                });
            };
            img.onerror = () => {
                reject(new Error('Failed to load image for dimension extraction'));
            };
            img.src = dataUrl;
        });
    }
    
    /* @tweakable method to extract video dimensions for proper aspect ratio handling */
    extractVideoDimensions(dataUrl) {
        return new Promise((resolve, reject) => {
            const video = document.createElement('video');
            video.onloadedmetadata = () => {
                resolve({
                    width: video.videoWidth,
                    height: video.videoHeight
                });
            };
            video.onerror = () => {
                reject(new Error('Failed to load video for dimension extraction'));
            };
            video.src = dataUrl;
        });
    }
    
    /* @tweakable method to adjust UI controls to maintain aspect ratio */
    adjustImageDimensionsToAspectRatio(originalWidth, originalHeight) {
        const aspectRatio = originalWidth / originalHeight;
        
        /* @tweakable maximum display dimensions to fit within reasonable UI bounds */
        const maxDisplayWidth = 800;
        const maxDisplayHeight = 600;
        
        let newWidth = originalWidth;
        let newHeight = originalHeight;
        
        // Scale down if too large
        if (originalWidth > maxDisplayWidth) {
            newWidth = maxDisplayWidth;
            newHeight = newWidth / aspectRatio;
        }
        
        if (newHeight > maxDisplayHeight) {
            newHeight = maxDisplayHeight;
            newWidth = newHeight * aspectRatio;
        }
        
        // Update UI controls
        this.imageWidth.value = Math.round(newWidth);
        this.widthValue.textContent = this.imageWidth.value + 'px';
        this.imageHeight.value = Math.round(newHeight);
        this.heightValue.textContent = this.imageHeight.value + 'px';
        
        console.log(`Adjusted dimensions: ${newWidth}x${newHeight} (maintaining ratio: ${aspectRatio})`);
    }
    
    /* @tweakable method to adjust media dimensions maintaining aspect ratio for iframe-style display */
    adjustMediaDimensionsToAspectRatio(originalWidth, originalHeight) {
        if (!this.preserveAspectRatio.checked) return;
        
        const aspectRatio = originalWidth / originalHeight;
        
        /* @tweakable iframe-style display dimensions with aspect ratio constraints */
        const maxIframeWidth = 800;
        const maxIframeHeight = 600;
        
        let newWidth = originalWidth;
        let newHeight = originalHeight;
        
        // Scale to fit within iframe constraints
        if (originalWidth > maxIframeWidth) {
            newWidth = maxIframeWidth;
            newHeight = newWidth / aspectRatio;
        }
        
        if (newHeight > maxIframeHeight) {
            newHeight = maxIframeHeight;
            newWidth = newHeight * aspectRatio;
        }
        
        // Update UI controls with new dimensions
        this.imageWidth.value = Math.round(newWidth);
        this.widthValue.textContent = this.imageWidth.value + 'px';
        this.imageHeight.value = Math.round(newHeight);
        this.heightValue.textContent = this.imageHeight.value + 'px';
        
        console.log(`Adjusted media dimensions for iframe: ${newWidth}x${newHeight} (ratio: ${aspectRatio})`);
    }
}