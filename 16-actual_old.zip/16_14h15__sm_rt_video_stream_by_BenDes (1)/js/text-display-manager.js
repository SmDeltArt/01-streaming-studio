export default class TextDisplayManager {
    constructor(app) {
        this.app = app;
        this.textPanel = null;
        this.currentTextElement = null;
        /* @tweakable default text display duration in milliseconds */
        this.defaultDisplayDuration = 5000;
        /* @tweakable text fade transition duration */
        this.textFadeTransition = 500;
        /* @tweakable maximum simultaneous text displays */
        this.maxSimultaneousTexts = 3;
        
        this.activeTexts = [];
        this.isDragging = false;
        this.dragOffset = { x: 0, y: 0 };
        this.currentSettings = this.getDefaultSettings();
        
        this.initializeElements();
        this.bindEvents();
        this.setupDragging();
        this.initializeWebSimTTS();
    }
    
    initializeElements() {
        this.textBtn = document.getElementById('textBtn');
        this.textPanel = document.getElementById('textDisplayPanel');
        this.textPanelCollapse = document.getElementById('textPanelCollapse');
        this.textPanelClose = document.getElementById('textPanelClose');
        
        // Content controls
        this.textContent = document.getElementById('textContent');
        this.textPosition = document.getElementById('textPosition');
        this.textFontSize = document.getElementById('textFontSize');
        this.fontSizeValue = document.getElementById('fontSizeValue');
        this.textDisplayTime = document.getElementById('textDisplayTime');
        this.displayTimeValue = document.getElementById('displayTimeValue');
        
        // Effect controls
        this.textAnimation = document.getElementById('textAnimation');
        this.textShadowBlur = document.getElementById('textShadowBlur');
        this.shadowBlurValue = document.getElementById('shadowBlurValue');
        this.textGlowIntensity = document.getElementById('textGlowIntensity');
        this.glowIntensityValue = document.getElementById('glowIntensityValue');
        
        // Style controls
        this.textFontFamily = document.getElementById('textFontFamily');
        this.textFontWeight = document.getElementById('textFontWeight');
        this.textColor = document.getElementById('textColor');
        this.textBackgroundColor = document.getElementById('textBackgroundColor');
        this.textBackgroundOpacity = document.getElementById('textBackgroundOpacity');
        this.bgOpacityValue = document.getElementById('bgOpacityValue');
        this.textBorderRadius = document.getElementById('textBorderRadius');
        this.borderRadiusValue = document.getElementById('borderRadiusValue');
        this.textStrokeWidth = document.getElementById('textStrokeWidth');
        this.strokeWidthValue = document.getElementById('strokeWidthValue');
        this.textStrokeColor = document.getElementById('textStrokeColor');
        
        // Voice controls
        this.textVoice = document.getElementById('textVoice');
        this.speechSpeed = document.getElementById('speechSpeed');
        this.speechSpeedValue = document.getElementById('speechSpeedValue');
        this.speechVolume = document.getElementById('speechVolume');
        this.speechVolumeValue = document.getElementById('speechVolumeValue');
        
        // Preview and actions
        this.textPreview = document.getElementById('textPreview');
        this.showTextBtn = document.getElementById('showTextBtn');
        this.speakTextBtn = document.getElementById('speakTextBtn');
        this.previewTextBtn = document.getElementById('previewTextBtn');
        this.saveTextBtn = document.getElementById('saveTextBtn');
        this.loadTextBtn = document.getElementById('loadTextBtn');
    }
    
    bindEvents() {
        this.textBtn.addEventListener('click', () => this.togglePanel());
        this.textPanelCollapse.addEventListener('click', () => this.toggleCollapse());
        this.textPanelClose.addEventListener('click', () => this.hidePanel());
        
        // Content events
        this.textContent.addEventListener('input', () => this.updatePreview());
        this.textFontSize.addEventListener('input', () => {
            this.fontSizeValue.textContent = this.textFontSize.value + 'px';
            this.updatePreview();
        });
        this.textDisplayTime.addEventListener('input', () => {
            this.displayTimeValue.textContent = this.textDisplayTime.value + 's';
        });
        
        // Effect events
        this.textShadowBlur.addEventListener('input', () => {
            this.shadowBlurValue.textContent = this.textShadowBlur.value + 'px';
            this.updatePreview();
        });
        this.textGlowIntensity.addEventListener('input', () => {
            this.glowIntensityValue.textContent = this.textGlowIntensity.value + 'px';
            this.updatePreview();
        });
        
        // Style events
        this.textBackgroundOpacity.addEventListener('input', () => {
            this.bgOpacityValue.textContent = this.textBackgroundOpacity.value + '%';
            this.updatePreview();
        });
        this.textBorderRadius.addEventListener('input', () => {
            this.borderRadiusValue.textContent = this.textBorderRadius.value + 'px';
            this.updatePreview();
        });
        this.textStrokeWidth.addEventListener('input', () => {
            this.strokeWidthValue.textContent = this.textStrokeWidth.value + 'px';
            this.updatePreview();
        });
        
        // Voice events
        this.speechSpeed.addEventListener('input', () => {
            this.speechSpeedValue.textContent = this.speechSpeed.value + 'x';
        });
        this.speechVolume.addEventListener('input', () => {
            this.speechVolumeValue.textContent = this.speechVolume.value + '%';
        });
        
        // All change events for preview update
        [this.textPosition, this.textAnimation, this.textFontFamily, this.textFontWeight,
         this.textColor, this.textBackgroundColor, this.textStrokeColor].forEach(element => {
            element.addEventListener('change', () => this.updatePreview());
        });
        
        // Preset buttons
        document.querySelectorAll('.preset-text-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.textContent.value = e.target.getAttribute('data-text');
                this.updatePreview();
            });
        });
        
        // Action buttons
        this.showTextBtn.addEventListener('click', () => this.showText());
        this.speakTextBtn.addEventListener('click', () => this.speakText());
        this.previewTextBtn.addEventListener('click', () => this.previewText());
        this.saveTextBtn.addEventListener('click', () => this.saveSettings());
        this.loadTextBtn.addEventListener('click', () => this.loadSettings());
        
        // Keyboard shortcut
        document.addEventListener('keydown', (e) => {
            if (e.key.toLowerCase() === 't' && !e.target.matches('input, textarea, select')) {
                this.togglePanel();
                e.preventDefault();
            }
        });
    }
    
    setupDragging() {
        const header = this.textPanel.querySelector('.text-panel-header');
        let isDragging = false;
        let startX, startY, initialX, initialY;
        
        header.addEventListener('mousedown', (e) => {
            isDragging = true;
            this.textPanel.classList.add('dragging');
            
            startX = e.clientX;
            startY = e.clientY;
            
            const rect = this.textPanel.getBoundingClientRect();
            initialX = rect.left;
            initialY = rect.top;
            
            e.preventDefault();
        });
        
        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            
            const deltaX = e.clientX - startX;
            const deltaY = e.clientY - startY;
            
            let newX = initialX + deltaX;
            let newY = initialY + deltaY;
            
            /* @tweakable boundaries for panel dragging - allow 95% off-screen */
            const panelRect = this.textPanel.getBoundingClientRect();
            const minVisibleArea = Math.min(panelRect.width, panelRect.height) * 0.05; // 5% must stay visible
            
            newX = Math.max(-panelRect.width + minVisibleArea, 
                           Math.min(newX, window.innerWidth - minVisibleArea));
            newY = Math.max(-panelRect.height + minVisibleArea, 
                           Math.min(newY, window.innerHeight - minVisibleArea));
            
            this.textPanel.style.left = `${newX}px`;
            this.textPanel.style.top = `${newY}px`;
            this.textPanel.style.transform = 'none';
        });
        
        document.addEventListener('mouseup', () => {
            if (isDragging) {
                isDragging = false;
                this.textPanel.classList.remove('dragging');
            }
        });
    }
    
    /* @tweakable method to initialize WebSim Text-to-Speech API */
    async initializeWebSimTTS() {
        try {
            if (typeof window.websim !== 'undefined' && window.websim.textToSpeech) {
                this.ttsAPI = window.websim.textToSpeech;
                console.log('WebSim TTS API initialized');
            } else {
                console.warn('WebSim TTS API not available, using fallback');
                this.ttsAPI = this.createFallbackTTS();
            }
        } catch (error) {
            console.error('Error initializing TTS:', error);
            this.ttsAPI = this.createFallbackTTS();
        }
    }
    
    createFallbackTTS() {
        return async (options) => {
            try {
                if ('speechSynthesis' in window && 'SpeechSynthesisUtterance' in window) {
                    /* @tweakable browser speech synthesis configuration */
                    const maxRetryAttempts = 3;
                    const retryDelay = 500; // milliseconds
                    const speechTimeout = 10000; // milliseconds
                    
                    return new Promise((resolve, reject) => {
                        let attempts = 0;
                        
                        const attemptSpeech = () => {
                            attempts++;
                            
                            try {
                                // Cancel any ongoing speech
                                speechSynthesis.cancel();
                                
                                /* @tweakable speech synthesis timeout for cleanup */
                                setTimeout(() => speechSynthesis.cancel(), speechTimeout);
                                
                                const utterance = new SpeechSynthesisUtterance(options.text);
                                
                                /* @tweakable voice selection and fallback mapping */
                                const voiceMap = {
                                    'en-male': ['male', 'man', 'david', 'alex', 'daniel'],
                                    'en-female': ['female', 'woman', 'samantha', 'victoria', 'karen'],
                                    'es-male': ['spanish', 'jorge', 'carlos'],
                                    'es-female': ['spanish', 'spanish female', 'monica'],
                                    'fr-male': ['french', 'thomas', 'henri'],
                                    'fr-female': ['french', 'aurelie', 'marie']
                                };
                                
                                // Get available voices
                                const voices = speechSynthesis.getVoices();
                                console.log('Available voices:', voices.length);
                                
                                if (voices.length === 0) {
                                    // Voices not loaded yet, wait and retry
                                    if (attempts < maxRetryAttempts) {
                                        setTimeout(attemptSpeech, retryDelay);
                                        return;
                                    } else {
                                        console.warn('No voices available, using default');
                                    }
                                } else {
                                    /* @tweakable voice matching algorithm */
                                    const preferredVoices = voiceMap[options.voice] || ['default'];
                                    let selectedVoice = null;
                                    
                                    // Try to find a matching voice
                                    for (const preference of preferredVoices) {
                                        selectedVoice = voices.find(voice => 
                                            voice.name.toLowerCase().includes(preference.toLowerCase()) ||
                                            voice.lang.toLowerCase().includes(preference.split('-')[0]) ||
                                            (preference.includes('male') && voice.name.toLowerCase().includes('male')) ||
                                            (preference.includes('female') && voice.name.toLowerCase().includes('female'))
                                        );
                                        if (selectedVoice) break;
                                    }
                                    
                                    // Fallback to English voices
                                    if (!selectedVoice) {
                                        selectedVoice = voices.find(voice => 
                                            voice.lang.startsWith('en') && !voice.name.includes('Google')
                                        ) || voices[0];
                                    }
                                    
                                    if (selectedVoice) {
                                        utterance.voice = selectedVoice;
                                        console.log('Selected voice:', selectedVoice.name);
                                    }
                                }
                                
                                /* @tweakable speech synthesis parameters */
                                utterance.rate = Math.max(0.1, Math.min(10, options.speed || 1));
                                utterance.volume = Math.max(0, Math.min(1, (options.volume || 70) / 100));
                                utterance.pitch = 1; // Default pitch
                                
                                let resolved = false;
                                
                                utterance.onend = () => {
                                    if (!resolved) {
                                        resolved = true;
                                        resolve({ success: true, url: null });
                                    }
                                };
                                
                                utterance.onerror = (event) => {
                                    if (!resolved) {
                                        resolved = true;
                                        console.error('Speech synthesis error:', event.error);
                                        if (attempts < maxRetryAttempts) {
                                            setTimeout(attemptSpeech, retryDelay);
                                        } else {
                                            reject(new Error(`Speech synthesis failed: ${event.error}`));
                                        }
                                    }
                                };
                                
                                /* @tweakable speech start timeout */
                                const startTimeout = setTimeout(() => {
                                    if (!resolved) {
                                        resolved = true;
                                        if (attempts < maxRetryAttempts) {
                                            setTimeout(attemptSpeech, retryDelay);
                                        } else {
                                            reject(new Error('Speech synthesis timeout'));
                                        }
                                    }
                                }, speechTimeout);
                                
                                utterance.onstart = () => {
                                    clearTimeout(startTimeout);
                                };
                                
                                speechSynthesis.speak(utterance);
                                
                            } catch (error) {
                                if (attempts < maxRetryAttempts) {
                                    setTimeout(attemptSpeech, retryDelay);
                                } else {
                                    reject(error);
                                }
                            }
                        };
                        
                        // Start attempting speech
                        attemptSpeech();
                    });
                    
                } else {
                    throw new Error('Speech synthesis not supported in this browser');
                }
            } catch (error) {
                console.error('Fallback TTS error:', error);
                return { success: false, error: error.message };
            }
        };
    }
    
    getDefaultSettings() {
        return {
            content: 'Welcome to my stream!',
            position: 'top-center',
            fontSize: 32,
            displayTime: 5,
            animation: 'fade',
            shadowBlur: 4,
            glowIntensity: 10,
            fontFamily: 'Inter',
            fontWeight: '600',
            textColor: '#ffffff',
            backgroundColor: '#000000',
            backgroundOpacity: 50,
            borderRadius: 8,
            strokeWidth: 0,
            strokeColor: '#000000',
            voice: 'en-male',
            speechSpeed: 1.0,
            speechVolume: 70
        };
    }
    
    togglePanel() {
        if (this.textPanel.style.display === 'block') {
            this.hidePanel();
        } else {
            this.showPanel();
        }
    }
    
    showPanel() {
        this.textPanel.style.display = 'block';
        this.updatePreview();
    }
    
    hidePanel() {
        this.textPanel.style.display = 'none';
    }
    
    toggleCollapse() {
        const isCollapsed = this.textPanel.classList.contains('collapsed');
        if (isCollapsed) {
            this.textPanel.classList.remove('collapsed');
            this.textPanelCollapse.textContent = '−';
        } else {
            this.textPanel.classList.add('collapsed');
            this.textPanelCollapse.textContent = '+';
        }
    }
    
    updatePreview() {
        const content = this.textContent.value || 'Your text will appear here';
        const settings = this.getCurrentSettings();
        
        /* @tweakable preview text styling to match actual display */
        this.textPreview.textContent = content;
        this.textPreview.style.fontSize = settings.fontSize + 'px';
        this.textPreview.style.fontFamily = settings.fontFamily;
        this.textPreview.style.fontWeight = settings.fontWeight;
        this.textPreview.style.color = settings.textColor;
        this.textPreview.style.borderRadius = settings.borderRadius + 'px';
        
        // Background with opacity
        const bgColor = this.hexToRgba(settings.backgroundColor, settings.backgroundOpacity / 100);
        this.textPreview.style.background = bgColor;
        
        // Text effects
        let textShadow = `0 ${settings.shadowBlur}px ${settings.shadowBlur * 2}px rgba(0, 0, 0, 0.5)`;
        if (settings.glowIntensity > 0) {
            textShadow += `, 0 0 ${settings.glowIntensity}px ${settings.textColor}`;
        }
        if (settings.strokeWidth > 0) {
            textShadow += `, 0 0 0 ${settings.strokeWidth}px ${settings.strokeColor}`;
        }
        this.textPreview.style.textShadow = textShadow;
    }
    
    getCurrentSettings() {
        return {
            content: this.textContent.value,
            position: this.textPosition.value,
            fontSize: parseInt(this.textFontSize.value),
            displayTime: parseInt(this.textDisplayTime.value),
            animation: this.textAnimation.value,
            shadowBlur: parseInt(this.textShadowBlur.value),
            glowIntensity: parseInt(this.textGlowIntensity.value),
            fontFamily: this.textFontFamily.value,
            fontWeight: this.textFontWeight.value,
            textColor: this.textColor.value,
            backgroundColor: this.textBackgroundColor.value,
            backgroundOpacity: parseInt(this.textBackgroundOpacity.value),
            borderRadius: parseInt(this.textBorderRadius.value),
            strokeWidth: parseInt(this.textStrokeWidth.value),
            strokeColor: this.textStrokeColor.value,
            voice: this.textVoice.value,
            speechSpeed: parseFloat(this.speechSpeed.value),
            speechVolume: parseInt(this.speechVolume.value)
        };
    }
    
    showText() {
        const settings = this.getCurrentSettings();
        if (!settings.content.trim()) {
            alert('Please enter some text to display');
            return;
        }
        
        this.displayText(settings);
    }
    
    /* @tweakable main text display method with enhanced active item integration for persistence */
    displayText(settings) {
        // Remove oldest text if at maximum
        if (this.activeTexts.length >= this.maxSimultaneousTexts) {
            const oldestText = this.activeTexts.shift();
            if (oldestText && oldestText.parentNode) {
                oldestText.remove();
            }
        }
        
        /* @tweakable merge stored settings with defaults to prevent undefined property errors */
        const mergedSettings = { ...this.getDefaultSettings(), ...settings };
        
        const textElement = document.createElement('div');
        textElement.className = 'text-display-element';
        
        // Set content and basic styling
        textElement.textContent = mergedSettings.content;
        textElement.style.fontSize = mergedSettings.fontSize + 'px';
        textElement.style.fontFamily = mergedSettings.fontFamily;
        textElement.style.fontWeight = mergedSettings.fontWeight;
        textElement.style.color = mergedSettings.textColor;
        textElement.style.borderRadius = mergedSettings.borderRadius + 'px';
        
        // Background with opacity
        const bgColor = this.hexToRgba(mergedSettings.backgroundColor, mergedSettings.backgroundOpacity / 100);
        textElement.style.background = bgColor;
        
        // Text effects
        let textShadow = `0 ${mergedSettings.shadowBlur}px ${mergedSettings.shadowBlur * 2}px rgba(0, 0, 0, 0.5)`;
        if (mergedSettings.glowIntensity > 0) {
            textShadow += `, 0 0 ${mergedSettings.glowIntensity}px ${mergedSettings.textColor}`;
        }
        if (mergedSettings.strokeWidth > 0) {
            textShadow += `, 0 0 0 ${mergedSettings.strokeWidth}px ${mergedSettings.strokeColor}`;
        }
        textElement.style.textShadow = textShadow;
        
        // Position the text
        this.positionText(textElement, mergedSettings.position);
        
        // Add animation class and custom properties
        if (mergedSettings.animation !== 'none') {
            textElement.classList.add(mergedSettings.animation);
            textElement.style.setProperty('--display-time', `${mergedSettings.displayTime}s`);
            if (mergedSettings.animation === 'typewriter') {
                textElement.style.setProperty('--char-count', mergedSettings.content.length);
            }
        }
        
        // Add to DOM and track
        document.body.appendChild(textElement);
        this.activeTexts.push(textElement);

        /* @tweakable enhanced active item creation for persistent replay functionality */
        let activeItemId = null;
        if (this.app.uiManager && this.app.uiManager.addActiveItem) {
            // Check if this is a replay of an existing item
            const existingItem = this.app.uiManager.activeItems.find(item => 
                item.type === 'text' && 
                item.settings.content === mergedSettings.content && 
                !item.element
            );
            
            if (existingItem) {
                // Update existing item with new element
                existingItem.element = textElement;
                activeItemId = existingItem.id;
                textElement.dataset.activeItemId = activeItemId;
                this.app.uiManager.updateActiveItemsDisplay();
            } else {
                // Create new active item
                activeItemId = this.app.uiManager.addActiveItem('text', mergedSettings.content, textElement, mergedSettings);
            }
        }
        
        // Auto-remove after display time
        const displayDuration = mergedSettings.displayTime * 1000;
        setTimeout(() => {
            this.removeTextElement(textElement);
        }, displayDuration);
    }
    
    positionText(element, position) {
        element.style.position = 'fixed';
        element.style.zIndex = '15000';
        
        switch (position) {
            case 'top-left':
                element.style.top = '20px';
                element.style.left = '20px';
                break;
            case 'top-center':
                element.style.top = '20px';
                element.style.left = '50%';
                element.style.transform = 'translateX(-50%)';
                break;
            case 'top-right':
                element.style.top = '20px';
                element.style.right = '20px';
                break;
            case 'center':
                element.style.top = '50%';
                element.style.left = '50%';
                element.style.transform = 'translate(-50%, -50%)';
                break;
            case 'bottom-left':
                element.style.bottom = '20px';
                element.style.left = '20px';
                break;
            case 'bottom-center':
                element.style.bottom = '20px';
                element.style.left = '50%';
                element.style.transform = 'translateX(-50%)';
                break;
            case 'bottom-right':
                element.style.bottom = '20px';
                element.style.right = '20px';
                break;
        }
    }
    
    removeTextElement(element) {
        if (element && element.parentNode) {
            /* @tweakable cleanup active item when text element is removed */
            if (this.app.uiManager && this.app.uiManager.cleanupActiveItem) {
                this.app.uiManager.cleanupActiveItem(element);
            }

            element.style.transition = `opacity ${this.textFadeTransition}ms ease-out`;
            element.style.opacity = '0';
            
            setTimeout(() => {
                if (element.parentNode) {
                    element.remove();
                }
                const index = this.activeTexts.indexOf(element);
                if (index > -1) {
                    this.activeTexts.splice(index, 1);
                }
            }, this.textFadeTransition);
        }
    }
    
    /* @tweakable text-to-speech functionality using WebSim API */
    async speakText() {
        const settings = this.getCurrentSettings();
        if (!settings.content.trim()) {
            alert('Please enter some text to speak');
            return;
        }
        
        try {
            this.speakTextBtn.textContent = '🔊 Speaking...';
            this.speakTextBtn.disabled = true;
            
            /* @tweakable WebSim TTS API call parameters */
            const ttsOptions = {
                text: settings.content.trim(),
                voice: settings.voice
            };
            
            // Try WebSim API first
            if (typeof this.ttsAPI === 'function') {
                const result = await this.ttsAPI(ttsOptions);
                
                if (result && result.url) {
                    /* @tweakable audio playback settings */
                    const audio = new Audio(result.url);
                    audio.volume = settings.speechVolume / 100;
                    audio.playbackRate = settings.speechSpeed;
                    
                    return new Promise((resolve, reject) => {
                        audio.onended = () => resolve({ success: true });
                        audio.onerror = () => reject(new Error('Audio playback failed'));
                        audio.play().catch(reject);
                    });
                } else if (result && result.success !== false) {
                    // WebSim API succeeded but didn't return audio URL
                    return { success: true };
                } else {
                    throw new Error(result?.error || 'WebSim TTS API returned no audio');
                }
            } else {
                throw new Error('TTS API not available');
            }
            
        } catch (error) {
            console.error('Primary TTS error:', error);
            
            try {
                /* @tweakable fallback TTS with enhanced error recovery */
                console.log('Attempting fallback TTS...');
                const fallbackTTS = this.createFallbackTTS();
                const fallbackOptions = {
                    text: settings.content.trim(),
                    voice: settings.voice,
                    speed: settings.speechSpeed,
                    volume: settings.speechVolume
                };
                
                const result = await fallbackTTS(fallbackOptions);
                
                if (result.success) {
                    console.log('Fallback TTS succeeded');
                } else {
                    throw new Error(result.error || 'Fallback TTS failed');
                }
                
            } catch (fallbackError) {
                console.error('Fallback TTS error:', fallbackError);
                alert(`Failed to speak text: ${fallbackError.message}. Please check your browser's speech synthesis support.`);
            }
            
        } finally {
            this.speakTextBtn.textContent = '🔊 Speak';
            this.speakTextBtn.disabled = false;
        }
    }
    
    previewText() {
        const settings = this.getCurrentSettings();
        if (!settings.content.trim()) {
            alert('Please enter some text to preview');
            return;
        }
        
        // Show a temporary preview for 2 seconds
        const tempSettings = { ...settings, displayTime: 2 };
        this.displayText(tempSettings);
    }
    
    /* @tweakable JSON save/load functionality for text settings */
    saveSettings() {
        const settings = this.getCurrentSettings();
        const dataStr = JSON.stringify(settings, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        
        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        link.download = `text-display-settings-${new Date().toISOString().slice(0, 10)}.json`;
        link.click();
        
        // Clean up
        setTimeout(() => URL.revokeObjectURL(link.href), 100);
    }
    
    loadSettings() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        
        input.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const settings = JSON.parse(e.target.result);
                    this.applySettings(settings);
                    this.updatePreview();
                    alert('Settings loaded successfully!');
                } catch (error) {
                    console.error('Error loading settings:', error);
                    alert('Failed to load settings: Invalid JSON file');
                }
            };
            reader.readAsText(file);
        });
        
        input.click();
    }
    
    applySettings(settings) {
        this.textContent.value = settings.content || '';
        this.textPosition.value = settings.position || 'top-center';
        this.textFontSize.value = settings.fontSize || 32;
        this.fontSizeValue.textContent = this.textFontSize.value + 'px';
        this.textDisplayTime.value = settings.displayTime || 5;
        this.displayTimeValue.textContent = this.textDisplayTime.value + 's';
        
        this.textAnimation.value = settings.animation || 'fade';
        this.textShadowBlur.value = settings.shadowBlur || 4;
        this.shadowBlurValue.textContent = this.textShadowBlur.value + 'px';
        this.textGlowIntensity.value = settings.glowIntensity || 10;
        this.glowIntensityValue.textContent = this.textGlowIntensity.value + 'px';
        
        this.textFontFamily.value = settings.fontFamily || 'Inter';
        this.textFontWeight.value = settings.fontWeight || '600';
        this.textColor.value = settings.textColor || '#ffffff';
        
        this.textBackgroundColor.value = settings.backgroundColor || '#000000';
        this.textBackgroundOpacity.value = settings.backgroundOpacity || 50;
        this.bgOpacityValue.textContent = this.textBackgroundOpacity.value + '%';
        this.textBorderRadius.value = settings.borderRadius || 8;
        this.borderRadiusValue.textContent = this.textBorderRadius.value + 'px';
        this.textStrokeWidth.value = settings.strokeWidth || 0;
        this.strokeWidthValue.textContent = this.textStrokeWidth.value + 'px';
        this.textStrokeColor.value = settings.strokeColor || '#000000';
        
        this.textVoice.value = settings.voice || 'en-male';
        this.speechSpeed.value = settings.speechSpeed || 1.0;
        this.speechSpeedValue.textContent = this.speechSpeed.value + 'x';
        this.speechVolume.value = settings.speechVolume || 70;
        this.speechVolumeValue.textContent = this.speechVolume.value + '%';
    }
    
    /* @tweakable enhanced hex to rgba conversion with null safety to prevent undefined property errors */
    hexToRgba(hex, alpha) {
        // Handle undefined or invalid hex values
        if (!hex || typeof hex !== 'string' || !hex.startsWith('#') || hex.length !== 7) {
            console.warn('Invalid hex color value:', hex, 'using default black');
            hex = '#000000';
        }
        
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        
        // Ensure alpha is a valid number
        const validAlpha = isNaN(alpha) ? 1 : Math.max(0, Math.min(1, alpha));
        
        return `rgba(${r}, ${g}, ${b}, ${validAlpha})`;
    }
    
    cleanup() {
        this.activeTexts.forEach(element => {
            if (element.parentNode) {
                element.remove();
            }
        });
        this.activeTexts = [];
    }
}