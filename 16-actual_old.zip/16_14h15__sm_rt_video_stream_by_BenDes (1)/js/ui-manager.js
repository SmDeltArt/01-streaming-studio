export default class UIManager {
    constructor(app) {
        this.app = app;
        this.panelCollapsed = false;
        
        this.initializePanelToggle();
        this.initializeInfoModal();
    }
    
    initializePanelToggle() {
        const controlPanel = document.querySelector('.control-panel');
        const toggleBtn = document.createElement('div');
        toggleBtn.id = 'controls-toggle';
        toggleBtn.textContent = '>';
        toggleBtn.addEventListener('click', () => this.togglePanel());
        
        controlPanel.appendChild(toggleBtn);
        
        if (window.innerWidth <= 768) {
            this.togglePanel();
        }
    }
    
    togglePanel() {
        const controlPanel = document.querySelector('.control-panel');
        const toggleBtn = document.getElementById('controls-toggle');
        
        this.panelCollapsed = !this.panelCollapsed;
        
        if (this.panelCollapsed) {
            controlPanel.classList.add('collapsed');
            toggleBtn.textContent = '<';
        } else {
            controlPanel.classList.remove('collapsed');
            toggleBtn.textContent = '>';
        }
    }
    
    initializeInfoModal() {
        this.app.infoModal.addEventListener('click', (e) => {
            if (e.target === this.app.infoModal) {
                this.hideInfoModal();
            }
        });

        /* @tweakable settings modal initialization for cursor effects and other settings */
        this.settingsModal = document.getElementById('settingsModal');
        this.settingsBtn = document.getElementById('settingsBtn');
        this.settingsCloseBtn = document.getElementById('settingsCloseBtn');

        if (this.settingsBtn) {
            this.settingsBtn.addEventListener('click', () => this.showSettingsModal());
        }
        
        if (this.settingsCloseBtn) {
            this.settingsCloseBtn.addEventListener('click', () => this.hideSettingsModal());
        }

        if (this.settingsModal) {
            this.settingsModal.addEventListener('click', (e) => {
                if (e.target === this.settingsModal) {
                    this.hideSettingsModal();
                }
            });
        }

        /* @tweakable active items manager for quick access to displayed content */
        this.initializeActiveItemsManager();
    }

    /* @tweakable method to initialize active items display management */
    initializeActiveItemsManager() {
        this.activeItemsSection = document.getElementById('activeItemsSection');
        this.activeItemsList = document.getElementById('activeItemsList');
        this.activeCount = document.getElementById('activeCount');
        this.activeItems = [];
        this.nextItemId = 1;

        this.updateActiveItemsDisplay();
    }

    /* @tweakable method to add an active item to the quick access list */
    addActiveItem(type, content, element, settings) {
        const item = {
            id: this.nextItemId++,
            type: type, // 'text' or 'image'
            content: content,
            element: element,
            settings: settings,
            timestamp: Date.now()
        };

        this.activeItems.push(item);
        this.updateActiveItemsDisplay();
        
        // Store reference in the display element for cleanup
        if (element) {
            element.dataset.activeItemId = item.id;
        }

        return item.id;
    }

    /* @tweakable method to remove an active item from the quick access list */
    removeActiveItem(itemId) {
        const index = this.activeItems.findIndex(item => item.id === itemId);
        if (index > -1) {
            const item = this.activeItems[index];
            
            // Remove the display element
            if (item.element && item.element.parentNode) {
                item.element.remove();
            }
            
            // Remove from active items list
            this.activeItems.splice(index, 1);
            this.updateActiveItemsDisplay();
        }
    }

    /* @tweakable method to update the active items display in the UI with vignette popup functionality */
    updateActiveItemsDisplay() {
        if (!this.activeItemsList || !this.activeCount) return;

        // Update count
        this.activeCount.textContent = this.activeItems.length;

        // Clear existing items
        this.activeItemsList.innerHTML = '';

        // Add each active item
        this.activeItems.forEach((item, index) => {
            const itemElement = document.createElement('div');
            
            /* @tweakable visual indicator for items that are currently displaying vs stored for replay */
            const isCurrentlyDisplaying = item.element && item.element.parentNode;
            itemElement.className = `active-item ${item.type}-item ${isCurrentlyDisplaying ? 'currently-displaying' : 'stored-for-replay'}`;
            
            /* @tweakable icon selection for vignette items */
            const icon = item.type === 'text' ? '📝' : item.type === 'image' ? '🖼️' : item.type === 'vignette' ? '📋' : '📄';
            const displayNumber = index + 1;
            
            /* @tweakable enhanced tooltip showing replay vs currently showing status */
            const statusIndicator = isCurrentlyDisplaying ? '●' : '▶';
            const statusTitle = isCurrentlyDisplaying ? 'Currently displaying - click to replay' : 'Stored - click to replay';
            
            itemElement.innerHTML = `
                <div class="active-item-icon">${icon}</div>
                <div class="active-item-number">${displayNumber}</div>
                <div class="active-item-status" title="${statusTitle}">${statusIndicator}</div>
                <button class="active-item-remove" data-item-id="${item.id}">×</button>
            `;
            
            itemElement.title = statusTitle;

            /* @tweakable vignette popup content display for active items */
            // Create vignette popup for content preview
            const vignettePopup = document.createElement('div');
            vignettePopup.className = 'active-item-vignette';
            vignettePopup.style.display = 'none';
            
            let vignetteContent = '';
            if (item.type === 'text') {
                vignetteContent = `
                    <div class="vignette-header">📝 Text Content</div>
                    <div class="vignette-content">${item.content.substring(0, 200)}${item.content.length > 200 ? '...' : ''}</div>
                    <div class="vignette-settings">Font: ${item.settings.fontFamily}, Size: ${item.settings.fontSize}px</div>
                `;
            } else if (item.type === 'image') {
                vignetteContent = `
                    <div class="vignette-header">🖼️ Image Display</div>
                    <div class="vignette-content">${item.content}</div>
                    <div class="vignette-settings">Size: ${item.settings.width}x${item.settings.height}px</div>
                `;
            } else if (item.type === 'vignette') {
                /* @tweakable vignette preview popup content for reading vignettes */
                vignetteContent = `
                    <div class="vignette-header">📋 Reading Vignette</div>
                    <div class="vignette-content">${item.settings.content.substring(0, 200)}${item.settings.content.length > 200 ? '...' : ''}</div>
                    <div class="vignette-settings">Position: ${item.settings.position ? `${item.settings.position.x}, ${item.settings.position.y}` : 'Default'}</div>
                `;
            }
            
            vignettePopup.innerHTML = vignetteContent;
            itemElement.appendChild(vignettePopup);

            // Show/hide vignette on hover
            itemElement.addEventListener('mouseenter', () => {
                vignettePopup.style.display = 'block';
            });
            
            itemElement.addEventListener('mouseleave', () => {
                vignettePopup.style.display = 'none';
            });

            // Add click handler to re-display item
            itemElement.addEventListener('click', (e) => {
                if (!e.target.classList.contains('active-item-remove')) {
                    this.reDisplayActiveItem(item);
                }
            });

            // Add remove handler
            const removeBtn = itemElement.querySelector('.active-item-remove');
            removeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.removeActiveItem(item.id);
            });

            this.activeItemsList.appendChild(itemElement);
        });
    }

    /* @tweakable method to re-display an active item when clicked from quick access with enhanced replay functionality */
    reDisplayActiveItem(item) {
        /* @tweakable automatic removal of currently displaying element before replay to avoid duplicates */
        if (item.element && item.element.parentNode) {
            // If the item is currently displaying, remove it first
            item.element.remove();
            item.element = null;
        }
        
        if (item.type === 'text' && this.app.textDisplayManager) {
            // Re-display text with stored settings
            this.app.textDisplayManager.displayText(item.settings);
        } else if (item.type === 'image' && this.app.imageDisplayManager) {
            // Re-display image with stored settings
            this.app.imageDisplayManager.displayImage(item.settings);
        } else if (item.type === 'vignette' && this.app.smartRedactorManager) {
            /* @tweakable enhanced vignette reopening functionality with proper element reference management */
            // Reopen the reading vignette with full state restoration
            const smartRedactor = this.app.smartRedactorManager;
            
            // Restore content
            if (smartRedactor.readingText && item.settings.content) {
                smartRedactor.readingText.textContent = item.settings.content;
            }
            
            // Show the vignette
            if (smartRedactor.readingVignette) {
                smartRedactor.readingVignette.style.display = 'block';
                
                /* @tweakable vignette position restoration with bounds checking */
                // Restore position if available
                if (item.settings.position) {
                    smartRedactor.vignettePosition = item.settings.position;
                    
                    // Ensure position is within screen bounds
                    const validX = Math.max(0, Math.min(item.settings.position.x, window.innerWidth - 200));
                    const validY = Math.max(0, Math.min(item.settings.position.y, window.innerHeight - 100));
                    
                    smartRedactor.readingVignette.style.left = `${validX}px`;
                    smartRedactor.readingVignette.style.top = `${validY}px`;
                    smartRedactor.readingVignette.style.transform = 'none';
                }
                
                /* @tweakable vignette state restoration including pinned and collapsed states */
                // Restore pinned state
                if (item.settings.isPinned) {
                    smartRedactor.isPinned = true;
                    smartRedactor.readingVignette.classList.add('pinned');
                    if (smartRedactor.vignettePin) {
                        smartRedactor.vignettePin.classList.add('active');
                    }
                } else {
                    smartRedactor.isPinned = false;
                    smartRedactor.readingVignette.classList.remove('pinned');
                    if (smartRedactor.vignettePin) {
                        smartRedactor.vignettePin.classList.remove('active');
                    }
                }
                
                // Ensure vignette is not collapsed
                smartRedactor.isCollapsed = false;
                smartRedactor.readingVignette.classList.remove('collapsed');
                if (smartRedactor.vignetteCollapse) {
                    smartRedactor.vignetteCollapse.textContent = '−';
                }
                
                /* @tweakable progress bar reset and tracking setup for reopened vignettes */
                // Reset progress bar
                if (smartRedactor.progressBar) {
                    smartRedactor.progressBar.style.width = '0%';
                }
                
                // Update item element reference to the reopened vignette
                item.element = smartRedactor.readingVignette;
                smartRedactor.readingVignette.dataset.activeItemId = item.id;
                
                // Setup progress tracking
                if (smartRedactor.setupReadingProgress) {
                    smartRedactor.setupReadingProgress();
                }
                
                console.log('Vignette reopened successfully from active display thumbnail');
            }
        }
        
        /* @tweakable display update timing to ensure proper state reflection after element restoration */
        // Update display after replay to show current status
        setTimeout(() => this.updateActiveItemsDisplay(), 150);
    }

    /* @tweakable method to clean up active item when element is removed */
    cleanupActiveItem(element) {
        if (element && element.dataset.activeItemId) {
            const itemId = parseInt(element.dataset.activeItemId);
            const index = this.activeItems.findIndex(item => item.id === itemId);
            if (index > -1) {
                // Don't remove the item from the list - keep it for replay functionality
                const item = this.activeItems[index];
                if (item.element === element) {
                    // Just clear the element reference but keep the item in the list
                    item.element = null;
                }
                // Update display to reflect the item is no longer actively showing
                this.updateActiveItemsDisplay();
            }
        }
    }

    /* @tweakable settings modal show/hide methods */
    showSettingsModal() {
        if (this.settingsModal) {
            this.settingsModal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        }
    }

    hideSettingsModal() {
        if (this.settingsModal) {
            this.settingsModal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    }
    
    showInfoModal() {
        this.app.infoModal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
    
    hideInfoModal() {
        this.app.infoModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
    
    toggleFullscreen() {
        const fullscreenEnabled = document.fullscreenEnabled || 
                                 document.webkitFullscreenEnabled || 
                                 document.mozFullScreenEnabled ||
                                 document.msFullscreenEnabled;
        
        if (!fullscreenEnabled) {
            console.warn('Fullscreen not supported in this browser');
            return;
        }

        if (!document.fullscreenElement && 
            !document.webkitFullscreenElement && 
            !document.mozFullScreenElement &&
            !document.msFullscreenElement) {
            const element = document.documentElement;
            if (element.requestFullscreen) {
                element.requestFullscreen();
            } else if (element.webkitRequestFullscreen) {
                element.webkitRequestFullscreen();
            } else if (element.mozRequestFullScreen) {
                element.mozRequestFullScreen();
            } else if (element.msRequestFullscreen) {
                element.msRequestFullscreen();
            }
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            } else if (document.mozCancelFullScreen) {
                document.mozCancelFullScreen();
            } else if (document.msExitFullscreen) {
                document.msExitFullscreen();
            }
        }
    }
    
    handleResize() {
        if (window.innerWidth <= 768 && !this.panelCollapsed) {
            this.togglePanel();
        } else if (window.innerWidth > 768 && this.panelCollapsed) {
            this.togglePanel();
        }
    }
}