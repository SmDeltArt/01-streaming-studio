// Import managers
import CameraManager from './js/camera-manager.js';
import RecordingManager from './js/recording-manager.js';
import UIManager from './js/ui-manager.js';
import AudioManager from './js/audio-manager.js';
import CursorEffectsManager from './js/cursor-effects-manager.js';
import TextDisplayManager from './js/text-display-manager.js';
import ImageDisplayManager from './js/image-display-manager.js';
import SmartRedactorManager from './js/smartRedactor.js';

class StreamingStudio {
    constructor() {
        this.mediaStream = null;
        this.isRecording = false;
        this.recordingStartTime = null;
        this.recordingTimer = null;
        this.recordingTimerInterval = null;
        this.websimRecordingSession = null;
        this.isDragging = false;
        this.dragOffset = { x: 0, y: 0 };
        this.panelCollapsed = false;
        
        this.initializeElements();
        this.initializeManagers();
        this.bindEvents();
        this.bindKeyboardShortcuts();
        this.initializeWebSimAPI();
    }
    
    initializeElements() {
        // Control elements
        this.urlInput = document.getElementById('urlInput');
        this.loadBtn = document.getElementById('loadBtn');
        this.mediaUploadInput = document.getElementById('mediaUploadInput');
        this.browseMediaBtn = document.getElementById('browseMediaBtn');
        this.mediaInfoDisplay = document.getElementById('mediaInfoDisplay');
        this.mediaFileName = document.getElementById('mediaFileName');
        this.mediaFileSize = document.getElementById('mediaFileSize');
        this.maintainAspectRatio = document.getElementById('maintainAspectRatio');
        this.hideMediaControls = document.getElementById('hideMediaControls');
        this.autoplayMedia = document.getElementById('autoplayMedia');
        
        this.cameraBtn = document.getElementById('cameraBtn');
        this.micBtn = document.getElementById('micBtn');
        this.recordBtn = document.getElementById('recordBtn');
        this.pauseBtn = document.getElementById('pauseBtn');
        this.stopBtn = document.getElementById('stopBtn');
        
        // Content elements
        this.contentDisplay = document.getElementById('contentDisplay');
        this.contentFrame = document.getElementById('contentFrame');
        this.welcomeScreen = document.querySelector('.welcome-screen');
        
        // Status elements
        this.statusDot = document.getElementById('statusDot');
        this.statusText = document.getElementById('statusText');
        
        // Info modal elements
        this.infoBtn = document.getElementById('infoBtn');
        this.infoModal = document.getElementById('infoModal');
        this.infoCloseBtn = document.getElementById('infoCloseBtn');
    }
    
    initializeManagers() {
        this.cameraManager = new CameraManager(this);
        this.recordingManager = new RecordingManager(this);
        this.uiManager = new UIManager(this);
        this.audioManager = new AudioManager(this);
        this.cursorEffectsManager = new CursorEffectsManager(this);
        this.textDisplayManager = new TextDisplayManager(this);
        this.imageDisplayManager = new ImageDisplayManager(this);
        this.smartRedactorManager = new SmartRedactorManager(this);
    }
    
    bindEvents() {
        // Load content
        this.loadBtn.addEventListener('click', () => this.loadContent());
        this.urlInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.loadContent();
        });
        
        this.browseMediaBtn.addEventListener('click', () => this.mediaUploadInput.click());
        this.mediaUploadInput.addEventListener('change', (e) => this.handleMainMediaUpload(e));
        
        // Quick links
        document.querySelectorAll('.quick-link-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const url = e.target.getAttribute('data-url');
                this.urlInput.value = url;
                this.loadContent();
            });
        });
        
        // Media controls
        this.cameraBtn.addEventListener('click', () => this.cameraManager.toggleCameraStream());
        this.micBtn.addEventListener('click', () => this.cameraManager.toggleMicrophone());
        
        // Recording controls
        this.recordBtn.addEventListener('click', () => this.recordingManager.toggleRecording());
        if (this.pauseBtn) {
            this.pauseBtn.addEventListener('click', () => this.recordingManager.togglePause());
        }
        this.stopBtn.addEventListener('click', () => this.recordingManager.stopRecording());
        
        // Info modal
        this.infoBtn.addEventListener('click', () => this.uiManager.showInfoModal());
        this.infoCloseBtn.addEventListener('click', () => this.uiManager.hideInfoModal());
        
        // Handle window resize
        window.addEventListener('resize', () => this.handleResize());
        
        /* @tweakable fullscreen button functionality */
        // Add fullscreen button event listener
        const fullscreenBtn = document.getElementById('fullscreenBtn');
        if (fullscreenBtn) {
            fullscreenBtn.addEventListener('click', () => this.uiManager.toggleFullscreen());
        }
    }
    
    bindKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
                return;
            }
            
            switch (e.key.toLowerCase()) {
                case 'c':
                    this.uiManager.togglePanel();
                    e.preventDefault();
                    break;
                case 'l':
                    this.loadContent();
                    e.preventDefault();
                    break;
                case 'v':
                    this.cameraManager.toggleCameraStream();
                    e.preventDefault();
                    break;
                case 'm':
                    this.cameraManager.toggleMicrophone();
                    e.preventDefault();
                    break;
                case 'f':
                    this.uiManager.toggleFullscreen();
                    e.preventDefault();
                    break;
                case 'r':
                    if (!this.isRecording) {
                        this.recordingManager.startRecording();
                    }
                    e.preventDefault();
                    break;
                case 'p':
                    if (this.isRecording) {
                        this.recordingManager.togglePause();
                    } else {
                        this.cameraManager.toggleCameraVisibility();
                    }
                    e.preventDefault();
                    break;
                case 's':
                    if (this.isRecording) {
                        this.recordingManager.stopRecording();
                    }
                    e.preventDefault();
                    break;
                case 'i':
                    this.imageDisplayManager.togglePanel();
                    e.preventDefault();
                    break;
                case 'a':
                    this.smartRedactorManager.togglePanel();
                    e.preventDefault();
                    break;
                case 'escape':
                    if (this.infoModal.style.display === 'block') {
                        this.uiManager.hideInfoModal();
                    }
                    if (document.fullscreenElement) {
                        document.exitFullscreen();
                    }
                    e.preventDefault();
                    break;
            }
        });
    }
    
    async initializeWebSimAPI() {
        try {
            /* @tweakable WebSim API detection timeout */
            const apiDetectionTimeout = 2000; // milliseconds
            
            // Check for native browser screen recording capabilities first
            if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
                console.log('Native screen recording API available');
                this.websimAPI = {
                    startRecording: async (options) => {
                        // This will be handled by the RecordingManager using MediaRecorder API
                        return { success: true, sessionId: 'native-' + Date.now() };
                    },
                    stopRecording: async (sessionId) => {
                        return { success: true, recordingUrl: null };
                    },
                    getStatus: async (sessionId) => {
                        return { status: 'recording', duration: this.recordingStartTime ? Date.now() - this.recordingStartTime : 0 };
                    }
                };
                return;
            }
            
            // Check for WebSim-specific recording APIs
            if (typeof window.websim !== 'undefined' && window.websim.screenRecorder) {
                console.log('WebSim Screen Recorder API detected');
                this.websimAPI = window.websim.screenRecorder;
            } else if (typeof WebSim !== 'undefined' && WebSim.screenRecorder) {
                console.log('WebSim Screen Recorder API (global) detected');
                this.websimAPI = WebSim.screenRecorder;
            } else if (typeof window.websim !== 'undefined' && window.websim.recording) {
                console.log('WebSim Recording API detected');
                this.websimAPI = window.websim.recording;
            } else {
                console.log('No supported recording API available, using enhanced fallback');
                this.websimAPI = this.createEnhancedFallbackAPI();
            }
        } catch (error) {
            console.error('Error initializing WebSim API:', error);
            this.websimAPI = this.createEnhancedFallbackAPI();
        }
    }
    
    createEnhancedFallbackAPI() {
        return {
            startRecording: async (options) => {
                console.log('Enhanced fallback recording started with options:', options);
                
                /* @tweakable fallback recording simulation parameters */
                const simulationDelay = 500;
                
                // Simulate API processing
                await new Promise(resolve => setTimeout(resolve, simulationDelay));
                
                throw new Error('Screen recording not supported. Please use a browser that supports getDisplayMedia API or enable screen sharing permissions.');
            },
            stopRecording: async (sessionId) => {
                console.log('Enhanced fallback recording stopped for session:', sessionId);
                return { success: false, error: 'Recording not supported' };
            },
            getStatus: async (sessionId) => {
                return { status: 'unsupported', duration: 0 };
            }
        };
    }
    
    createFallbackAPI() {
        // Keep the old fallback for compatibility
        return this.createEnhancedFallbackAPI();
    }
    
    async loadContent() {
        const url = this.urlInput.value.trim();
        if (!url) return;
        
        this.updateStatus('Loading...', 'loading');
        
        try {
            let validUrl = url;
            if (!url.startsWith('http://') && !url.startsWith('https://') && url !== 'about:blank') {
                validUrl = 'https://' + url;
            }
            
            this.contentFrame.src = validUrl;
            this.welcomeScreen.style.display = 'none';
            this.contentFrame.style.display = 'block';
            
            this.contentFrame.onload = () => {
                this.updateStatus('Content Loaded', 'ready');
            };
            
            this.contentFrame.onerror = () => {
                this.updateStatus('Load Failed', 'error');
                this.showWelcomeScreen();
            };
            
        } catch (error) {
            console.error('Error loading content:', error);
            this.updateStatus('Load Error', 'error');
            this.showWelcomeScreen();
        }
    }
    
    async handleMainMediaUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        try {
            /* @tweakable supported media file types and size limits for main content */
            const maxMediaSize = 200 * 1024 * 1024; // 200MB limit for main content media
            const supportedVideoTypes = [
                'video/mp4', 'video/webm', 'video/ogg', 'video/avi', 'video/mov', 
                'video/wmv', 'video/flv', 'video/mkv', 'video/3gp', 'video/m4v',
                'video/quicktime', 'video/x-msvideo'
            ];
            const supportedAudioTypes = [
                'audio/mp3', 'audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/aac', 
                'audio/m4a', 'audio/webm', 'audio/flac', 'audio/wma'
            ];
            
            if (file.size > maxMediaSize) {
                alert('Media file too large. Maximum allowed size is 200MB.');
                return;
            }
            
            const fileType = file.type;
            const isVideo = supportedVideoTypes.includes(fileType) || this.isVideoFileByExtension(file.name);
            const isAudio = supportedAudioTypes.includes(fileType) || this.isAudioFileByExtension(file.name);
            
            if (!isVideo && !isAudio) {
                alert('Unsupported media format. Please select a video or audio file.');
                return;
            }
            
            this.updateStatus('Loading Media...', 'loading');
            
            const reader = new FileReader();
            reader.onload = async (e) => {
                const mediaData = {
                    type: fileType || (isVideo ? 'video/mp4' : 'audio/mpeg'),
                    data: e.target.result,
                    name: file.name,
                    size: file.size,
                    isVideo: isVideo,
                    isAudio: isAudio
                };
                
                // Update media info display
                this.updateMediaInfoDisplay(mediaData);
                
                // Load media into content area
                await this.loadMediaContent(mediaData);
                
                console.log(`Main media loaded: ${file.name} (${isVideo ? 'video' : 'audio'})`);
            };
            
            reader.readAsDataURL(file);
            
        } catch (error) {
            console.error('Error handling main media upload:', error);
            alert('Error loading media file: ' + error.message);
            this.updateStatus('Media Load Error', 'error');
        }
    }
    
    updateMediaInfoDisplay(mediaData) {
        this.mediaFileName.textContent = ` ${mediaData.name}`;
        this.mediaFileSize.textContent = `(${this.formatFileSize(mediaData.size)})`;
        this.mediaInfoDisplay.style.display = 'block';
    }
    
    async loadMediaContent(mediaData) {
        try {
            // Hide welcome screen and clear existing content
            this.welcomeScreen.style.display = 'none';
            this.contentFrame.style.display = 'none';
            
            // Create media element
            let mediaElement;
            const { type, data, isVideo, isAudio, name } = mediaData;
            
            if (isVideo) {
                mediaElement = document.createElement('video');
                mediaElement.src = data;
                
                /* @tweakable comprehensive media control hiding for video elements */
                mediaElement.controls = !this.hideMediaControls.checked;
                mediaElement.controlsList = this.hideMediaControls.checked ? 'nodownload nofullscreen noremoteplayback' : '';
                mediaElement.disablePictureInPicture = this.hideMediaControls.checked;
                mediaElement.disableRemotePlayback = this.hideMediaControls.checked;
                
                /* @tweakable context menu and interaction control for video */
                if (this.hideMediaControls.checked) {
                    mediaElement.oncontextmenu = (e) => e.preventDefault();
                    mediaElement.style.pointerEvents = 'none';
                    mediaElement.addEventListener('contextmenu', (e) => e.preventDefault());
                    mediaElement.addEventListener('selectstart', (e) => e.preventDefault());
                    mediaElement.style.webkitUserSelect = 'none';
                    mediaElement.style.userSelect = 'none';
                }
                
                mediaElement.autoplay = true; // Always autoplay for better UX
                mediaElement.muted = false; // Allow audio for main content

                if (this.maintainAspectRatio.checked) {
                    try {
                        const dimensions = await this.extractVideoDimensions(data);
                        if (dimensions.width && dimensions.height) {
                            const aspectRatio = dimensions.width / dimensions.height;
                            mediaElement.style.aspectRatio = aspectRatio;
                            mediaElement.style.objectFit = 'contain';
                            console.log(`Video aspect ratio applied: ${aspectRatio}`);
                        }
                    } catch (error) {
                        console.warn('Could not extract video dimensions:', error);
                    }
                }
                
                mediaElement.style.width = '100%';
                mediaElement.style.height = '100%';
                mediaElement.style.maxWidth = '100%';
                mediaElement.style.maxHeight = '100%';
                
            } else if (isAudio) {
                // Create audio player container
                const audioContainer = document.createElement('div');
                audioContainer.style.display = 'flex';
                audioContainer.style.flexDirection = 'column';
                audioContainer.style.alignItems = 'center';
                audioContainer.style.justifyContent = 'center';
                audioContainer.style.height = '100%';
                audioContainer.style.background = 'linear-gradient(135deg, #2d3748 0%, #1a202c 100%)';
                audioContainer.style.color = 'white';
                
                audioContainer.innerHTML = `
                    <div style="text-align: center; margin-bottom: 30px;">
                        <div style="font-size: 64px; margin-bottom: 20px;"></div>
                        <h2 style="margin: 0 0 10px 0; font-size: 24px;">${name}</h2>
                        <p style="margin: 0; opacity: 0.7;">Audio Player</p>
                    </div>
                `;
                
                const audio = document.createElement('audio');
                audio.src = data;
                
                /* @tweakable comprehensive media control hiding for audio elements */
                audio.controls = !this.hideMediaControls.checked;
                audio.controlsList = this.hideMediaControls.checked ? 'nodownload noremoteplayback' : '';
                audio.disableRemotePlayback = this.hideMediaControls.checked;
                
                /* @tweakable context menu and interaction control for audio */
                if (this.hideMediaControls.checked) {
                    audio.oncontextmenu = (e) => e.preventDefault();
                    audio.style.pointerEvents = 'none';
                    audio.addEventListener('contextmenu', (e) => e.preventDefault());
                    audio.addEventListener('selectstart', (e) => e.preventDefault());
                    audio.style.webkitUserSelect = 'none';
                    audio.style.userSelect = 'none';
                }
                
                audio.autoplay = true; // Always autoplay for better UX
                audio.style.width = '80%';
                audio.style.maxWidth = '600px';
                
                audioContainer.appendChild(audio);
                mediaElement = audioContainer;
            }
            
            // Clear content display and add media element
            this.contentDisplay.innerHTML = '';
            this.contentDisplay.appendChild(mediaElement);
            
            this.updateStatus('Media Loaded', 'ready');
            
        } catch (error) {
            console.error('Error loading media content:', error);
            this.updateStatus('Media Load Error', 'error');
            this.showWelcomeScreen();
        }
    }
    
    isVideoFileByExtension(filename) {
        const videoExtensions = ['.mp4', '.webm', '.ogg', '.avi', '.mov', '.wmv', '.flv', '.mkv', '.3gp', '.m4v'];
        const extension = filename.toLowerCase().substring(filename.lastIndexOf('.'));
        return videoExtensions.includes(extension);
    }
    
    isAudioFileByExtension(filename) {
        const audioExtensions = ['.mp3', '.wav', '.ogg', '.aac', '.m4a', '.webm', '.flac', '.wma'];
        const extension = filename.toLowerCase().substring(filename.lastIndexOf('.'));
        return audioExtensions.includes(extension);
    }
    
    extractVideoDimensions(dataUrl) {
        return new Promise((resolve, reject) => {
            const video = document.createElement('video');
            video.onloadedmetadata = () => {
                resolve({
                    width: video.videoWidth,
                    height: video.videoHeight
                });
            };
            video.onerror = () => {
                reject(new Error('Failed to load video for dimension extraction'));
            };
            setTimeout(() => {
                reject(new Error('Video dimension extraction timeout'));
            }, 5000);
            video.src = dataUrl;
        });
    }
    
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    showWelcomeScreen() {
        this.contentFrame.style.display = 'none';
        const mediaElements = this.contentDisplay.querySelectorAll('video, audio, div');
        mediaElements.forEach(el => {
            if (el !== this.welcomeScreen && el !== this.contentFrame) {
                el.remove();
            }
        });
        this.welcomeScreen.style.display = 'flex';
        if (this.mediaInfoDisplay) {
            this.mediaInfoDisplay.style.display = 'none';
        }
    }

    updateStatus(text, type) {
        this.statusText.textContent = text;
        this.statusDot.className = 'status-dot';
        
        switch (type) {
            case 'ready':
                this.statusDot.style.background = '#48bb78';
                break;
            case 'loading':
                this.statusDot.style.background = '#ed8936';
                break;
            case 'recording':
                this.statusDot.style.background = '#f56565';
                break;
            case 'error':
                this.statusDot.style.background = '#e53e3e';
                break;
        }
    }
    
    handleResize() {
        this.cameraManager.handleResize();
        this.uiManager.handleResize();
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new StreamingStudio();
});