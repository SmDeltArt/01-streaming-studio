// ================================================
// TEXT DISPLAY SYSTEM MODULE
// ================================================

export class TextManager {
    constructor(recorderManager) {
        this.recorderManager = recorderManager;
        this.activeTexts = new Map();
        this.textIdCounter = 0;
        this.isTextControlPanelOpen = false;
        this.currentEditingTextId = null;
        this.isTextPanelCollapsed = false;
        
        // TTS properties
        this.currentSpeech = null;
        this.availableVoices = [];
        this.isPlaying = false;
        this.speechQueue = [];
        
        // Default text properties
        this.defaultTextProperties = {
            content: 'Sample Text',
            fontFamily: 'Arial',
            fontSize: 48,
            fontWeight: 'normal',
            fontStyle: 'normal',
            color: '#ffffff',
            strokeColor: '#000000',
            strokeWidth: 0,
            opacity: 1.0,
            backgroundColor: 'rgba(0,0,0,0)',
            padding: 10,
            borderRadius: 5,
            x: 50,
            y: 50,
            zIndex: 1000,
            displayTime: 3000,
            animation: 'none',
            animationDuration: 1000,
            animationDelay: 0,
            textAlign: 'left',
            lineHeight: 1.2,
            letterSpacing: 0,
            textShadow: 'none',
            gradient: 'none',
            gradientColors: ['#ffffff', '#cccccc'],
            blinkInterval: 500,
            scrollDirection: 'left',
            scrollSpeed: 50,
            // TTS properties
            enableTTS: false,
            voiceIndex: 0,
            speechRate: 1.0,
            speechPitch: 1.0,
            speechVolume: 1.0,
            autoTranslate: false,
            targetLanguage: 'en',
            soundEffect: 'none',
            readOnDisplay: false
        };
        
        this.availableFonts = [
            'Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 
            'Georgia', 'Helvetica', 'Impact', 'Lucida Console', 
            'Palatino', 'Times New Roman', 'Trebuchet MS', 'Verdana'
        ];
        
        this.availableAnimations = [
            { value: 'none', name: 'None' },
            { value: 'fadeIn', name: '🌅 Fade In' },
            { value: 'fadeOut', name: '🌄 Fade Out' },
            { value: 'slideInLeft', name: '⬅️ Slide In Left' },
            { value: 'slideInRight', name: '➡️ Slide In Right' },
            { value: 'slideInTop', name: '⬆️ Slide In Top' },
            { value: 'slideInBottom', name: '⬇️ Slide In Bottom' },
            { value: 'zoomIn', name: '🔍 Zoom In' },
            { value: 'zoomOut', name: '🔎 Zoom Out' },
            { value: 'bounce', name: '🏀 Bounce' },
            { value: 'shake', name: '🔔 Shake' },
            { value: 'pulse', name: '💓 Pulse' },
            { value: 'flash', name: '⚡ Flash' },
            { value: 'flip', name: '🔄 Flip' },
            { value: 'scroll', name: '📜 Scroll' },
            { value: 'typewriter', name: '⌨️ Typewriter' }
        ];
        
        this.availableGradients = [
            { value: 'none', name: 'None' },
            { value: 'linear-horizontal', name: '➡️ Linear Horizontal' },
            { value: 'linear-vertical', name: '⬇️ Linear Vertical' },
            { value: 'radial', name: '🎯 Radial' },
            { value: 'rainbow', name: '🌈 Rainbow' },
            { value: 'sunset', name: '🌅 Sunset' },
            { value: 'ocean', name: '🌊 Ocean' },
            { value: 'fire', name: '🔥 Fire' }
        ];
        
        this.availableSoundEffects = [
            { value: 'none', name: 'None' },
            { value: 'beep', name: '🔊 Beep' },
            { value: 'chime', name: '🔔 Chime' },
            { value: 'swoosh', name: '💨 Swoosh' },
            { value: 'pop', name: '🎈 Pop' },
            { value: 'click', name: '🖱️ Click' }
        ];
        
        this.availableLanguages = [
            { code: 'en', name: 'English' },
            { code: 'es', name: 'Spanish' },
            { code: 'fr', name: 'French' },
            { code: 'de', name: 'German' },
            { code: 'it', name: 'Italian' },
            { code: 'pt', name: 'Portuguese' },
            { code: 'ru', name: 'Russian' },
            { code: 'ja', name: 'Japanese' },
            { code: 'ko', name: 'Korean' },
            { code: 'zh', name: 'Chinese' },
            { code: 'ar', name: 'Arabic' },
            { code: 'hi', name: 'Hindi' }
        ];
    }

    init() {
        this.createTextStyles();
        this.initializeTTS();
    }

    createTextStyles() {
        if (document.getElementById('text-system-styles')) return;
        
        const style = document.createElement('style');
        style.id = 'text-system-styles';
        style.textContent = `
            @keyframes textFadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            
            @keyframes textFadeOut {
                from { opacity: 1; }
                to { opacity: 0; }
            }
            
            @keyframes textSlideInLeft {
                from { transform: translateX(-100%); }
                to { transform: translateX(0); }
            }
            
            @keyframes textSlideInRight {
                from { transform: translateX(100%); }
                to { transform: translateX(0); }
            }
            
            @keyframes textSlideInTop {
                from { transform: translateY(-100%); }
                to { transform: translateY(0); }
            }
            
            @keyframes textSlideInBottom {
                from { transform: translateY(100%); }
                to { transform: translateY(0); }
            }
            
            @keyframes textZoomIn {
                from { transform: scale(0); }
                to { transform: scale(1); }
            }
            
            @keyframes textZoomOut {
                from { transform: scale(1); }
                to { transform: scale(0); }
            }
            
            @keyframes textBounce {
                0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
                40% { transform: translateY(-20px); }
                60% { transform: translateY(-10px); }
            }
            
            @keyframes textShake {
                0%, 100% { transform: translateX(0); }
                10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
                20%, 40%, 60%, 80% { transform: translateX(5px); }
            }
            
            @keyframes textPulse {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.1); }
            }
            
            @keyframes textFlash {
                0%, 100% { opacity: 1; }
                50% { opacity: 0; }
            }
            
            @keyframes textFlip {
                from { transform: rotateY(0deg); }
                to { transform: rotateY(360deg); }
            }
            
            @keyframes textScroll {
                from { transform: translateX(100vw); }
                to { transform: translateX(-100%); }
            }
            
            .text-display-element {
                position: fixed;
                pointer-events: none;
                white-space: nowrap;
                user-select: none;
                text-rendering: optimizeLegibility;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
            }
            
            .text-control-panel {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 500px;
                max-height: 90vh;
                background: rgba(255, 255, 255, 0.85);
                border: 2px solid #667eea;
                border-radius: 12px;
                z-index: 20000;
                backdrop-filter: blur(15px);
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
                overflow-y: auto;
            }
            
            .text-control-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 15px 20px;
                background: linear-gradient(135deg, rgba(102, 126, 234, 0.9) 0%, rgba(118, 75, 162, 0.9) 100%);
                color: white;
                border-radius: 10px 10px 0 0;
                margin: -2px -2px 0 -2px;
                user-select: none;
            }

            .text-header-controls {
                display: flex;
                gap: 5px;
                align-items: center;
            }
            
            .text-control-collapse,
            .text-control-close {
                background: rgba(255, 255, 255, 0.2);
                border: none;
                color: white;
                padding: 5px 10px;
                border-radius: 50%;
                cursor: pointer;
                font-size: 16px;
                width: 30px;
                height: 30px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: bold;
            }
            
            .text-control-collapse:hover,
            .text-control-close:hover {
                background: rgba(255, 255, 255, 0.3);
            }
            
            .text-control-content {
                padding: 20px;
                background: rgba(255, 255, 255, 0.05);
                backdrop-filter: blur(5px);
            }
            
            .text-section {
                margin-bottom: 20px;
                padding-bottom: 15px;
                border-bottom: 1px solid #eee;
            }
            
            .text-section:last-child {
                border-bottom: none;
                margin-bottom: 10px;
            }
            
            .text-section h4 {
                margin: 0 0 10px 0;
                color: #333;
                font-size: 14px;
                font-weight: bold;
            }
            
            .text-property-row {
                display: flex;
                align-items: center;
                gap: 10px;
                margin-bottom: 10px;
            }
            
            .text-property-row label {
                min-width: 80px;
                font-size: 12px;
                font-weight: 500;
            }
            
            .text-property-row input,
            .text-property-row select,
            .text-property-row textarea {
                flex: 1;
                padding: 4px 8px;
                border: 1px solid #ccc;
                border-radius: 4px;
                font-size: 12px;
            }
            
            .text-property-row textarea {
                min-height: 60px;
                resize: vertical;
            }
            
            .text-property-row input[type="range"] {
                height: 6px;
            }
            
            .text-property-row input[type="color"] {
                width: 40px;
                height: 30px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                padding: 0;
            }
            
            .text-property-value {
                min-width: 40px;
                font-size: 11px;
                color: #666;
                text-align: center;
            }
            
            .text-actions {
                display: flex;
                gap: 10px;
                flex-wrap: wrap;
                margin: 0;
                padding: 15px 20px;
                background: rgba(255, 255, 255, 0.05);
                border-radius: 0 0 10px 10px;
                backdrop-filter: blur(5px);
            }
            
            .text-action-btn {
                flex: 1;
                min-width: 80px;
                padding: 8px 12px;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-size: 12px;
                font-weight: bold;
                transition: all 0.2s ease;
            }
            
            .text-action-btn.primary {
                background: #28a745;
                color: white;
            }
            
            .text-action-btn.primary:hover {
                background: #218838;
            }
            
            .text-action-btn.secondary {
                background: #007bff;
                color: white;
            }
            
            .text-action-btn.secondary:hover {
                background: #0056b3;
            }
            
            .text-action-btn.danger {
                background: #dc3545;
                color: white;
            }
            
            .text-action-btn.danger:hover {
                background: #c82333;
            }
            
            .text-action-btn:not(.primary):not(.secondary):not(.danger) {
                background: #6c757d;
                color: white;
            }
            
            .text-action-btn:not(.primary):not(.secondary):not(.danger):hover {
                background: #5a6268;
            }
            
            .text-preview {
                background: #f8f9fa;
                border: 1px solid #dee2e6;
                border-radius: 6px;
                padding: 15px;
                margin: 10px 0;
                text-align: center;
                min-height: 60px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .text-list {
                max-height: 200px;
                overflow-y: auto;
                border: 1px solid #ddd;
                border-radius: 6px;
                background: rgba(0, 0, 0, 0.02);
            }
            
            .text-item {
                padding: 8px;
                border-bottom: 1px solid #eee;
                transition: background-color 0.2s ease;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .text-item:last-child {
                border-bottom: none;
            }
            
            .text-item:hover {
                background: rgba(0, 123, 255, 0.05);
            }
            
            .text-item-info {
                flex: 1;
                font-size: 12px;
            }
            
            .text-item-controls {
                display: flex;
                gap: 4px;
            }
            
            .text-item-btn {
                padding: 2px 6px;
                border: none;
                border-radius: 3px;
                cursor: pointer;
                font-size: 10px;
                background: rgba(0, 0, 0, 0.1);
                transition: all 0.2s ease;
                min-width: 20px;
                height: 20px;
            }
            
            .text-item-btn:hover {
                transform: scale(1.1);
            }
            
            .text-item-btn.edit:hover {
                background: #007bff;
                color: white;
            }
            
            .text-item-btn.remove:hover {
                background: #dc3545;
                color: white;
            }
            
            .text-item-btn.toggle:hover {
                background: #28a745;
                color: white;
            }
        `;
        document.head.appendChild(style);
    }

    initializeTTS() {
        // Initialize Speech Synthesis
        if ('speechSynthesis' in window) {
            this.loadAvailableVoices();
            // Update voices when they change (some browsers load them asynchronously)
            speechSynthesis.onvoiceschanged = () => {
                this.loadAvailableVoices();
            };
        } else {
            console.warn('Speech Synthesis not supported in this browser');
        }
    }

    loadAvailableVoices() {
        this.availableVoices = speechSynthesis.getVoices();
        console.log(`Loaded ${this.availableVoices.length} TTS voices`);
    }

    estimateSpeechDuration(text, speechRate = 1.0) {
        // Average speaking rate is about 150-200 words per minute for normal speech
        // Adjusted for speech synthesis which tends to be slightly different
        const baseWordsPerMinute = 180;
        const adjustedWPM = baseWordsPerMinute * speechRate;
        
        // Count words (simple split by whitespace)
        const wordCount = text.trim().split(/\s+/).filter(word => word.length > 0).length;
        
        // Calculate duration in milliseconds
        const durationMinutes = wordCount / adjustedWPM;
        const durationMs = Math.max(2000, durationMinutes * 60 * 1000); // Minimum 2 seconds
        
        return Math.round(durationMs);
    }

    updateAutomaticDisplayTime() {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const enableTTS = panel.querySelector('#enable-tts')?.checked;
        if (!enableTTS) return;

        const textContent = panel.querySelector('#text-content')?.value || '';
        const speechRate = parseFloat(panel.querySelector('#speech-rate')?.value || 1.0);
        
        if (textContent.trim()) {
            const estimatedDuration = this.estimateSpeechDuration(textContent, speechRate);
            
            // Update display time slider and value
            const displayTimeSlider = panel.querySelector('#text-display-time');
            const displayTimeValue = panel.querySelector('#display-time-value');
            const estimatedTimeDisplay = panel.querySelector('#estimated-speech-time');
            
            if (displayTimeSlider && displayTimeValue) {
                displayTimeSlider.value = estimatedDuration;
                displayTimeValue.textContent = (estimatedDuration / 1000).toFixed(1) + 's';
                
                // Update the visual indicator
                if (estimatedTimeDisplay) {
                    estimatedTimeDisplay.textContent = `Estimated: ${(estimatedDuration / 1000).toFixed(1)}s`;
                    estimatedTimeDisplay.style.color = '#28a745';
                }
            }
        }
    }

    showTextControlPanel() {
        // Remove existing panel if it exists
        const existingPanel = document.getElementById('text-control-panel');
        if (existingPanel) {
            existingPanel.remove();
        }

        this.isTextControlPanelOpen = true;
        this.isTextPanelCollapsed = false;
        const panel = document.createElement('div');
        panel.id = 'text-control-panel';
        panel.className = 'text-control-panel';
        
        panel.innerHTML = `
            <div class="text-control-header">
                <div class="text-control-title">📝 Text Display Manager</div>
                <div class="text-header-controls">
                    <button class="text-control-collapse" title="Collapse/Expand">−</button>
                    <button class="text-control-close">×</button>
                </div>
            </div>
            <div class="text-control-content" id="text-control-content">
                <div class="text-section">
                    <h4>📝 Text Content</h4>
                    <div class="text-property-row">
                        <label>Text:</label>
                        <textarea id="text-content" placeholder="Enter your text here..." style="min-height: 80px; white-space: pre-wrap; word-wrap: break-word;">${this.defaultTextProperties.content}</textarea>
                    </div>
                </div>
                
                <div class="text-section">
                    <h4>🔊 Text-to-Speech</h4>
                    <div class="text-property-row">
                        <label>
                            <input type="checkbox" id="enable-tts" ${this.defaultTextProperties.enableTTS ? 'checked' : ''}>
                            Enable TTS (Auto-adjusts timing)
                        </label>
                    </div>
                    <div class="text-property-row">
                        <label>Voice:</label>
                        <select id="tts-voice">
                            <option value="0">Default Voice</option>
                        </select>
                    </div>
                    <div class="text-property-row">
                        <label>Rate:</label>
                        <input type="range" id="speech-rate" min="0.1" max="2" step="0.1" value="${this.defaultTextProperties.speechRate}">
                        <span class="text-property-value" id="speech-rate-value">${this.defaultTextProperties.speechRate}x</span>
                    </div>
                    <div class="text-property-row">
                        <label>Pitch:</label>
                        <input type="range" id="speech-pitch" min="0" max="2" step="0.1" value="${this.defaultTextProperties.speechPitch}">
                        <span class="text-property-value" id="speech-pitch-value">${this.defaultTextProperties.speechPitch}</span>
                    </div>
                    <div class="text-property-row">
                        <label>Volume:</label>
                        <input type="range" id="speech-volume" min="0" max="1" step="0.1" value="${this.defaultTextProperties.speechVolume}">
                        <span class="text-property-value" id="speech-volume-value">${Math.round(this.defaultTextProperties.speechVolume * 100)}%</span>
                    </div>
                    <div class="text-property-row">
                        <label>
                            <input type="checkbox" id="read-on-display" ${this.defaultTextProperties.readOnDisplay ? 'checked' : ''}>
                            Read when displayed
                        </label>
                    </div>
                    <div class="text-property-row">
                        <div style="font-size: 11px; color: #666; font-style: italic;" id="estimated-speech-time">
                            Auto-timing disabled
                        </div>
                    </div>
                    <div class="text-property-row">
                        <button id="test-speech-btn" class="text-action-btn secondary">🔊 Test Voice</button>
                        <button id="stop-speech-btn" class="text-action-btn">⏹️ Stop</button>
                    </div>
                </div>
                
                <div class="text-section">
                    <h4>🌐 Translation</h4>
                    <div class="text-property-row">
                        <label>
                            <input type="checkbox" id="auto-translate" ${this.defaultTextProperties.autoTranslate ? 'checked' : ''}>
                            Auto Translate
                        </label>
                    </div>
                    <div class="text-property-row">
                        <label>To Language:</label>
                        <select id="target-language">
                            ${this.availableLanguages.map(lang => 
                                `<option value="${lang.code}" ${lang.code === this.defaultTextProperties.targetLanguage ? 'selected' : ''}>${lang.name}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <div class="text-property-row">
                        <button id="translate-now-btn" class="text-action-btn secondary">🔄 Translate Now</button>
                        <button id="restore-original-btn" class="text-action-btn">↩️ Original</button>
                    </div>
                </div>
                
                <div class="text-section">
                    <h4>🎵 Sound Effects</h4>
                    <div class="text-property-row">
                        <label>Effect:</label>
                        <select id="sound-effect">
                            ${this.availableSoundEffects.map(effect => 
                                `<option value="${effect.value}" ${effect.value === this.defaultTextProperties.soundEffect ? 'selected' : ''}>${effect.name}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <div class="text-property-row">
                        <button id="test-sound-btn" class="text-action-btn secondary">🎵 Test Sound</button>
                    </div>
                </div>
                
                <div class="text-section">
                    <h4>🎨 Font & Style</h4>
                    <div class="text-property-row">
                        <label>Font:</label>
                        <select id="text-font-family">
                            ${this.availableFonts.map(font => 
                                `<option value="${font}" ${font === this.defaultTextProperties.fontFamily ? 'selected' : ''}>${font}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <div class="text-property-row">
                        <label>Size:</label>
                        <input type="range" id="text-font-size" min="12" max="200" value="${this.defaultTextProperties.fontSize}">
                        <span class="text-property-value" id="font-size-value">${this.defaultTextProperties.fontSize}px</span>
                    </div>
                    <div class="text-property-row">
                        <label>Weight:</label>
                        <select id="text-font-weight">
                            <option value="normal" ${this.defaultTextProperties.fontWeight === 'normal' ? 'selected' : ''}>Normal</option>
                            <option value="bold" ${this.defaultTextProperties.fontWeight === 'bold' ? 'selected' : ''}>Bold</option>
                            <option value="lighter" ${this.defaultTextProperties.fontWeight === 'lighter' ? 'selected' : ''}>Lighter</option>
                        </select>
                    </div>
                    <div class="text-property-row">
                        <label>Style:</label>
                        <select id="text-font-style">
                            <option value="normal" ${this.defaultTextProperties.fontStyle === 'normal' ? 'selected' : ''}>Normal</option>
                            <option value="italic" ${this.defaultTextProperties.fontStyle === 'italic' ? 'selected' : ''}>Italic</option>
                        </select>
                    </div>
                </div>
                
                <div class="text-section">
                    <h4>🌈 Colors & Effects</h4>
                    <div class="text-property-row">
                        <label>Text Color:</label>
                        <input type="color" id="text-color" value="${this.defaultTextProperties.color}">
                    </div>
                    <div class="text-property-row">
                        <label>Stroke Color:</label>
                        <input type="color" id="text-stroke-color" value="${this.defaultTextProperties.strokeColor}">
                    </div>
                    <div class="text-property-row">
                        <label>Stroke Width:</label>
                        <input type="range" id="text-stroke-width" min="0" max="10" step="0.5" value="${this.defaultTextProperties.strokeWidth}">
                        <span class="text-property-value" id="stroke-width-value">${this.defaultTextProperties.strokeWidth}px</span>
                    </div>
                    <div class="text-property-row">
                        <label>Gradient:</label>
                        <select id="text-gradient">
                            ${this.availableGradients.map(gradient => 
                                `<option value="${gradient.value}" ${gradient.value === this.defaultTextProperties.gradient ? 'selected' : ''}>${gradient.name}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <div class="text-property-row">
                        <label>Opacity:</label>
                        <input type="range" id="text-opacity" min="0" max="1" step="0.05" value="${this.defaultTextProperties.opacity}">
                        <span class="text-property-value" id="opacity-value">${Math.round(this.defaultTextProperties.opacity * 100)}%</span>
                    </div>
                </div>
                
                <div class="text-section">
                    <h4>📍 Position & Layout</h4>
                    <div class="text-property-row">
                        <label>X Position:</label>
                        <input type="range" id="text-x" min="0" max="100" value="${this.defaultTextProperties.x}">
                        <span class="text-property-value" id="x-value">${this.defaultTextProperties.x}%</span>
                    </div>
                    <div class="text-property-row">
                        <label>Y Position:</label>
                        <input type="range" id="text-y" min="0" max="100" value="${this.defaultTextProperties.y}">
                        <span class="text-property-value" id="y-value">${this.defaultTextProperties.y}%</span>
                    </div>
                    <div class="text-property-row">
                        <label>Text Align:</label>
                        <select id="text-align">
                            <option value="left">Left</option>
                            <option value="center">Center</option>
                            <option value="right">Right</option>
                        </select>
                    </div>
                </div>
                
                <div class="text-section">
                    <h4>⏰ Timing & Animation</h4>
                    <div class="text-property-row">
                        <label>Display Time:</label>
                        <input type="range" id="text-display-time" min="1000" max="40000" step="100" value="${this.defaultTextProperties.displayTime}">
                        <span class="text-property-value" id="display-time-value">${this.defaultTextProperties.displayTime / 1000}s</span>
                    </div>
                    <div class="text-property-row">
                        <label>Animation:</label>
                        <select id="text-animation">
                            ${this.availableAnimations.map(animation => 
                                `<option value="${animation.value}" ${animation.value === this.defaultTextProperties.animation ? 'selected' : ''}>${animation.name}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <div class="text-property-row">
                        <label>Duration:</label>
                        <input type="range" id="text-animation-duration" min="100" max="30000" step="50" value="${this.defaultTextProperties.animationDuration}">
                        <span class="text-property-value" id="animation-duration-value">${this.defaultTextProperties.animationDuration}ms</span>
                    </div>
                    <div class="text-property-row">
                        <label>Delay:</label>
                        <input type="range" id="text-animation-delay" min="0" max="2000" step="50" value="${this.defaultTextProperties.animationDelay}">
                        <span class="text-property-value" id="animation-delay-value">${this.defaultTextProperties.animationDelay}ms</span>
                    </div>
                </div>
                
                <div class="text-section">
                    <h4>👁️ Preview</h4>
                    <div class="text-preview" id="text-preview">
                        ${this.defaultTextProperties.content}
                    </div>
                </div>
            </div>
                
            <div class="text-actions" id="text-actions">
                <button id="preview-text-btn" class="text-action-btn secondary">👁️ Preview</button>
                <button id="add-text-display-btn" class="text-action-btn primary">➕ Add Text</button>
                <button id="save-text-preset-btn" class="text-action-btn">💾 Save Preset</button>
                <button id="load-text-preset-btn" class="text-action-btn">📂 Load Preset</button>
                <button id="clear-all-texts-btn" class="text-action-btn danger">🗑️ Clear All</button>
            </div>
        `;

        document.body.appendChild(panel);
        this.setupTextControlEvents(panel);
        this.setupTextPanelDragging(panel);
        this.populateVoices();
        this.updatePreview();
        this.updateAutomaticDisplayTime(); // Initial update
    }

    populateVoices() {
        const voiceSelect = document.getElementById('tts-voice');
        if (!voiceSelect) return;

        // Clear existing options except default
        while (voiceSelect.children.length > 1) {
            voiceSelect.removeChild(voiceSelect.lastChild);
        }

        // Filter voices to include only one Arabic or Chinese voice
        const filteredVoices = this.availableVoices.filter((voice, index) => {
            const lang = voice.lang.toLowerCase();
            if (lang.includes('ar') || lang.includes('zh')) {
                // Only include the first Arabic or Chinese voice found
                return this.availableVoices.findIndex(v => {
                    const vLang = v.lang.toLowerCase();
                    return vLang.includes('ar') || vLang.includes('zh');
                }) === index;
            }
            return true; // Include all other voices
        });

        filteredVoices.forEach((voice, index) => {
            const option = document.createElement('option');
            option.value = index;
            option.textContent = `${voice.name} (${voice.lang})`;
            voiceSelect.appendChild(option);
        });
    }

    setupTextPanelDragging(panel) {
        const header = panel.querySelector('.text-control-header');
        let isDragging = false;
        let dragOffset = { x: 0, y: 0 };

        header.addEventListener('mousedown', (e) => {
            // Don't start dragging if clicking on buttons
            if (e.target.classList.contains('text-control-close') || 
                e.target.classList.contains('text-control-collapse')) {
                return;
            }
            
            isDragging = true;
            const rect = panel.getBoundingClientRect();
            dragOffset.x = e.clientX - rect.left;
            dragOffset.y = e.clientY - rect.top;
            panel.style.cursor = 'grabbing';
            header.style.cursor = 'grabbing';
        });

        document.addEventListener('mousemove', (e) => {
            if (isDragging) {
                const x = e.clientX - dragOffset.x;
                const y = e.clientY - dragOffset.y;
                
                // Allow 95% off-screen positioning
                const maxX = window.innerWidth - (panel.offsetWidth * 0.05);
                const maxY = window.innerHeight - (panel.offsetHeight * 0.05);
                const minX = -(panel.offsetWidth * 0.95);
                const minY = -(panel.offsetHeight * 0.95);
                
                panel.style.left = `${Math.max(minX, Math.min(x, maxX))}px`;
                panel.style.top = `${Math.max(minY, Math.min(y, maxY))}px`;
                panel.style.transform = 'none';
            }
        });

        document.addEventListener('mouseup', () => {
            isDragging = false;
            panel.style.cursor = 'default';
            header.style.cursor = 'grab';
        });

        // Set initial cursor
        header.style.cursor = 'grab';
    }

    setupTextControlEvents(panel) {
        const closeBtn = panel.querySelector('.text-control-close');
        const collapseBtn = panel.querySelector('.text-control-collapse');
        const content = panel.querySelector('#text-control-content');
        
        closeBtn.addEventListener('click', () => this.closeTextControlPanel());
        
        collapseBtn.addEventListener('click', () => {
            this.isTextPanelCollapsed = !this.isTextPanelCollapsed;
            
            if (this.isTextPanelCollapsed) {
                content.style.display = 'none';
                collapseBtn.textContent = '+';
                collapseBtn.title = 'Expand';
                panel.style.height = 'auto';
            } else {
                content.style.display = 'block';
                collapseBtn.textContent = '−';
                collapseBtn.title = 'Collapse';
            }
        });

        // Real-time preview updates
        const inputs = panel.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('input', () => this.updatePreview());
        });

        // Value displays
        panel.querySelector('#text-font-size').addEventListener('input', (e) => {
            panel.querySelector('#font-size-value').textContent = e.target.value + 'px';
        });

        panel.querySelector('#text-stroke-width').addEventListener('input', (e) => {
            panel.querySelector('#stroke-width-value').textContent = e.target.value + 'px';
        });

        panel.querySelector('#text-opacity').addEventListener('input', (e) => {
            panel.querySelector('#opacity-value').textContent = Math.round(e.target.value * 100) + '%';
        });

        panel.querySelector('#text-x').addEventListener('input', (e) => {
            panel.querySelector('#x-value').textContent = e.target.value + '%';
        });

        panel.querySelector('#text-y').addEventListener('input', (e) => {
            panel.querySelector('#y-value').textContent = e.target.value + '%';
        });

        panel.querySelector('#text-display-time').addEventListener('input', (e) => {
            panel.querySelector('#display-time-value').textContent = (e.target.value / 1000) + 's';
        });

        panel.querySelector('#text-animation-duration').addEventListener('input', (e) => {
            panel.querySelector('#animation-duration-value').textContent = e.target.value + 'ms';
        });

        panel.querySelector('#text-animation-delay').addEventListener('input', (e) => {
            panel.querySelector('#animation-delay-value').textContent = e.target.value + 'ms';
        });

        // TTS event listeners with auto-timing
        const enableTTSCheckbox = panel.querySelector('#enable-tts');
        const voiceSelect = panel.querySelector('#tts-voice');
        const speechRateSlider = panel.querySelector('#speech-rate');
        const speechPitchSlider = panel.querySelector('#speech-pitch');
        const speechVolumeSlider = panel.querySelector('#speech-volume');
        const testSpeechBtn = panel.querySelector('#test-speech-btn');
        const stopSpeechBtn = panel.querySelector('#stop-speech-btn');
        const readOnDisplayCheckbox = panel.querySelector('#read-on-display');
        const textContentTextarea = panel.querySelector('#text-content');

        if (enableTTSCheckbox) {
            enableTTSCheckbox.addEventListener('change', (e) => {
                this.updatePreview();
                if (e.target.checked) {
                    this.updateAutomaticDisplayTime();
                } else {
                    // Reset estimated time display
                    const estimatedTimeDisplay = panel.querySelector('#estimated-speech-time');
                    if (estimatedTimeDisplay) {
                        estimatedTimeDisplay.textContent = 'Auto-timing disabled';
                        estimatedTimeDisplay.style.color = '#666';
                    }
                }
            });
        }
        
        if (voiceSelect) voiceSelect.addEventListener('change', () => this.updatePreview());
        
        if (speechRateSlider) {
            speechRateSlider.addEventListener('input', (e) => {
                panel.querySelector('#speech-rate-value').textContent = e.target.value + 'x';
                this.updatePreview();
                this.updateAutomaticDisplayTime();
            });
        }
        
        if (speechPitchSlider) {
            speechPitchSlider.addEventListener('input', (e) => {
                panel.querySelector('#speech-pitch-value').textContent = e.target.value;
                this.updatePreview();
            });
        }
        
        if (speechVolumeSlider) {
            speechVolumeSlider.addEventListener('input', (e) => {
                panel.querySelector('#speech-volume-value').textContent = Math.round(e.target.value * 100) + '%';
                this.updatePreview();
            });
        }
        
        if (textContentTextarea) {
            textContentTextarea.addEventListener('input', () => {
                this.updatePreview();
                this.updateAutomaticDisplayTime();
            });
        }
        
        if (testSpeechBtn) testSpeechBtn.addEventListener('click', () => this.testSpeech());
        if (stopSpeechBtn) stopSpeechBtn.addEventListener('click', () => this.stopSpeech());
        if (readOnDisplayCheckbox) readOnDisplayCheckbox.addEventListener('change', () => this.updatePreview());

        // Translation event listeners
        const autoTranslateCheckbox = panel.querySelector('#auto-translate');
        const targetLanguageSelect = panel.querySelector('#target-language');
        const translateNowBtn = panel.querySelector('#translate-now-btn');
        const restoreOriginalBtn = panel.querySelector('#restore-original-btn');

        if (autoTranslateCheckbox) autoTranslateCheckbox.addEventListener('change', () => this.updatePreview());
        if (targetLanguageSelect) targetLanguageSelect.addEventListener('change', () => this.updatePreview());
        if (translateNowBtn) translateNowBtn.addEventListener('click', () => this.translateText());
        if (restoreOriginalBtn) restoreOriginalBtn.addEventListener('click', () => this.restoreOriginalText());

        // Sound effect listeners
        const soundEffectSelect = panel.querySelector('#sound-effect');
        const testSoundBtn = panel.querySelector('#test-sound-btn');

        if (soundEffectSelect) soundEffectSelect.addEventListener('change', () => this.updatePreview());
        if (testSoundBtn) testSoundBtn.addEventListener('click', () => this.testSoundEffect());

        // Action buttons
        panel.querySelector('#preview-text-btn').addEventListener('click', () => this.previewText());
        panel.querySelector('#add-text-display-btn').addEventListener('click', () => this.addTextDisplay());
        panel.querySelector('#save-text-preset-btn').addEventListener('click', () => this.saveTextPreset());
        panel.querySelector('#load-text-preset-btn').addEventListener('click', () => this.loadTextPreset());
        panel.querySelector('#clear-all-texts-btn').addEventListener('click', () => this.clearAllTexts());
    }

    updatePreview() {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const preview = panel.querySelector('#text-preview');
        const properties = this.getTextPropertiesFromPanel(panel);
        
        this.applyTextStyle(preview, properties);
        preview.textContent = properties.content || 'Sample Text';
    }

    getTextPropertiesFromPanel(panel) {
        return {
            content: panel.querySelector('#text-content').value,
            fontFamily: panel.querySelector('#text-font-family').value,
            fontSize: parseInt(panel.querySelector('#text-font-size').value),
            fontWeight: panel.querySelector('#text-font-weight').value,
            fontStyle: panel.querySelector('#text-font-style').value,
            color: panel.querySelector('#text-color').value,
            strokeColor: panel.querySelector('#text-stroke-color').value,
            strokeWidth: parseFloat(panel.querySelector('#text-stroke-width').value),
            opacity: parseFloat(panel.querySelector('#text-opacity').value),
            x: parseInt(panel.querySelector('#text-x').value),
            y: parseInt(panel.querySelector('#text-y').value),
            textAlign: panel.querySelector('#text-align').value,
            displayTime: parseInt(panel.querySelector('#text-display-time').value),
            animation: panel.querySelector('#text-animation').value,
            animationDuration: parseInt(panel.querySelector('#text-animation-duration').value),
            animationDelay: parseInt(panel.querySelector('#text-animation-delay').value),
            gradient: panel.querySelector('#text-gradient').value,
            zIndex: 1000,
            // TTS properties
            enableTTS: panel.querySelector('#enable-tts')?.checked || false,
            voiceIndex: parseInt(panel.querySelector('#tts-voice')?.value || 0),
            speechRate: parseFloat(panel.querySelector('#speech-rate')?.value || 1.0),
            speechPitch: parseFloat(panel.querySelector('#speech-pitch')?.value || 1.0),
            speechVolume: parseFloat(panel.querySelector('#speech-volume')?.value || 1.0),
            readOnDisplay: panel.querySelector('#read-on-display')?.checked || false,
            autoTranslate: panel.querySelector('#auto-translate')?.checked || false,
            targetLanguage: panel.querySelector('#target-language')?.value || 'en',
            soundEffect: panel.querySelector('#sound-effect')?.value || 'none'
        };
    }

    applyTextStyle(element, properties) {
        let background = 'transparent';
        if (properties.gradient && properties.gradient !== 'none') {
            background = this.createGradientBackground(properties.gradient);
        }

        element.style.fontFamily = properties.fontFamily;
        element.style.fontSize = properties.fontSize + 'px';
        element.style.fontWeight = properties.fontWeight;
        element.style.fontStyle = properties.fontStyle;
        element.style.color = properties.color;
        element.style.opacity = properties.opacity;
        element.style.textAlign = properties.textAlign;
        element.style.background = background;
        element.style.webkitBackgroundClip = background !== 'transparent' ? 'text' : 'unset';
        element.style.webkitTextFillColor = background !== 'transparent' ? 'transparent' : properties.color;
        
        if (properties.strokeWidth > 0) {
            element.style.webkitTextStroke = `${properties.strokeWidth}px ${properties.strokeColor}`;
        } else {
            element.style.webkitTextStroke = 'none';
        }
    }

    createGradientBackground(gradientType) {
        switch (gradientType) {
            case 'linear-horizontal':
                return 'linear-gradient(90deg, #667eea, #764ba2)';
            case 'linear-vertical':
                return 'linear-gradient(180deg, #667eea, #764ba2)';
            case 'radial':
                return 'radial-gradient(circle, #667eea, #764ba2)';
            case 'rainbow':
                return 'linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #9400d3)';
            case 'sunset':
                return 'linear-gradient(90deg, #ff9a9e, #feccef, #feccef)';
            case 'ocean':
                return 'linear-gradient(90deg, #a8edea, #fed6e3)';
            case 'fire':
                return 'linear-gradient(90deg, #ff416c, #ff4b2b)';
            default:
                return 'transparent';
        }
    }

    previewText() {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const properties = this.getTextPropertiesFromPanel(panel);
        this.displayText(properties, true);
    }

    addTextDisplay() {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const properties = this.getTextPropertiesFromPanel(panel);
        const textId = this.displayText(properties, false);
        
        // Record the text addition
        if (this.recorderManager) {
            this.recorderManager.logEvent('add-text', [textId, properties]);
        }
        
        this.updateActiveTextsList();
    }

    displayText(properties, isPreview = false) {
        const textId = isPreview ? 'preview-text' : `text-${this.textIdCounter++}`;
        
        // Remove existing preview if it exists
        if (isPreview) {
            const existing = document.getElementById(textId);
            if (existing) existing.remove();
        }
        
        const textElement = document.createElement('div');
        textElement.id = textId;
        textElement.className = 'text-display-element';
        textElement.textContent = properties.content;
        
        // Position
        textElement.style.left = properties.x + '%';
        textElement.style.top = properties.y + '%';
        textElement.style.zIndex = properties.zIndex;
        textElement.style.whiteSpace = 'pre-wrap';
        textElement.style.wordWrap = 'break-word';
        textElement.style.maxWidth = '80vw';
        
        // Apply styles
        this.applyTextStyle(textElement, properties);
        
        // Apply animation
        if (properties.animation && properties.animation !== 'none') {
            this.applyAnimation(textElement, properties);
        }
        
        document.body.appendChild(textElement);
        
        // Store active text if not preview
        if (!isPreview) {
            this.activeTexts.set(textId, {
                element: textElement,
                properties: { ...properties },
                isVisible: true
            });
        }

        // Play sound effect if specified
        if (properties.soundEffect && properties.soundEffect !== 'none') {
            this.playSoundEffect(properties.soundEffect);
        }

        // Read text aloud if TTS is enabled and readOnDisplay is true
        if (properties.enableTTS && properties.readOnDisplay && !isPreview) {
            setTimeout(() => {
                this.speakText(properties.content, properties);
            }, properties.animationDelay || 0);
        }
        
        // Auto-remove after display time
        if (properties.displayTime > 0) {
            setTimeout(() => {
                if (textElement.parentNode) {
                    if (isPreview || this.activeTexts.has(textId)) {
                        textElement.remove();
                        if (!isPreview) {
                            this.activeTexts.delete(textId);
                        }
                    }
                }
            }, properties.displayTime);
        }
        
        return textId;
    }

    applyAnimation(element, properties) {
        const animationName = `text${properties.animation.charAt(0).toUpperCase() + properties.animation.slice(1)}`;
        element.style.animation = `${animationName} ${properties.animationDuration}ms ease ${properties.animationDelay}ms`;
        
        // Special handling for specific animations
        if (properties.animation === 'typewriter') {
            this.applyTypewriterEffect(element, properties);
        } else if (properties.animation === 'scroll') {
            element.style.animation = `textScroll ${properties.animationDuration}ms linear infinite`;
        }
    }

    applyTypewriterEffect(element, properties) {
        const text = element.textContent;
        element.textContent = '';
        
        let i = 0;
        const typeInterval = setInterval(() => {
            element.textContent = text.substring(0, i);
            i++;
            if (i > text.length) {
                clearInterval(typeInterval);
            }
        }, properties.animationDuration / text.length);
    }

    updateActiveTextsList() {
        // Remove this method since we're removing the Active Texts section
        return;
    }

    handleTextItemAction(textId, action) {
        const textData = this.activeTexts.get(textId);
        if (!textData) return;

        switch (action) {
            case 'edit':
                this.editText(textId);
                break;
            case 'toggle':
                this.toggleTextVisibility(textId);
                break;
            case 'remove':
                this.removeText(textId);
                break;
        }
    }

    editText(textId) {
        const textData = this.activeTexts.get(textId);
        if (!textData) return;

        // Load properties into the panel
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const props = textData.properties;
        panel.querySelector('#text-content').value = props.content;
        panel.querySelector('#text-font-family').value = props.fontFamily;
        panel.querySelector('#text-font-size').value = props.fontSize;
        panel.querySelector('#text-font-weight').value = props.fontWeight;
        panel.querySelector('#text-font-style').value = props.fontStyle;
        panel.querySelector('#text-color').value = props.color;
        panel.querySelector('#text-stroke-color').value = props.strokeColor;
        panel.querySelector('#text-stroke-width').value = props.strokeWidth;
        panel.querySelector('#text-opacity').value = props.opacity;
        panel.querySelector('#text-x').value = props.x;
        panel.querySelector('#text-y').value = props.y;
        panel.querySelector('#text-align').value = props.textAlign;
        panel.querySelector('#text-display-time').value = props.displayTime;
        panel.querySelector('#text-animation').value = props.animation;
        panel.querySelector('#text-animation-duration').value = props.animationDuration;
        panel.querySelector('#text-animation-delay').value = props.animationDelay;
        panel.querySelector('#text-gradient').value = props.gradient;

        // Update value displays
        panel.querySelector('#font-size-value').textContent = props.fontSize + 'px';
        panel.querySelector('#stroke-width-value').textContent = props.strokeWidth + 'px';
        panel.querySelector('#opacity-value').textContent = Math.round(props.opacity * 100) + '%';
        panel.querySelector('#x-value').textContent = props.x + '%';
        panel.querySelector('#y-value').textContent = props.y + '%';
        panel.querySelector('#display-time-value').textContent = (props.displayTime / 1000) + 's';
        panel.querySelector('#animation-duration-value').textContent = props.animationDuration + 'ms';
        panel.querySelector('#animation-delay-value').textContent = props.animationDelay + 'ms';

        // Change button to update mode
        const addBtn = panel.querySelector('#add-text-display-btn');
        addBtn.textContent = '💾 Update Text';
        addBtn.onclick = () => this.updateText(textId);

        this.currentEditingTextId = textId;
        this.updatePreview();
    }

    updateText(textId) {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const properties = this.getTextPropertiesFromPanel(panel);
        const textData = this.activeTexts.get(textId);
        
        if (textData) {
            // Update element
            textData.element.textContent = properties.content;
            textData.element.style.left = properties.x + '%';
            textData.element.style.top = properties.y + '%';
            this.applyTextStyle(textData.element, properties);
            
            // Update stored properties
            textData.properties = { ...properties };
            
            // Record the update
            if (this.recorderManager) {
                this.recorderManager.logEvent('update-text', [textId, properties]);
            }
            
            this.updateActiveTextsList();
        }

        // Reset button
        const addBtn = panel.querySelector('#add-text-display-btn');
        addBtn.textContent = '➕ Add Text';
        addBtn.onclick = () => this.addTextDisplay();
        this.currentEditingTextId = null;
    }

    toggleTextVisibility(textId) {
        const textData = this.activeTexts.get(textId);
        if (!textData) return;

        textData.isVisible = !textData.isVisible;
        textData.element.style.display = textData.isVisible ? 'block' : 'none';
        
        // Record the toggle
        if (this.recorderManager) {
            this.recorderManager.logEvent('toggle-text', [textId, textData.isVisible]);
        }
        
        this.updateActiveTextsList();
    }

    removeText(textId) {
        const textData = this.activeTexts.get(textId);
        if (!textData) return;

        textData.element.remove();
        this.activeTexts.delete(textId);
        
        // Record the removal
        if (this.recorderManager) {
            this.recorderManager.logEvent('remove-text', [textId]);
        }
        
        this.updateActiveTextsList();
    }

    clearAllTexts() {
        this.activeTexts.forEach((textData, textId) => {
            textData.element.remove();
        });
        this.activeTexts.clear();
        
        // Record the clear
        if (this.recorderManager) {
            this.recorderManager.logEvent('clear-all-texts', []);
        }
        
        this.updateActiveTextsList();
    }

    saveTextPreset() {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const properties = this.getTextPropertiesFromPanel(panel);
        
        // Ensure text content preserves line breaks
        const textContent = panel.querySelector('#text-content').value;
        properties.content = textContent; // This should preserve \n characters
        
        const activeTextsData = [];
        
        // Include active texts in the preset
        this.activeTexts.forEach((textData, textId) => {
            activeTextsData.push({
                id: textId,
                properties: { 
                    ...textData.properties,
                    // Ensure content from active texts also preserves formatting
                    content: textData.properties.content
                },
                isVisible: textData.isVisible
            });
        });
        
        const preset = {
            version: '1.0',
            created: new Date().toISOString(),
            properties: properties,
            activeTexts: activeTextsData,
            // Add metadata about text formatting
            formatInfo: {
                preserveLineBreaks: true,
                textareaWhitespace: 'pre-wrap'
            }
        };

        // Use JSON.stringify with proper formatting to preserve readability
        const jsonString = JSON.stringify(preset, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `text-preset-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        URL.revokeObjectURL(url);
        
        console.log('Text preset saved with preserved formatting:', {
            contentLength: properties.content.length,
            hasLineBreaks: properties.content.includes('\n'),
            lineCount: properties.content.split('\n').length
        });
    }

    loadTextPreset() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const preset = JSON.parse(e.target.result);
                    if (preset.properties) {
                        this.applyTextPreset(preset.properties);
                    }
                    
                    // Restore active texts if they exist in the preset
                    if (preset.activeTexts && Array.isArray(preset.activeTexts)) {
                        preset.activeTexts.forEach(textData => {
                            this.addTextFromRecording(textData.id, textData.properties);
                        });
                    }
                } catch (error) {
                    console.error('Failed to load text preset:', error);
                }
            };
            reader.readAsText(file);
        });
        input.click();
    }

    applyTextPreset(properties) {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        // Apply properties to panel with proper element mapping
        Object.keys(properties).forEach(key => {
            let element = null;
            
            // Handle special cases for TTS and translation elements
            switch (key) {
                case 'content':
                    element = panel.querySelector('#text-content');
                    // Ensure textarea content preserves line breaks when loaded
                    if (element) {
                        element.value = properties[key];
                        // Trigger input event to update any listeners
                        element.dispatchEvent(new Event('input', { bubbles: true }));
                    }
                    return; // Skip the general handling below
                case 'enableTTS':
                    element = panel.querySelector('#enable-tts');
                    break;
                case 'voiceIndex':
                    element = panel.querySelector('#tts-voice');
                    break;
                case 'speechRate':
                    element = panel.querySelector('#speech-rate');
                    break;
                case 'speechPitch':
                    element = panel.querySelector('#speech-pitch');
                    break;
                case 'speechVolume':
                    element = panel.querySelector('#speech-volume');
                    break;
                case 'readOnDisplay':
                    element = panel.querySelector('#read-on-display');
                    break;
                case 'autoTranslate':
                    element = panel.querySelector('#auto-translate');
                    break;
                case 'targetLanguage':
                    element = panel.querySelector('#target-language');
                    break;
                case 'soundEffect':
                    element = panel.querySelector('#sound-effect');
                    break;
                case 'fontFamily':
                    element = panel.querySelector('#text-font-family');
                    break;
                case 'fontSize':
                    element = panel.querySelector('#text-font-size');
                    break;
                case 'fontWeight':
                    element = panel.querySelector('#text-font-weight');
                    break;
                case 'fontStyle':
                    element = panel.querySelector('#text-font-style');
                    break;
                case 'strokeWidth':
                    element = panel.querySelector('#text-stroke-width');
                    break;
                case 'strokeColor':
                    element = panel.querySelector('#text-stroke-color');
                    break;
                case 'displayTime':
                    element = panel.querySelector('#text-display-time');
                    break;
                case 'animationDuration':
                    element = panel.querySelector('#text-animation-duration');
                    break;
                case 'animationDelay':
                    element = panel.querySelector('#text-animation-delay');
                    break;
                case 'textAlign':
                    element = panel.querySelector('#text-align');
                    break;
                default:
                    // Try the original kebab-case conversion for other properties
                    element = panel.querySelector(`#text-${key.replace(/([A-Z])/g, '-$1').toLowerCase()}`);
                    break;
            }
            
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = properties[key];
                } else {
                    element.value = properties[key];
                }
                element.dispatchEvent(new Event('input'));
            }
        });

        this.updatePreview();
        console.log('Text preset applied with preserved formatting');
    }

    closeTextControlPanel() {
        const panel = document.getElementById('text-control-panel');
        if (panel) {
            panel.remove();
        }
        this.isTextControlPanelOpen = false;
        this.currentEditingTextId = null;
    }

    // Public methods for recorder integration
    addTextFromRecording(textId, properties) {
        const customId = textId || `text-${this.textIdCounter++}`;
        
        const textElement = document.createElement('div');
        textElement.id = customId;
        textElement.className = 'text-display-element';
        textElement.textContent = properties.content;
        
        textElement.style.left = properties.x + '%';
        textElement.style.top = properties.y + '%';
        textElement.style.zIndex = properties.zIndex;
        
        this.applyTextStyle(textElement, properties);
        
        if (properties.animation && properties.animation !== 'none') {
            this.applyAnimation(textElement, properties);
        }
        
        document.body.appendChild(textElement);
        
        this.activeTexts.set(customId, {
            element: textElement,
            properties: { ...properties },
            isVisible: true
        });
        
        if (properties.displayTime > 0) {
            setTimeout(() => {
                if (textElement.parentNode && this.activeTexts.has(customId)) {
                    textElement.remove();
                    this.activeTexts.delete(customId);
                    this.updateActiveTextsList();
                }
            }, properties.displayTime);
        }
        
        this.updateActiveTextsList();
    }

    updateTextFromRecording(textId, properties) {
        const textData = this.activeTexts.get(textId);
        if (!textData) return;

        textData.element.textContent = properties.content;
        textData.element.style.left = properties.x + '%';
        textData.element.style.top = properties.y + '%';
        this.applyTextStyle(textData.element, properties);
        textData.properties = { ...properties };
        this.updateActiveTextsList();
    }

    toggleTextFromRecording(textId, isVisible) {
        const textData = this.activeTexts.get(textId);
        if (!textData) return;

        textData.isVisible = isVisible;
        textData.element.style.display = isVisible ? 'block' : 'none';
        this.updateActiveTextsList();
    }

    removeTextFromRecording(textId) {
        const textData = this.activeTexts.get(textId);
        if (!textData) return;

        textData.element.remove();
        this.activeTexts.delete(textId);
        this.updateActiveTextsList();
    }

    clearAllTextsFromRecording() {
        this.activeTexts.forEach((textData, textId) => {
            textData.element.remove();
        });
        this.activeTexts.clear();
        this.updateActiveTextsList();
    }

    speakText(text, properties = {}) {
        if (!('speechSynthesis' in window)) {
            console.warn('Speech synthesis not supported');
            return;
        }

        // Stop any current speech
        this.stopSpeech();

        const utterance = new SpeechSynthesisUtterance(text);
        
        // Configure voice
        if (properties.voiceIndex !== undefined && this.availableVoices[properties.voiceIndex]) {
            utterance.voice = this.availableVoices[properties.voiceIndex];
        }
        
        // Configure speech parameters
        utterance.rate = properties.speechRate || 1.0;
        utterance.pitch = properties.speechPitch || 1.0;
        utterance.volume = properties.speechVolume || 1.0;
        
        // Event handlers
        utterance.onstart = () => {
            this.isPlaying = true;
            console.log('Speech started');
        };
        
        utterance.onend = () => {
            this.isPlaying = false;
            this.currentSpeech = null;
            console.log('Speech ended');
        };
        
        utterance.onerror = (event) => {
            console.error('Speech error:', event.error);
            this.isPlaying = false;
            this.currentSpeech = null;
        };

        this.currentSpeech = utterance;
        speechSynthesis.speak(utterance);

        // Record TTS event
        if (this.recorderManager) {
            this.recorderManager.logEvent('speak-text', [text, properties]);
        }
    }

    stopSpeech() {
        if (speechSynthesis.speaking) {
            speechSynthesis.cancel();
        }
        this.isPlaying = false;
        this.currentSpeech = null;
        
        // Record stop event
        if (this.recorderManager) {
            this.recorderManager.logEvent('stop-speech', []);
        }
    }

    testSpeech() {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const properties = this.getTextPropertiesFromPanel(panel);
        this.speakText(properties.content, properties);
    }

    async translateText() {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const textContent = panel.querySelector('#text-content');
        const targetLang = panel.querySelector('#target-language').value;
        const originalText = textContent.value;

        if (!originalText.trim()) return;

        try {
            // Store original text as data attribute
            if (!textContent.dataset.originalText) {
                textContent.dataset.originalText = originalText;
            }

            // Simple translation using Google Translate (Note: In production, you'd use proper API)
            const translatedText = await this.performTranslation(originalText, targetLang);
            textContent.value = translatedText;
            this.updatePreview();

            // Record translation event
            if (this.recorderManager) {
                this.recorderManager.logEvent('translate-text', [originalText, translatedText, targetLang]);
            }

        } catch (error) {
            console.error('Translation failed:', error);
            alert('Translation failed. Please check your internet connection.');
        }
    }

    async performTranslation(text, targetLang) {
        // Simple translation simulation - in production use proper translation API
        const translations = {
            'es': text.replace(/hello/gi, 'hola').replace(/world/gi, 'mundo').replace(/sample text/gi, 'texto de muestra'),
            'fr': text.replace(/hello/gi, 'bonjour').replace(/world/gi, 'monde').replace(/sample text/gi, 'texte d\'exemple'),
            'de': text.replace(/hello/gi, 'hallo').replace(/world/gi, 'welt').replace(/sample text/gi, 'beispieltext'),
            'it': text.replace(/hello/gi, 'ciao').replace(/world/gi, 'mondo').replace(/sample text/gi, 'testo di esempio'),
            'pt': text.replace(/hello/gi, 'olá').replace(/world/gi, 'mundo').replace(/sample text/gi, 'texto de amostra'),
            'ja': text.replace(/hello/gi, 'こんにちは').replace(/world/gi, '世界').replace(/sample text/gi, 'サンプルテキスト'),
            'zh': text.replace(/hello/gi, '你好').replace(/world/gi, '世界').replace(/sample text/gi, '示例文本')
        };

        return translations[targetLang] || text;
    }

    restoreOriginalText() {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const textContent = panel.querySelector('#text-content');
        const originalText = textContent.dataset.originalText;

        if (originalText) {
            textContent.value = originalText;
            this.updatePreview();

            // Record restore event
            if (this.recorderManager) {
                this.recorderManager.logEvent('restore-original-text', [originalText]);
            }
        }
    }

    playSoundEffect(effectType) {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        let frequency, duration, type;

        switch (effectType) {
            case 'beep':
                frequency = 800;
                duration = 0.2;
                type = 'sine';
                break;
            case 'chime':
                frequency = 1000;
                duration = 0.5;
                type = 'sine';
                break;
            case 'swoosh':
                frequency = 200;
                duration = 0.3;
                type = 'sawtooth';
                break;
            case 'pop':
                frequency = 600;
                duration = 0.1;
                type = 'square';
                break;
            case 'click':
                frequency = 1200;
                duration = 0.05;
                type = 'square';
                break;
            default:
                return;
        }

        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
        oscillator.type = type;

        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);

        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + duration);

        // Record sound effect event
        if (this.recorderManager) {
            this.recorderManager.logEvent('play-sound-effect', [effectType]);
        }
    }

    testSoundEffect() {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const soundEffect = panel.querySelector('#sound-effect').value;
        if (soundEffect !== 'none') {
            this.playSoundEffect(soundEffect);
        }
    }

    // Public methods for recorder integration
    speakTextFromRecording(text, properties) {
        this.speakText(text, properties);
    }

    stopSpeechFromRecording() {
        this.stopSpeech();
    }

    translateTextFromRecording(originalText, translatedText, targetLang) {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const textContent = panel.querySelector('#text-content');
        if (textContent) {
            textContent.dataset.originalText = originalText;
            textContent.value = translatedText;
            this.updatePreview();
        }
    }

    restoreOriginalTextFromRecording(originalText) {
        const panel = document.getElementById('text-control-panel');
        if (!panel) return;

        const textContent = panel.querySelector('#text-content');
        if (textContent) {
            textContent.value = originalText;
            this.updatePreview();
        }
    }

    playSoundEffectFromRecording(effectType) {
        this.playSoundEffect(effectType);
    }
}